/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

#ifdef OLD
minimize := function(f, p, hessian=FALSE, typsiz=rep(1,np),
        typf=1, msg=9, ndigit=12, gradtl=1.e-6,
        stepmx=max(10*sqrt(sum(p^2)),10), steptl=1.e-6, iterlim=100)
#endif

	/* This is the real R function to be called by the optimizer */
	/* It comes in as an argument to minimize */

static SEXP fcn;

	/* And this is the view of it that the optimizer has */

static double f(double *x, int n)
{
        void *args[1], *values[1];
        double zz[1], *result;
        char *mode[1]; long length[1];

        args[0] = (void*)x;
        mode[0] = "double";
        length[0] = n;
        call_R((char*)fcn, 1L, args, mode, length,
		(char**)0, 1L, (char**)values);
        return *(double*)values[0];
}

static double *fixparam(SEXP p, int *n, SEXP call)
{
	double *x;
	int i;

	if(!isNumeric(p))
		errorcall(call, "numeric parameter expected");

	if(*n) {
		if(LENGTH(p) != *n)
			errorcall(call, "conflicting parameter lengths\n");
	}
	else {
		if(LENGTH(p) <= 0) 
			errorcall(call, "invalid parameter length\n");
		*n = LENGTH(p);
	}

	x = (double*)R_alloc(*n, sizeof(double));
	switch(TYPEOF(p)) {
		case LGLSXP:
		case INTSXP:
			for(i=0 ; i<*n ; i++) {
				if(INTEGER(p)[i] == NA_INTEGER)
					errorcall(call, "missing value in parameter\n");
				x[i] = INTEGER(p)[i];
			}
			break;
		case REALSXP:
			for(i=0 ; i<*n ; i++) {
				if(REAL(p)[i] == NA_REAL)
					errorcall(call, "missing value in parameter\n");
				x[i] = REAL(p)[i];
			}
			break;
		default:
			errorcall(call, "invalid parameter type\n");
	}
	return x;
}

static void invalid_na(SEXP call)
{
	errorcall(call, "invalid NA value in parameter\n");
}

#ifdef OLD
minimize := function(f, p, hessian=FALSE, typsiz=rep(1,np),
        typf=1, msg=9, ndigit=12, gradtl=1.e-6,
        stepmx=max(10*sqrt(sum(p^2)),10), steptl=1.e-6, iterlim=100)
#endif

int optif(int *pnr, int *pn, double *x, void *fcn, double *typsiz,
        double *fscale, int *msg, int *ndigit, int *itnlim, int *ipr,
        double *gradtl, double *stepmx, double *steptl, double *xpls,
        double *fpls, double *gpls, int *itrmcd, double *a, double *wrk);

SEXP do_minimize(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP value, v;
	double *p, *tp, tf, gradtl, stepmx, steptl,
		*estimate, *gradient, minimum, *hessian, *work;
	int code, i, ipr, iterlim, want_hessian, msg, n, ndigit;
	char *vmax;

	checkArity(op, args);
	PrintDefaults();
	vmax = vmaxget();

		/* the function to be minimized */

	PROTECT(fcn = CAR(args));
	if(!isFunction(fcn))
		error("attempt to minimize non-function\n");
	args = CDR(args);

		/* inital parameter value */

	n = 0;
	p = fixparam(CAR(args), &n, call);
	args = CDR(args);

		/* hessian required? */

	want_hessian = asLogical(CAR(args));
	if(want_hessian == NA_LOGICAL) want_hessian = 0;
	args = CDR(args);

		/* typical size of parameter elements */

	tp = fixparam(CAR(args), &n, call);
	args = CDR(args);
	
		/* expected function size */

	tf = asReal(CAR(args));
	if(tf == NA_REAL) invalid_na(call);
	args = CDR(args);

	msg = asInteger(CAR(args));
	if(msg == NA_INTEGER) invalid_na(call);
	args = CDR(args);

	ndigit = asInteger(CAR(args));
	if(ndigit == NA_INTEGER) invalid_na(call);
	args = CDR(args);

	gradtl = asReal(CAR(args));
	if(gradtl == NA_REAL) invalid_na(call);
	args = CDR(args);

	stepmx = asReal(CAR(args));
	if(stepmx == NA_REAL) invalid_na(call);
	args = CDR(args);

	steptl = asReal(CAR(args));
	if(steptl == NA_REAL) invalid_na(call);
	args = CDR(args);

	iterlim = asInteger(CAR(args));
	if(iterlim == NA_INTEGER) invalid_na(call);
	args = CDR(args);

	/* Plug in the call to the optimizer here */

	ipr = 6;
	estimate = (double*)R_alloc(n, sizeof(double));
	gradient = (double*)R_alloc(n, sizeof(double));
	hessian = (double*)R_alloc(n*n, sizeof(double));
	work = (double*)R_alloc(8*n, sizeof(double));

        optif(&n, &n, p, f, tp, &tf, &msg, &ndigit, &iterlim,
                &ipr, &gradtl, &stepmx, &steptl,
                estimate, &minimum, gradient, &code, hessian, work);

	if(want_hessian) {
		PROTECT(v = value = allocList(6));
                fdhess(&n, estimate, &minimum, f, hessian, &n,
			&work[0], &work[n], &ndigit, tp);
	}
	else {
		PROTECT(v = value = allocList(5));
	}

	CAR(v) = allocVector(REALSXP, 1);
	REAL(CAR(v))[0] = minimum;
	TAG(v) = install("minimum");
	v = CDR(v);

	CAR(v) = allocVector(REALSXP, n);
	for(i=0 ; i<n ; i++)
		REAL(CAR(v))[i] = estimate[i];
	TAG(v) = install("estimate");
	v = CDR(v);

	CAR(v) = allocVector(REALSXP, n);
	for(i=0 ; i<n ; i++)
		REAL(CAR(v))[i] = gradient[i];
	TAG(v) = install("gradient");
	v = CDR(v);

	if(want_hessian) {
		CAR(v) = allocMatrix(REALSXP, n, n);
		for(i=0 ; i<n*n ; i++)
			REAL(CAR(v))[i] = hessian[i];
		TAG(v) = install("hessian");
		v = CDR(v);
	}

	CAR(v) = allocVector(INTSXP, 1);
	REAL(CAR(v))[0] = msg;
	TAG(v) = install("error");
	v = CDR(v);

	CAR(v) = allocVector(INTSXP, 1);
	REAL(CAR(v))[0] = code;
	TAG(v) = install("code");
	v = CDR(v);

	vmaxset(vmax); 
	UNPROTECT(2);
	return value;
}
