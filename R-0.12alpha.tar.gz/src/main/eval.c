/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define ARGUSED(x) LEVELS(x)

#include "Defn.h"

	/* The universe will end if the Stack on the Mac grows */
	/* until it hits the heap.  This code places a limit */
	/* on the depth to which eval can recurse. */

	/* NEEDED: A fixup is needed in browser, because it */
	/* can trap errors, and currently does not reset the */
	/* limit to the right value. */

#ifdef Macintosh
extern void isintrpt();
#define EVAL_LIMIT 100
#endif

/* not ifdef'ed to keep main etc happy */
extern int R_EvalDepth;
extern int R_EvalCount;


/* eval - return value of e evaluated in rho */
SEXP eval(SEXP e, SEXP rho)
{

	SEXP op, tmp, val;

	/*
	 * The use of depthsave below is necessary because of the possibility
	 * of non-local returns from evaluation.  Without this an "expression
	 * too complex error" is quite likely.
	 */

#ifdef EVAL_LIMIT
	int depthsave = R_EvalDepth++;
	if (R_EvalDepth > EVAL_LIMIT)
		error("expression too complex for evaluator\n");
#endif
#ifdef Macintosh
	if ((R_EvalCount++ % 100) == 0) {
		isintrpt();
	}
#endif

	R_Visible = 1;
	switch (TYPEOF(e)) {
	case NILSXP:
	case LISTSXP:
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
	case REALSXP:
	case STRSXP:
	case SPECIALSXP:
	case BUILTINSXP:
	case ENVSXP:
	case CLOSXP:
		tmp = e;
		break;
	case SYMSXP:
		R_Visible = 1;
		if (e == R_DotsSymbol)
			error("... used in an incorrect context\n");
		tmp = findVar(e, rho);
		if (tmp == R_UnboundValue)
			error("Object \"%s\" not found\n", CHAR(PRINTNAME(e)));
		else if (tmp == R_MissingArg) {
			char *n = CHAR(PRINTNAME(e));
			if(*n) error("Argument \"%s\" is missing, with no default\n", CHAR(PRINTNAME(e)));
			else error("Argument is missing, with no default\n");
		}
		else if (TYPEOF(tmp) == PROMSXP) {
			PROTECT(tmp);
			tmp = eval(tmp, rho);
			if (NAMED(tmp) == 1) NAMED(tmp) = 2;
			else NAMED(tmp) = 1;
			UNPROTECT(1);
		}
		else if (!isNull(tmp))
			NAMED(tmp) = 1;
		break;
	case PROMSXP:
		if (PRVALUE(e) == R_UnboundValue) {
			if(PRSEEN(e))
				errorcall(R_GlobalContext->call,
					"recursive default argument reference\n");
			PRSEEN(e) = 1;
			val = eval(PREXPR(e), PRENV(e));
			PRSEEN(e) = 0;
			PRVALUE(e) = val;
		}
		tmp = PRVALUE(e);
		break;
	case LANGSXP:
		if (TYPEOF(CAR(e)) == SYMSXP)
			PROTECT(op = findFun(CAR(e), rho));
		else
			PROTECT(op = eval(CAR(e), rho));
		if(TRACE(op)) {
			Rprintf("trace: ");
			PrintValue(e);
		}
		if (TYPEOF(op) == SPECIALSXP) {
			int save = R_PPStackTop;
			PROTECT(CDR(e));
			R_Visible = 1 - PRIMPRINT(op);
			tmp = PRIMFUN(op) (e, op, CDR(e), rho);
			UNPROTECT(1);
			if(save != R_PPStackTop) {
				Rprintf("stack imbalance in %s, %d then %d\n",
					PRIMNAME(op), save, R_PPStackTop);
			}
		}
		else if (TYPEOF(op) == BUILTINSXP) {
			int save = R_PPStackTop;
			PROTECT(tmp = evalList(CDR(e), rho));
			R_Visible = 1 - PRIMPRINT(op);
			tmp = PRIMFUN(op) (e, op, tmp, rho);
			UNPROTECT(1);
			if(save != R_PPStackTop) {
				Rprintf("stack imbalance in %s, %d then %d\n",
					PRIMNAME(op), save, R_PPStackTop);
			}
		}
		else if (TYPEOF(op) == CLOSXP) {
			PROTECT(tmp = promiseArgs(CDR(e), rho));
			tmp = applyClosure(e, op, tmp, rho);
			UNPROTECT(1);
		}
		else
			error("attempt to apply non-function\n");
		UNPROTECT(1);
		break;
	case DOTSXP:
		error("... used in an incorrect context\n");
	default:
		UNIMPLEMENTED("eval");
	}
#ifdef EVAL_LIMIT
	R_EvalDepth = depthsave;
#endif
	return (tmp);
}

/* applyClosure - apply SEXP op of type CLOSXP to actuals */
SEXP applyClosure(SEXP call, SEXP op, SEXP arglist, SEXP rho)
{
	int i, nargs;
	SEXP body, formals, actuals, savedrho, newrho;
	SEXP f, a, tmp;
	RCNTXT cntxt;

		/* formals = list of formal parameters */
		/* actuals = values to be bound to formals */
		/* arglist = the tagged list of arguments */

	formals = FORMALS(op);
	body = BODY(op);
	savedrho = CLOENV(op);
	nargs = length(arglist);

	/*set up a context with the call in it so error has access to it */
	begincontext(&cntxt, CTXT_RETURN, call, newrho, rho); 

	actuals = matchArgs(formals,arglist);
	PROTECT(newrho = extendEnv(savedrho, formals, actuals));
	NARGS(newrho) = nargs;

	/* end the previous context and start up a new one with the correct env*/
	endcontext(&cntxt);
	begincontext(&cntxt, CTXT_RETURN, call, newrho, rho); 


	/* Use default code for unbound formals */
	f = formals;
	a = actuals;
	while (f != R_NilValue) {
		if (CAR(a) == R_MissingArg && CAR(f) != R_MissingArg) {
			CAR(a) = mkPROMISE(CAR(f), newrho);
			MISSING(a) = 2;
		}
		f = CDR(f);
		a = CDR(a);
	}

	/* Default value */
	tmp = R_NilValue;

	/* debugging */
	DEBUG(newrho) = DEBUG(op);
		
	if (setjmp(cntxt.cjmpbuf)) {
		tmp = R_ReturnedValue;
	}
	else {
		tmp = eval(body, newrho);
	}
	endcontext(&cntxt);
	UNPROTECT(1);

	return (tmp);
}

/* Build a list of promises to evaluate unmatched arguments */
SEXP extractUnused(SEXP a)
{
	if (a == R_NilValue)
		return R_NilValue;
	if (ARGUSED(a))
		return extractUnused(CDR(a));
	SETCDR(a, extractUnused(CDR(a)));
	return a;
}


static SEXP EnsureLocal(SEXP symbol, SEXP rho)
{
        SEXP vl;

	vl = findVarInFrame(FRAME(rho), symbol);
	if (vl != R_UnboundValue) {
		return eval(symbol, rho);
	}

	vl = eval(symbol, ENCLOS(rho));
	if (vl == R_UnboundValue)
		error("Object \"%s\" not found\n", CHAR(PRINTNAME(symbol)));

	PROTECT(vl = duplicate(vl));
	defineVar(symbol, vl, rho);
	UNPROTECT(1);
	NAMED(vl) = 1;
	return vl;
}

	/* evalseq - preprocess the LHS of an assignment.	*/
	/* Given an expression, evalseq builds a list of	*/
	/* partial values for the exression.  For example,	*/
	/* the assignment x$a[3] <- 10 with LHS x$a[3] yields	*/
	/* the (improper) list:					*/
	/*							*/
	/*	 (eval(x$a[3])  eval(x$a)  eval(x)  .  x)	*/
	/*							*/
	/* Note the terminating symbol.				*/
	/* The partial evaluations are carried out efficiently	*/
	/* using previously computed components.		*/

static SEXP evalseq(SEXP expr, SEXP rho, int forcelocal)
{
	SEXP val, nval, nexpr;
	if (isNull(expr))
		error("invalid left side of assignment\n");
	if (isSymbol(expr)) {
		PROTECT(expr);
		if(forcelocal) {
			nval = EnsureLocal(expr, rho);
		}
		else {
			nval = eval(expr, rho);
		}
		UNPROTECT(1);
		return CONS(nval, expr);
	}
	else if (isLanguage(expr)) {
		PROTECT(expr);
		PROTECT(val = evalseq(CADR(expr), rho, forcelocal));
		PROTECT(nexpr = LCONS(CAR(val), CDDR(expr)));
		PROTECT(nexpr = LCONS(CAR(expr), nexpr));
		nval = eval(nexpr, rho);
		UNPROTECT(4);
		return CONS(nval, val);
	}
	else error("invalid left side of assignment\n");
	/*NOTREACHED*/
}

/* NOTE: list and end must be protected before top level entry */
static SEXP langAppend(SEXP lst, SEXP end)
{
	if (lst == R_NilValue) 
		lst = LCONS(end, R_NilValue);
	else
		lst = CONS(CAR(lst), langAppend(CDR(lst), end));
	return lst;
}

static SEXP replaceCall(SEXP fun, SEXP val, SEXP args, SEXP rhs)
{
	SEXP tmp;
	PROTECT(fun);
	PROTECT(val);
	PROTECT(args);
	PROTECT(rhs);
	val = LCONS(fun, LCONS(val, langAppend(args, rhs)));
	UNPROTECT(4);
	return val;
}

static SEXP assignCall(SEXP op, SEXP symbol, SEXP fun, SEXP val, SEXP args, SEXP rhs)
{
	PROTECT(op);
	PROTECT(symbol);
	val = replaceCall(fun, val, args, rhs);
	UNPROTECT(2);
	return lang3(op, symbol, val);
}

SEXP do_if(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int cond = asLogical(eval(CAR(args), rho));
	if (cond == NA_LOGICAL)
		errorcall(call, "missing value where logical needed\n");
	else if (cond)
		return (eval(CAR(CDR(args)), rho));
	else if (length(args) > 2)
		return (eval(CAR(CDR(CDR(args))), rho));
	return R_NilValue;
}

SEXP do_for(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int i, n, tmp, dbg, bgn;
	SEXP ans, sym, v, val, body;
	RCNTXT cntxt;

	sym = CAR(args);
	val = CADR(args);
	body = CADDR(args);

	PROTECT(args);
	PROTECT(rho);
	PROTECT(val = eval(val, rho));
	defineVar(sym, R_NilValue, rho);
	if (isList(val) || isNull(val)) {
		n = length(val);
		PROTECT(v = R_NilValue);
	}
	else {
		n = LENGTH(val);
		PROTECT(v = allocVector(TYPEOF(val), 1));
	}
	ans = R_NilValue;

	dbg = DEBUG(rho);
	if( isSymbol(CAR(body)) && strcmp(CHAR(PRINTNAME(CAR(body))),"{") )
			bgn = 1;
	else
			bgn = 0;

	for (i = 0; i < n; i++) {
		if( DEBUG(rho) && bgn ) {
			Rprintf("debug: ");
			PrintValue(body);
			do_browser(call,op,args,rho);
		}
		begincontext(&cntxt, CTXT_LOOP, R_NilValue, R_NilValue, R_NilValue);
		if ((tmp = setjmp(cntxt.cjmpbuf)))
			if (tmp == CTXT_BREAK) break;	/* break */
			else continue;			/* next  */
		else {
			if (isVector(v)) {
				UNPROTECT(1);
				PROTECT(v = allocVector(TYPEOF(val), 1));
			}
			switch (TYPEOF(val)) {
			case LGLSXP:
				LOGICAL(v)[0] = LOGICAL(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case INTSXP:
				INTEGER(v)[0] = INTEGER(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case REALSXP:
				REAL(v)[0] = REAL(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case STRSXP:
				STRING(v)[0] = STRING(val)[i];
				setVar(sym, v, rho);
				ans = eval(body, rho);
				break;
			case LISTSXP:
				setVar(sym, CAR(val), rho);
				ans = eval(body, rho);
				val = CDR(val);
			}
			endcontext(&cntxt);
		}
	}
	UNPROTECT(4);
	R_Visible = 0;
	DEBUG(rho) = dbg;
	return ans;
}

SEXP do_while(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int cond, dbg, bgn;
	SEXP s, t;
	RCNTXT cntxt;

	checkArity(op, args);
	s = eval(CAR(args), rho);

	dbg = DEBUG(rho);
	t=CAR(CADR(args));
	if( isSymbol(t) && strcmp(CHAR(PRINTNAME(t)),"{") )
		bgn=1;
	t = R_NilValue;
	for (;;) {
		if ((cond = asLogical(s)) == NA_LOGICAL)
			errorcall(call, "missing value where logical needed\n");
		else if (!cond)
			break;

		if( bgn && DEBUG(rho) ) {
			Rprintf("debug: ");
			PrintValue(CAR(args));
			do_browser(call,op,args,rho);
		}
			
		begincontext(&cntxt, CTXT_LOOP, R_NilValue, R_NilValue, R_NilValue);
		if ((cond = setjmp(cntxt.cjmpbuf)))
			if (cond == CTXT_BREAK) break;	/* break */
			else continue;			/* next  */
		else {
			PROTECT(t = eval(CAR(CDR(args)), rho));
			s = eval(CAR(args), rho);
			UNPROTECT(1);
			endcontext(&cntxt);
		}
	}
	R_Visible = 0;
	DEBUG(rho) = dbg;
	return t;
}

SEXP do_repeat(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int cond, dbg, bgn;
	SEXP t;
	RCNTXT cntxt;

	checkArity(op, args);

	dbg = DEBUG(rho);
	if( isSymbol(CAR(args)) && strcmp(CHAR(PRINTNAME(CAR(args))),"{") )
		bgn=1;

	for (;;) {
		if( DEBUG(rho) && bgn ) {
			Rprintf("debug: ");
			PrintValue(CAR(args));
			do_browser(call,op,args,rho);
		}

		begincontext(&cntxt, CTXT_LOOP, R_NilValue, R_NilValue, R_NilValue);
		if ((cond = setjmp(cntxt.cjmpbuf)))
			if (cond == CTXT_BREAK) break;	/*break */
			else continue;			/* next */
		else {
			t = eval(CAR(args), rho);
			endcontext(&cntxt);
		}
	}
	R_Visible = 0;
	DEBUG(rho) = dbg;
	return t;
}

SEXP do_break(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	findcontext(PRIMVAL(op), R_NilValue);
	/*NOTREACHED*/
}

SEXP do_paren(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	checkArity(op, args);
	return CAR(args);
}

SEXP do_begin(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP s;

	if (args == R_NilValue) {
		s = R_NilValue;
	}
	else { 
		while (args != R_NilValue) {
			if( DEBUG(rho) ) {
				Rprintf("debug: ");
				PrintValue(CAR(args));
				do_browser(call,op,args,rho);
			}
			s = eval(CAR(args), rho);
			args = CDR(args); 
		} 
	}
	return s;
}

SEXP do_return(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP s;
	s = eval(CAR(args), rho);
	/* R_Visible = 1; */
	findcontext(CTXT_RETURN, s);
	/*NOTREACHED*/
}

SEXP do_function(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	if (length(args) < 2)
		WrongArgCount("lambda");
	CheckFormals(CAR(args));
	return mkCLOSXP(CAR(args), CADR(args), rho);
}

	/* Assignments for complex LVAL specifications */
	/* We have checked to see that CAR(args) is a LANGSXP */

static char *asym[] = {":=", "<-", "<<-"};

SEXP applydefine(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP expr, lhs, rhs, saverhs;
	char buf[32];

	expr = CAR(args);
	/* it's important that the rhs get evaluated first */
	PROTECT(saverhs =rhs = eval(CADR(args), rho));
	PROTECT(lhs = evalseq(CADR(expr), rho, PRIMVAL(op)==1));
	while (isLanguage(CADR(expr))) {
		sprintf(buf, "%s<-", CHAR(PRINTNAME(CAR(expr))));
		UNPROTECT(1);
		PROTECT(rhs = replaceCall(install(buf), CAR(lhs), CDDR(expr), rhs));
		rhs = eval(rhs, rho);
		lhs = CDR(lhs);
		expr = CADR(expr);
	}
	sprintf(buf, "%s<-", CHAR(PRINTNAME(CAR(expr))));
	PROTECT(expr = assignCall(install(asym[PRIMVAL(op)]), CDR(lhs),
				 install(buf), CAR(lhs), CDDR(expr), rhs));
	expr = eval(expr, rho);
	UNPROTECT(3);
	return duplicate(saverhs);
}

	/* do_set - assignment in its various forms */

SEXP do_set(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP s;

	if (length(args) != 2) WrongArgCount(asym[PRIMVAL(op)]);
	if (isString(CAR(args)))
		CAR(args) = install(CHAR(STRING(CAR(args))[0]));

	switch (PRIMVAL(op)) {
	case 0:						/* := */
		if (isSymbol(CAR(args))) {
			s = eval(CADR(args), rho);
			if (NAMED(s))
				s = duplicate(s);
			PROTECT(s);
			R_Visible = 0;
			gsetVar(CAR(args), s, rho);
			UNPROTECT(1);
			NAMED(s) = 1;
			return s;
		}
		else if (isLanguage(CAR(args))) {
			R_Visible = 0;
			return applydefine(call, op, args, rho);
		}
		else error("invalid assignment lhs\n");
		/*NOTREACHED*/
	case 1:						/* <- */
		if (isSymbol(CAR(args))) {
			s = eval(CADR(args), rho);
			if (NAMED(s))
				s = duplicate(s);
			PROTECT(s);
			R_Visible = 0;
			defineVar(CAR(args), s, rho);
			UNPROTECT(1);
			NAMED(s) = 1;
			return (s);
		}
		else if (isLanguage(CAR(args))) {
			R_Visible = 0;
			return applydefine(call, op, args, rho);
		}
		else error("invalid left-hand side to assignment\n");
		/*NOTREACHED*/
	case 2:						/* <<- */
		if (isSymbol(CAR(args))) {
			s = eval(CADR(args), rho);
			if (NAMED(s))
				s = duplicate(s);
			PROTECT(s);
			R_Visible = 0;
			setVar(CAR(args), s, rho);
			UNPROTECT(1);
			NAMED(s) = 1;
			return s;
		}
		else if (isLanguage(CAR(args)))
			return applydefine(call, op, args, rho);
		else error("invalid assignment lhs\n");
		/*NOTREACHED*/
	default:
		UNIMPLEMENTED("do_set");
	}
	/*NOTREACHED*/
}

/* evalList - evaluate each expression in el */
SEXP evalList(SEXP el, SEXP rho)
{
	SEXP h, t;

	if (el == R_NilValue)
		return R_NilValue;

	if (CAR(el) == R_DotsSymbol) {
		h = findVar(CAR(el), rho);
		if (h == R_NilValue)
			return evalList(CDR(el), rho);
		if (TYPEOF(h) != DOTSXP) {
			if (h == R_MissingArg)
				return evalList(CDR(el), rho);
			error("... used in an incorrect context\n");
		}
		PROTECT(h = evalList(h, rho));
		PROTECT(t = evalList(CDR(el), rho));
		t = listAppend(h, t);
		UNPROTECT(2);
		return t;
	}
	else if (CAR(el) == R_MissingArg) {
		return evalList(CDR(el), rho);
	}
	else {
		PROTECT(h = eval(CAR(el), rho));
		PROTECT(t = evalList(CDR(el), rho));
		t = CONS(h, t);
		TAG(t) = TAG(el);
		UNPROTECT(2);
		return t;
	}
}

/* promiseArgs - create a promise to evaluate each argument */
SEXP promiseArgs(SEXP el, SEXP rho)
{
	SEXP h, t;
	if (el == R_NilValue) {
		return R_NilValue;
	}
	else if (CAR(el) == R_MissingArg ) {
		PROTECT(t = promiseArgs(CDR(el), rho));
		t = CONS(R_MissingArg, t);
		TAG(t) = TAG(el);
		UNPROTECT(1);
		return t;
	}
	else if (CAR(el) == R_DotsSymbol) {
		h = findVar(CAR(el), rho);
		if (TYPEOF(h) != DOTSXP) {
			if (h == R_MissingArg || h == R_NilValue)
				return promiseArgs(CDR(el), rho);
			error("... used in an incorrect context\n");
		}
		PROTECT(h = promiseArgs(h, rho));
		PROTECT(t = promiseArgs(CDR(el), rho));
		t = listAppend(h, t);
		UNPROTECT(2);
		return t;
	}
	else {
		PROTECT(h = mkPROMISE(CAR(el), rho));
		PROTECT(t = promiseArgs(CDR(el), rho));
		t = CONS(h, t);
		TAG(t) = TAG(el);
		UNPROTECT(2);
		return t;
	}
}


void CheckFormals(SEXP ls)
{
	if (isList(ls))
		for (; ls != R_NilValue; ls = CDR(ls))
			if (TYPEOF(TAG(ls)) != SYMSXP)
				error("invalid formal argument list for \"function\"\n");
}


/* WrongArgCount - error recovery for wrong # of args */
void WrongArgCount(char *s)
{
	error("incorrect number of arguments to \"%s\"\n", s);
}


	/* Evaluate the first argument in the environment */
	/* specified by the second argument. */

SEXP do_eval(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP tmp, expr, env;
	int nback;
	checkArity(op, args);

	expr = CAR(args);
	env = CADR(args);

	switch(TYPEOF(env)) {
	case NILSXP: /* if no envir use the one up from eval */
		PROTECT(env = sysframe(0,R_GlobalContext));
		break;
	case LISTSXP:
		PROTECT(env = allocSExp(ENVSXP));
		FRAME(env) = duplicate(CADR(args));
		ENCLOS(env) = R_GlobalEnv;
		break;
	case ENVSXP:
		PROTECT(env); /* so we can unprotect 2 at the end */
		break;
	case INTSXP:
	case REALSXP:
		nback = asInteger(env);
		if (nback==NA_INTEGER)
			errorcall(call,"invalid environment\n");
		if (nback > 0 )
			nback -= framedepth(R_GlobalContext);
		nback = -nback;
		PROTECT(env = sysframe(nback,R_GlobalContext));
		break;
	default:
		errorcall(call, "invalid second argument\n");
	}

	if(isLanguage(expr) || isSymbol(expr)) {
		PROTECT(expr);
		expr = eval(expr, env);
		UNPROTECT(1);
	}
	UNPROTECT(1);
	return expr;
}
