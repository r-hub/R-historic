/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"

#define SMALL	0.25
#define RADIUS	0.425
#define SQRC	0.88622692545275801364		/* sqrt(pi / 4) */
#define DMDC	1.25331413731550025119		/* sqrt(pi / 4) * sqrt(2) */
#define TRC0	1.55512030155621416073		/* sqrt(4 * pi/(3 * sqrt(3))) */
#define TRC1	1.34677368708859836060		/* TRC0 * sqrt(3) / 2 */
#define TRC2	0.77756015077810708036		/* TRC0 / 2 */

void GSymbol(double x, double y, int pch)
{
	double r, xc, yc;
	double xx[4], yy[4];
	char str[2];
	int ltysave;

	if(' ' <= pch && pch <= 255) {
		str[0] = pch;
		str[1] = '\0';
		GText(x, y, str, GP->xCharOffset, GP->yCharOffset, 0.0);
	}
	else {
		ltysave = GP->lty;
		GP->lty = LTY_SOLID;

		switch(pch) {
		case 0:					/* Dot */
			xc = SMALL * GStrWidth("0", 3);
			GCircle(x, y, xc, GP->col, GP->col);
			break;
		case 1:					/* Unfilled Circle */
			xc = RADIUS * GStrWidth("0", 3);
			GCircle(x, y, xc, NA_INTEGER, GP->col);
			break;
		case 2:					/* Unfilled Square */
			xc = RADIUS * SQRC * GStrWidth("0",2);
			yc = GP->asp * xc;
			GRect(x-xc, y-yc, x+xc, y+yc, NA_INTEGER, GP->col);
			break;
		case 3:					/* Unfilled Diamond */
			xc = RADIUS * DMDC * GStrWidth("0",2);
			yc = GP->asp * xc;
			GStartPath();
			GMoveTo(x, y-yc);
			GLineTo(x+xc, y);
			GLineTo(x, y+yc);
			GLineTo(x-xc, y);
			GLineTo(x, y-yc);
			GEndPath();
			break;
		case 4:					/* Triangle - point up */
			xc = RADIUS * TRC1 * GStrWidth("0",2);
			r = GP->asp * RADIUS * TRC0 * GStrWidth("0",2);
			yc = GP->asp * RADIUS * TRC2 * GStrWidth("0",2);
			GStartPath();
			GMoveTo(x, y+r);
			GLineTo(x+xc, y-yc);
			GLineTo(x-xc, y-yc);
			GLineTo(x, y+r);
			GEndPath();
			break;
		case 11:				/* Filled Circle */
			xc = RADIUS * GStrWidth("0", 3);
			GCircle(x, y, xc, GP->col, GP->col);
			break;
		case 16:				/* Opaque Circle */
			xc = RADIUS * GStrWidth("0", 3);
			GCircle(x, y, xc, GP->bg, GP->col);
			break;
		}
		GP->lty = ltysave;
	}
}
