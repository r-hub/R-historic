/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPBDI computes the determinant
 *     of a double symmetric positive definite band matrix
 *     using the factors computed by DPBCO or DPBFA.
 *     If the inverse is needed, use DPBSL  n  times.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                the output from DPBCO or DPBFA.
 *
 *        lda     int
 *                the leading dimension of the array  abd.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        m       int
 *                the number of diagonals above the main diagonal.
 *
 *     On Return
 *
 *        det     double(2)
 *                determinant of original matrix in the form
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 <= det(1) < 10.0
 *                or  det(1) == 0.0.
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPBDI(double *abd, int lda, int n, int m, double *det)
{
	double s;
	int i;

	abd -= (lda+1);
	det -= 1;

	/* compute determinant */

	det[1] = 1.0;
	det[2] = 0.0;
	s = 10.0;
	for(i=1 ; i <= n  ; i++) {
		det[1] = fsquare(abd[m+1+i*lda])*det[1];
		if(det[1] == 0.0)
			break;
		while (det[1] < 1.0) {
			det[1] = s*det[1];
			det[2] = det[2]-1.0;
		}
		while (det[1] >= s) {
			det[1] = det[1]/s;
			det[2] = det[2]+1.0;
		}
	}
	return;
}

int dpbdi_(double *abd, int *lda, int *n, int *m, double *det)
{
	DPBDI(abd, *lda, *n, *m, det);
}
