/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGBCO factors a double band matrix by Gaussian
 *     elimination and estimates the condition of the matrix.
 *
 *     If  rcond  is not needed, DGBFA is slightly faster.
 *     To solve  a*x = b , follow DGBCO by DGBSL.
 *     To compute  inverse(a)*c , follow DGBCO by DGBSL.
 *     To compute  determinant(a) , follow DGBCO by DGBDI.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                contains the matrix in band storage.  the columns
 *                of the matrix are stored in the columns of  abd  and
 *                the diagonals of the matrix are stored in rows
 *                ml + 1 through 2 * ml + mu + 1 of  abd.
 *                see the comments below for details.
 *
 *        lda     int
 *                the leading dimension of the array  abd.
 *                lda must be >= 2 * ml + mu + 1.
 *
 *        n       int
 *                the order of the original matrix.
 *
 *        ml      int
 *                number of diagonals below the main diagonal.
 *                0 <= ml < n.
 *
 *        mu      int
 *                number of diagonals above the main diagonal.
 *                0 <= mu < n.
 *                more efficient if  ml <= mu.
 *
 *     On Return
 *
 *        abd     an upper triangular matrix in band storage and
 *                the multipliers which were used to obtain it.
 *                the factorization can be written  a = l*u  where
 *                l  is a product of permutation and unit lower
 *                triangular matrices and  u  is upper triangular.
 *
 *        ipvt    int(n)
 *                an int vector of pivot indices.
 *
 *        rcond   double*
 *                an estimate of the reciprocal condition of  a.
 *                for the system  a*x = b , relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond.
 *                if  rcond  is so small that the int expression
 *                           1.0 + rcond == 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z).
 *
 *     Band Storage
 *
 *           If  a  is a band matrix, the following program segment
 *           will set up the input.
 *
 *                   ml = (band width below the diagonal)
 *                   mu = (band width above the diagonal)
 *                   m = ml + mu + 1
 *                   do 20 j = 1, n
 *                      i1 = imax(1, j-mu)
 *                      i2 = imin(n, j+ml)
 *                      do 10 i = i1, i2
 *                         k = i - j +m
 *                         abd(k,j) = a(i,j)
 *                10    continue
 *                20 continue
 *
 *           This uses rows  ml+1  through  2*ml+mu+1  of  abd.
 *           in addition, the first  ml  rows in  abd  are used for
 *           elements generated during the triangularization.
 *           the total number of rows needed in  abd  is  2*ml+mu+1.
 *           the  ml+mu by ml+mu  upper left triangle and the
 *           ml by ml  lower right triangle are not referenced.
 *
 *     Example..  If the original matrix is
 *
 *           11 12 13  0  0  0
 *           21 22 23 24  0  0
 *            0 32 33 34 35  0
 *            0  0 43 44 45 46
 *            0  0  0 54 55 56
 *            0  0  0  0 65 66
 *
 *      Then  n = 6, ml = 1, mu = 2, lda >= 5  and abd should contain
 *
 *            *  *  *  +  +  +  , * = not used
 *            *  * 13 24 35 46  , += used for pivoting
 *            * 12 23 34 45 56
 *           11 22 33 44 55 66
 *           21 32 43 54 65  *
 *
 *     LINPACK. This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DGBCO(double *abd, int lda, int n, int ml, int mu, int *ipvt, double *rcond, double *z)
{
	double ek, t, wk, wkm;
	double anorm, s, sm, ynorm;
	int is, info, j, ju, k, kb, kp1, l, la, lm, lz, m, mm;

	abd -= (lda+1);
	ipvt -= 1;
	z -= 1;

	/* compute 1-norm of a */

	anorm = 0.0;
	l = ml+1;
	is = l+mu;
	for(j=1 ; j <= n  ; j++) {
		anorm = fmax(anorm, DASUM(l, &abd[is+j*lda], 1));
		if(is > ml+1)
			is = is-1;
		if(j <= mu)
			l = l+1;
		if(j >= n-ml)
			l = l-1;
	}

	/* factor */

	DGBFA(&abd[1+lda], lda, n, ml, mu, &ipvt[1], &info);

	/* rcond = 1/(norm(a)*(estimate of norm(inverse(a)))) . */
	/* estimate = norm(z)/norm(y) where  a*z = y  and  trans(a)*y = e . */
	/* trans(a)  is the transpose of a .  the components of  e  are */
	/* chosen to cause maximum local growth in the elements of w  where */
	/* trans(u)*w = e .  the vectors are frequently rescaled to avoid */
	/* overflow. */

	/* solve trans(u)*w = e */

	ek = 1.0;
	for(j=1 ; j <= n ; j++) 
		z[j] = 0.0;
	m = ml+mu+1;
	ju = 0;
	for(k=1 ; k <= n  ; k++) {
		if(z[k] != 0.0)
			ek = fsign(ek, -z[k]);
		if(fabs(ek-z[k]) > fabs(abd[m+k*lda])) {
			s = fabs(abd[m+k*lda])/fabs(ek-z[k]);
			DSCAL(n, s, &z[1], 1);
			ek = s*ek;
		}
		wk = ek-z[k];
		wkm = -ek-z[k];
		s = fabs(wk);
		sm = fabs(wkm);
		if(abd[m+k*lda] == 0.0) {
			wk = 1.0;
			wkm = 1.0;
		}
		else {
			wk = wk/abd[m+k*lda];
			wkm = wkm/abd[m+k*lda];
		}
		kp1 = k+1;
		ju = imin(imax(ju, mu+ipvt[k]), n);
		mm = m;
		if(kp1 <= ju) {
			for(j=kp1 ; j <= ju  ; j++) {
				mm = mm-1;
				sm = sm+fabs(z[j]+wkm*abd[mm+j*lda]);
				z[j] = z[j]+wk*abd[mm+j*lda];
				s = s+fabs(z[j]);
			}
			if(s < sm) {
				t = wkm-wk;
				wk = wkm;
				mm = m;
				for(j=kp1 ; j <= ju  ; j++) {
					mm = mm-1;
					z[j] = z[j]+t*abd[mm+j*lda];
				}
			}
		}
		z[k] = wk;
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);

	/* solve trans(l)*y = w */

	for(kb=1 ; kb <= n  ; kb++) {
		k = n+1-kb;
		lm = imin(ml, n-k);
		if(k < n)
			z[k] = z[k]+DDOT(lm, &abd[m+1+k*lda], 1, &z[k+1], 1);
		if(fabs(z[k]) > 1.0) {
			s = 1.0/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
		}
		l = ipvt[k];
		t = z[l];
		z[l] = z[k];
		z[k] = t;
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);

	ynorm = 1.0;

	/* solve l*v = y */

	for(k=1 ; k <= n  ; k++) {
		l = ipvt[k];
		t = z[l];
		z[l] = z[k];
		z[k] = t;
		lm = imin(ml, n-k);
		if(k < n)
			DAXPY(lm, t, &abd[m+1+k*lda], 1, &z[k+1], 1);
		if(fabs(z[k]) > 1.0) {
			s = 1.0/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
			ynorm = s*ynorm;
		}
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);
	ynorm = s*ynorm;

	/* solve  u*z = w */

	for(kb=1 ; kb <= n  ; kb++) {
		k = n+1-kb;
		if(fabs(z[k]) > fabs(abd[m+k*lda])) {
			s = fabs(abd[m+k*lda])/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
			ynorm = s*ynorm;
		}
		if(abd[m+k*lda] != 0.0)
			z[k] = z[k]/abd[m+k*lda];
		if(abd[m+k*lda] == 0.0)
			z[k] = 1.0;
		lm = imin(k, m)-1;
		la = m-lm;
		lz = k-lm;
		t = -z[k];
		DAXPY(lm, t, &abd[la+k*lda], 1, &z[lz], 1);
	}

	/* make znorm = 1.0 */

	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);
	ynorm = s*ynorm;

	if(anorm != 0.0)
		*rcond = ynorm/anorm;
	else
		*rcond = 0.0;
	return;
}

int dgbco_(double *abd, int *lda, int *n, int *ml, int *mu, int *ipvt, double *rcond, double *z)
{
	DGBCO(abd, *lda, *n, *ml, *mu, ipvt, rcond, z);
}
