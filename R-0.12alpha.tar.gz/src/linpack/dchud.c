/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DCHUD updates an augmented cholesky decomposition of the
 *     triangular part of an augmented qr decomposition.  Specifically,
 *     given an upper triangular matrix r of order p, a row vector
 *     x, a column vector z, and a scalar y, DCHUD determines a
 *     untiary matrix u and a scalar zeta such that
 *
 *
 *                              (r  z)     (rr   zz )
 *                         u  * (    )  =  (        ),
 *                              (x  y)     ( 0  zeta)
 *
 *     where rr is upper triangular.  If r and z have been
 *     obtained from the factorization of a least squares
 *     problem, then rr and zz are the factors corresponding to
 *     the problem with the observation (x,y) appended.  In this
 *     case, if rho is the norm of the residual vector, then the
 *     norm of the residual vector of the updated problem is
 *     sqrt(rho**2 + zeta**2).  DCHUD will simultaneously update
 *     several triplets (z,y,rho).
 *     For a less terse description of what DCHUD does and how
 *     it may be applied, see the LINPACK guide.
 *
 *     The matrix u is determined as the product u(p)*...*u(1),
 *     where u(i) is a rotation in the (i,p+1) plane of the
 *     form
 *
 *                       (     c(i)      s(i) )
 *                       (                    ).
 *                       (    -s(i)      c(i) )
 *
 *     The rotations are chosen so that c(i) is double precision.
 *
 *     On Entry
 *
 *         r      double(ldr,p), where ldr >= p.
 *                r contains the upper triangular matrix
 *                that is to be updated.  the part of r
 *                below the diagonal is not referenced.
 *
 *         ldr    int.
 *                ldr is the leading dimension of the array r.
 *
 *         p      int.
 *                p is the order of the matrix r.
 *
 *         x      double(p).
 *                x contains the row to be added to r.  x is
 *                not altered by DCHUD.
 *
 *         z      double(ldz,nz), where ldz >= p.
 *                z is an array containing nz p-vectors to
 *                be updated with r.
 *
 *         ldz    int.
 *                ldz is the leading dimension of the array z.
 *
 *         nz     int.
 *                nz is the number of vectors to be updated
 *                nz may be zero, in which case z, y, and rho
 *                are not referenced.
 *
 *         y      double(nz).
 *                y contains the scalars for updating the vectors
 *                z.  y is not altered by DCHUD.
 *
 *         rho    double(nz).
 *                rho contains the norms of the residual
 *                vectors that are to be updated.  if rho(j)
 *                is negative, it is left unaltered.
 *
 *     On Return
 *
 *         rc
 *         rho    contain the updated quantities.
 *         z
 *
 *         c      double(p).
 *                c contains the cosines of the transforming
 *                rotations.
 *
 *         s      double(p).
 *                s contains the sines of the transforming
 *                rotations.
 *
 *     LINPACK. This version dated 08/14/78.
 *     G.W. Stewart, University of Maryland, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define r(i,j)	r[i+(j)*ldr]
#define z(i,j)	z[i+(j)*ldz]
#define rho(i)	rho[i]
#define x(i)	x[i]
#define y(i)	y[i]
#define c(i)	c[i]
#define s(i)	s[i]

void DCHUD(double *r, int ldr, int p, double *x, double *z, int ldz, int nz, double *y, double *rho, double *c, double *s)
{
	int i, j, jm1;
	double azeta, scale;
	double t, xj, zeta;

	r -= (ldr+1);
	z -= (ldz+1);
	rho -= 1;
	x -= 1;
	y -= 1;
	c -= 1;
	s -= 1;

	/* update r. */

	for(j=1 ; j <= p  ; j++) {
		xj = x(j);

		/* apply the previous rotations. */

		jm1 = j-1;
		if(jm1 >= 1)
			for(i=1 ; i <= jm1  ; i++) {
				t = c(i)*r(i, j)+s(i)*xj;
				xj = c(i)*xj-s(i)*r(i, j);
				r(i, j) = t;
			}

		/* compute the next rotation. */

		DROTG(&r(j, j), &xj, &c(j), &s(j));
	}

	/* if required, update z and rho. */

	if(nz >= 1)
		for(j=1 ; j <= nz  ; j++) {
			zeta = y(j);
			for(i=1 ; i <= p  ; i++) {
				t = c(i)*z(i, j)+s(i)*zeta;
				zeta = c(i)*zeta-s(i)*z(i, j);
				z(i, j) = t;
			}
			azeta = fabs(zeta);
			if(azeta != 0.0 && rho(j) >= 0.0) {
				scale = azeta+rho(j);
				rho(j) = scale*sqrt(fsquare(azeta/scale)+fsquare(rho(j)/scale));
			}
		}
	return;
}

int dchud_(double *r, int *ldr, int *p, double *x, double *z, int *ldz, int *nz, double *y, double *rho, double *c, double *s)
{
	DCHUD(r, *ldr, *p, x, z, *ldz, *nz, y, rho, c, s);
}
