/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGBSL solves the double band system
 *     a * x = b  or  trans(a) * x = b
 *     using the factors computed by DGBCO or DGBFA.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                the output from DGBCO or DGBFA.
 *
 *        lda     int
 *                the leading dimension of the array  abd .
 *
 *        n       int
 *                the order of the original matrix.
 *
 *        ml      int
 *                number of diagonals below the main diagonal.
 *
 *        mu      int
 *                number of diagonals above the main diagonal.
 *
 *        ipvt    int(n)
 *                the pivot vector from DGBCO or DGBFA.
 *
 *        b       double(n)
 *                the right hand side vector.
 *
 *        job     int
 *                = 0         to solve  a*x = b ,
 *                = nonzero   to solve  trans(a)*x = b , where
 *                            trans(a)  is the transpose.
 *
 *     On Return
 *
 *        b       the solution vector  x.
 *
 *     Error Condition
 *
 *        A division by zero will occur if the input factor contains a
 *        zero on the diagonal.  Technically this indicates singularity
 *        but it is often caused by improper arguments or improper
 *        setting of lda.  It will not occur if the subroutines are
 *        called correctly and if DGBCO has set rcond > 0.0
 *        or DGBFA has set info == 0.
 *
 *     To compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           DGBCO(abd,lda,n,ml,mu,ipvt,rcond,z)
 *           if (rcond is too small) go to ...
 *           do 10 j = 1, p
 *              DGBSL(abd,lda,n,ml,mu,ipvt,c(1,j),0)
 *        10 continue
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DGBSL(double *abd, int lda, int n, int ml, int mu, int *ipvt, double *b, int job)
{
	double t;
	int k, kb, l, la, lb, lm, m, nm1;

	abd -= (lda+1);
	ipvt -= 1;
	b -= 1;

	m = mu+ml+1;
	nm1 = n-1;
	if(job != 0) {

		/* job = nonzero, solve  trans(a) * x = b */
		/* first solve  trans(u)*y = b */

		for(k=1 ; k <= n  ; k++) {
			lm = imin(k, m)-1;
			la = m-lm;
			lb = k-lm;
			t = DDOT(lm, &abd[la+k*lda], 1, &b[lb], 1);
			b[k] = (b[k]-t)/abd[m+k*lda];
		}

		/* now solve trans(l)*x = y */

		if(ml != 0)
			if(nm1 >= 1)
				for(kb=1 ; kb <= nm1  ; kb++) {
					k = n-kb;
					lm = imin(ml, n-k);
					b[k] = b[k]+DDOT(lm, &abd[m+1+k*lda], 1, &b[k+1], 1);
					l = ipvt[k];
					if(l != k) {
						t = b[l];
						b[l] = b[k];
						b[k] = t;
					}
				}
	}
	else {

		/* job = 0 , solve  a * x = b */
		/* first solve l*y = b */

		if(ml != 0)
			if(nm1 >= 1)
				for(k=1 ; k <= nm1  ; k++) {
					lm = imin(ml, n-k);
					l = ipvt[k];
					t = b[l];
					if(l != k) {
						b[l] = b[k];
						b[k] = t;
					}
					DAXPY(lm, t, &abd[m+1+k*lda], 1, &b[k+1], 1);
				}

		/* now solve  u*x = y */

		for(kb=1 ; kb <= n  ; kb++) {
			k = n+1-kb;
			b[k] = b[k]/abd[m+k*lda];
			lm = imin(k, m)-1;
			la = m-lm;
			lb = k-lm;
			t = -b[k];
			DAXPY(lm, t, &abd[la+k*lda], 1, &b[lb], 1);
		}
	}
	return;
}

int dgbsl_(double *abd, int *lda, int *n, int *ml, int *mu, int *ipvt, double *b, int *job)
{
	DGBSL(abd, *lda, *n, *ml, *mu, ipvt, b, *job);
}
