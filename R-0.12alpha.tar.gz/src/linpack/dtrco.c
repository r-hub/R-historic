/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DTRCO estimates the condition of a double triangular
 *     matrix.
 *
 *     On Entry
 *
 *        t       double(ldt,n)
 *                t contains the triangular matrix. the zero
 *                elements of the matrix are not referenced, and
 *                the corresponding elements of the array can be
 *                used to store other information.
 *
 *        ldt     int
 *                ldt is the leading dimension of the array t.
 *
 *        n       int
 *                n is the order of the system.
 *
 *        job     int
 *                = 0         t  is lower triangular.
 *                = nonzero   t  is upper triangular.
 *
 *     On Return
 *
 *        rcond   double*
 *                an estimate of the reciprocal condition of  t .
 *                for the system  t*x = b , relative perturbations
 *                in  t  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond .
 *                if  rcond  is so small that the int expression
 *                           1.0 +rcond .eq. 1.0
 *                is true, then  t  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  t  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z) .
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DTRCO(double *t, int ldt, int n, double *rcond, double *z, int job)
{
	double w, wk, wkm, ek;
	double tnorm, ynorm, s, sm;
	int i1, j, j1, j2, k, kk, l;
	int lower;

	t -= (ldt+1);
	z -= 1;

	lower = (job == 0);

	/* compute 1-norm of t */

	tnorm = 0.0;
	for(j=1 ; j <= n  ; j++) {
		l = j;
		if(lower)
			l = n+1-j;
		i1 = 1;
		if(lower)
			i1 = j;
		tnorm = fmax(tnorm, DASUM(l, &t[i1+j*ldt], 1));
	}

	/* rcond = 1/(norm(t)*(estimate of norm(inverse(t)))) . */
	/* estimate = norm(z)/norm(y) where  t*z = y  and  trans(t)*y = e . */
	/* trans(t)  is the transpose of t . */
	/* the components of  e  are chosen to cause maximum local */
	/* growth in the elements of y . */
	/* the vectors are frequently rescaled to avoid overflow. */

	/* solve trans(t)*y = e */

	ek = 1.0;
	for(j=1 ; j <= n ; j++) 
		z[j] = 0.0;
	for(kk=1 ; kk <= n  ; kk++) {
		k = kk;
		if(lower)
			k = n+1-kk;
		if(z[k] != 0.0)
			ek = fsign(ek, -z[k]);
		if(fabs(ek-z[k]) > fabs(t[k+k*ldt])) {
			s = fabs(t[k+k*ldt])/fabs(ek-z[k]);
			DSCAL(n, s, &z[1], 1);
			ek = s*ek;
		}
		wk = ek-z[k];
		wkm = -ek-z[k];
		s = fabs(wk);
		sm = fabs(wkm);
		if(t[k+k*ldt] == 0.0) {
			wk = 1.0;
			wkm = 1.0;
		}
		else {
			wk = wk/t[k+k*ldt];
			wkm = wkm/t[k+k*ldt];
		}
		if(kk != n) {
			j1 = k+1;
			if(lower)
				j1 = 1;
			j2 = n;
			if(lower)
				j2 = k-1;
			for(j=j1 ; j <= j2  ; j++) {
				sm = sm+fabs(z[j]+wkm*t[k+j*ldt]);
				z[j] = z[j]+wk*t[k+j*ldt];
				s = s+fabs(z[j]);
			}
			if(s < sm) {
				w = wkm-wk;
				wk = wkm;
				for(j=j1 ; j <= j2 ; j++) 
					z[j] = z[j]+w*t[k+j*ldt];
			}
		}
		z[k] = wk;
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);

	ynorm = 1.0;

	/* solve t*z = y */

	for(kk=1 ; kk <= n  ; kk++) {
		k = n+1-kk;
		if(lower)
			k = kk;
		if(fabs(z[k]) > fabs(t[k+k*ldt])) {
			s = fabs(t[k+k*ldt])/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
			ynorm = s*ynorm;
		}
		if(t[k+k*ldt] != 0.0)
			z[k] = z[k]/t[k+k*ldt];
		if(t[k+k*ldt] == 0.0)
			z[k] = 1.0;
		i1 = 1;
		if(lower)
			i1 = k+1;
		if(kk < n) {
			w = -z[k];
			DAXPY(n-kk, w, &t[i1+k*ldt], 1, &z[i1], 1);
		}
	}

	/* make znorm = 1.0 */

	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);
	ynorm = s*ynorm;

	if(tnorm != 0.0)
		*rcond = ynorm/tnorm;
	else
		*rcond = 0.0;
	return;
}

int dtrco_(double *t, int *ldt, int *n, double *rcond, double *z, int *job)
{
	DTRCO(t, *ldt, *n, rcond, z, *job);
}
