/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DTRDI computes the determinant and inverse of a double precision
 *     triangular matrix.
 *
 *     On Entry
 *
 *        t       double(ldt,n)
 *                t contains the triangular matrix. the zero
 *                elements of the matrix are not referenced, and
 *                the corresponding elements of the array can be
 *                used to store other information.
 *
 *        ldt     int
 *                ldt is the leading dimension of the array t.
 *
 *        n       int
 *                n is the order of the system.
 *
 *        job     int
 *                = 010       no det, inverse of lower triangular.
 *                = 011       no det, inverse of upper triangular.
 *                = 100       det, no inverse.
 *                = 110       det, inverse of lower triangular.
 *                = 111       det, inverse of upper triangular.
 *
 *     On Return
 *
 *        t       inverse of original matrix if requested.
 *                otherwise unchanged.
 *
 *        det     double(2)
 *                determinant of original matrix if requested.
 *                otherwise not referenced.
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 .le. fabs(det(1)) .lt. 10.0
 *                or  det(1) .eq. 0.0 .
 *
 *        info    int*
 *                info contains zero if the system is nonsingular
 *                and the inverse is requested.
 *                otherwise info contains the index of
 *                a zero diagonal element of t.
 *
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DTRDI(double *t, int ldt, int n, double *det, int job, int *info)
{
	double temp;
	double ten;
	int i, j, k, kb, km1, kp1;

	t -= (ldt+1);
	det -= 1;

	/* compute determinant */

	if(job/100 != 0) {
		det[1] = 1.0;
		det[2] = 0.0;
		ten = 10.0;
		for(i=1 ; i <= n  ; i++) {
			det[1] = t[i+i*ldt]*det[1];
			if(det[1] == 0.0)
				break;
			while (fabs(det[1]) < 1.0) {
				det[1] = ten*det[1];
				det[2] = det[2]-1.0;
			}
			while (fabs(det[1]) >= ten) {
				det[1] = det[1]/ten;
				det[2] = det[2]+1.0;
			}
		}
	}

	/* compute inverse of upper triangular */

	if((job/10)%10 != 0)
		if((job%10) != 0) {
			for(k=1 ; k <= n  ; k++) {
				*info = k;
				if(t[k+k*ldt] == 0.0)
					return;
				t[k+k*ldt] = 1.0/t[k+k*ldt];
				temp = -t[k+k*ldt];
				DSCAL(k-1, temp, &t[1+k*ldt], 1);
				kp1 = k+1;
				if(n >= kp1)
					for(j=kp1 ; j <= n  ; j++) {
						temp = t[k+j*ldt];
						t[k+j*ldt] = 0.0;
						DAXPY(k, temp, &t[1+k*ldt], 1, &t[1+j*ldt], 1);
					}
			}
			*info = 0;
		}
		else {

			/* compute inverse of lower triangular */

			for(kb=1 ; kb <= n  ; kb++) {
				k = n+1-kb;
				*info = k;
				if(t[k+k*ldt] == 0.0)
					return;
				t[k+k*ldt] = 1.0/t[k+k*ldt];
				temp = -t[k+k*ldt];
				if(k != n)
					DSCAL(n-k, temp, &t[k+1+k*ldt], 1);
				km1 = k-1;
				if(km1 >= 1)
					for(j=1 ; j <= km1  ; j++) {
						temp = t[k+j*ldt];
						t[k+j*ldt] = 0.0;
						DAXPY(n-k+1, temp, &t[k+k*ldt], 1, &t[k+j*ldt], 1);
					}
			}
			*info = 0;
		}
	return;
}

int dtrdi_(double *t, int *ldt, int *n, double *det, int *job, int *info)
{
	DTRDI(t, *ldt, *n, det, *job, info);
}
