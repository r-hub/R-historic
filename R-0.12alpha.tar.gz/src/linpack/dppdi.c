/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DPPDI computes the determinant and inverse
 *     of a double symmetric positive definite matrix
 *     using the factors computed by DPPCO or DPPFA.
 *
 *     On Entry
 *
 *        ap      double(n*(n+1)/2)
 *                the output from DPPCO or DPPFA.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        job     int
 *                = 11   both determinant and inverse.
 *                = 01   inverse only.
 *                = 10   determinant only.
 *
 *     On Return
 *
 *        ap      the upper triangular half of the inverse.
 *                the strict lower triangle is unaltered.
 *
 *        det     double(2)
 *                determinant of original matrix if requested.
 *                otherwise not referenced.
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 <= det(1) < 10.0
 *                or  det(1) == 0.0.
 *
 *     Error Condition
 *
 *        A division by zero will occur if the input factor contains
 *        a zero on the diagonal and the inverse is requested.
 *        It will not occur if the subroutines are called correctly
 *        and if DPOCO or DPOFA has set info == 0.
 *
 *     LINPACK.  This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DPPDI(double *ap, int n, double *det, int job)
{
	int i, ii, j, jj, jm1, j1, k, kj, kk, kp1, k1;
	double s, t;

	ap -= 1;
	det -= 1;

	if(job/10 != 0) {
		det[1] = 1.0;
		det[2] = 0.0;
		s = 10.0;
		ii = 0;
		for(i=1 ; i <= n  ; i++) {
			ii = ii+i;
			det[1] = fsquare(ap[ii])*det[1];
			if(det[1] == 0.0)
				break;
			while (det[1] < 1.0) {
				det[1] = s*det[1];
				det[2] = det[2]-1.0;
			}
			while (det[1] >= s) {
				det[1] = det[1]/s;
				det[2] = det[2]+1.0;
			}
		}
	}

	if(job%10 != 0) {
		kk = 0;
		for(k=1 ; k <= n  ; k++) {
			k1 = kk+1;
			kk = kk+k;
			ap[kk] = 1.0/ap[kk];
			t = -ap[kk];
			DSCAL(k-1, t, &ap[k1], 1);
			kp1 = k+1;
			j1 = kk+1;
			kj = kk+k;
			if(n >= kp1)
				for(j=kp1 ; j <= n  ; j++) {
					t = ap[kj];
					ap[kj] = 0.0;
					DAXPY(k, t, &ap[k1], 1, &ap[j1], 1);
					j1 = j1+j;
					kj = kj+j;
				}
		}

		jj = 0;
		for(j=1 ; j <= n  ; j++) {
			j1 = jj+1;
			jj = jj+j;
			jm1 = j-1;
			k1 = 1;
			kj = j1;
			if(jm1 >= 1)
				for(k=1 ; k <= jm1  ; k++) {
					t = ap[kj];
					DAXPY(k, t, &ap[j1], 1, &ap[k1], 1);
					k1 = k1+k;
					kj = kj+1;
				}
			t = ap[jj];
			DSCAL(j, t, &ap[j1], 1);
		}
	}
	return;
}

int dppdi_(double *ap, int *n, double *det, int *job)
{
	DPPDI(ap, *n, det, *job);
}
