/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSISL solves the double symmetric system
 *     a * x = b
 *     using the factors computed by DSIFA.
 *
 *     On Entry
 *
 *        a       double(lda,n)
 *                the output from DSIFA.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        kpvt    int(n)
 *                the pivot vector from DSIFA.
 *
 *        b       double(n)
 *                the right hand side vector.
 *
 *     On Return
 *
 *        b       the solution vector  x.
 *
 *     Error Condition
 *
 *        a division by zero may occur if  DSICO  has set rcond == 0.0
 *        or  DSIFA  has set info != 0.
 *
 *     To compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           DSIFA(a,lda,n,kpvt,info)
 *           if (info != 0) go to...
 *           do 10 j = 1, p
 *              DSISL(a,lda,n,kpvt,c(1,j))
 *        10 continue
 *
 *     LINPACK. This version dated 08/14/78.
 *     James Bunch, Univ. Calif. San Diego, Argonne Nat. Lab.
 *     C Translation by Ross Ihaka.
 */

#define a(i,j)	a[i+(j)*lda]
#define kpvt(i)	kpvt[i]
#define b(i)	b[i]

void DSISL(double *a, int lda, int n, int *kpvt, double *b)
{
	double ak, akm1, bk, bkm1, denom, temp;
	int k, kp;

	a -= (lda+1);
	kpvt -= 1;
	b -= 1;

	/* loop backward applying the transformations and */
	/* d inverse to b. */

	k = n;
	while (k != 0)
		if(kpvt(k) >= 0) {

			/* 1 x 1 pivot block. */

			if(k != 1) {
				kp = kpvt(k);
				if(kp != k) {

					/* interchange. */

					temp = b(k);
					b(k) = b(kp);
					b(kp) = temp;
				}

				/* apply the transformation. */

				DAXPY(k-1, b(k), &a(1, k), 1, &b(1), 1);
			}

			/* apply d inverse. */

			b(k) = b(k)/a(k, k);
			k = k-1;
		}
		else {

			/* 2 x 2 pivot block. */

			if(k != 2) {
				kp = abs(kpvt(k));
				if(kp != k-1) {

					/* interchange. */

					temp = b(k-1);
					b(k-1) = b(kp);
					b(kp) = temp;
				}

				/* apply the transformation. */

				DAXPY(k-2, b(k), &a(1, k), 1, &b(1), 1);
				DAXPY(k-2, b(k-1), &a(1, k-1), 1, &b(1), 1);
			}

			/* apply d inverse. */

			ak = a(k, k)/a(k-1, k);
			akm1 = a(k-1, k-1)/a(k-1, k);
			bk = b(k)/a(k-1, k);
			bkm1 = b(k-1)/a(k-1, k);
			denom = ak*akm1-1.0;
			b(k) = (akm1*bk-bkm1)/denom;
			b(k-1) = (ak*bkm1-bk)/denom;
			k = k-2;
		}

	/* loop forward applying the transformations. */

	k = 1;
	while (k <= n)
		if(kpvt(k) >= 0) {

			/* 1 x 1 pivot block. */

			if(k != 1) {

				/* apply the transformation. */

				b(k) = b(k)+DDOT(k-1, &a(1, k), 1, &b(1), 1);
				kp = kpvt(k);
				if(kp != k) {

					/* interchange. */

					temp = b(k);
					b(k) = b(kp);
					b(kp) = temp;
				}
			}
			k = k+1;
		}
		else {

			/* 2 x 2 pivot block. */

			if(k != 1) {

				/* apply the transformation. */

				b(k) = b(k)+DDOT(k-1, &a(1, k), 1, &b(1), 1);
				b(k+1) = b(k+1)+DDOT(k-1, &a(1, k+1), 1, &b(1), 1);
				kp = abs(kpvt(k));
				if(kp != k) {

					/* interchange. */

					temp = b(k);
					b(k) = b(kp);
					b(kp) = temp;
				}
			}
			k = k+2;
		}
	return;
}

int dsisl_(double *a, int *lda, int *n, int *kpvt, double *b)
{
	DSISL(a, *lda, *n, kpvt, b);
}
