/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGBFA factors a double band matrix by elimination.
 *
 *     DGBFA is usually called by DGBCO, but it can be called
 *     directly with a saving in time if  rcond  is not needed.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                contains the matrix in band storage.  the columns
 *                of the matrix are stored in the columns of  abd  and
 *                the diagonals of the matrix are stored in rows
 *                ml + 1 through 2 * ml + mu + 1 of  abd.
 *                see the comments below for details.
 *
 *        lda     int
 *                the leading dimension of the array  abd.
 *                lda must be >= 2*ml + mu + 1 .
 *
 *        n       int
 *                the order of the original matrix.
 *
 *        ml      int
 *                number of diagonals below the main diagonal.
 *                0 <= ml < n .
 *
 *        mu      int
 *                number of diagonals above the main diagonal.
 *                0 <= mu < n .
 *                more efficient if  ml <= mu.
 *
 *     On Return
 *
 *        abd     an upper triangular matrix in band storage and
 *                the multipliers which were used to obtain it.
 *                the factorization can be written  a = l*u  where
 *                l  is a product of permutation and unit lower
 *                triangular matrices and  u  is upper triangular.
 *
 *        ipvt    int(n)
 *                an int vector of pivot indices.
 *
 *        info    int*
 *                = 0  normal value.
 *                = k  if  u(k,k) == 0.0.  this is not an error
 *                     condition for this subroutine, but it does
 *                     indicate that dgbsl will divide by zero if
 *                     called.  use  rcond  in DGBCO for a reliable
 *                     indication of singularity.
 *
 *     Band Storage
 *
 *           If  a  is a band matrix, the following program segment
 *           will set up the input.
 *
 *                   ml = (band width below the diagonal)
 *                   mu = (band width above the diagonal)
 *                   m = ml + mu + 1
 *                   do 20 j = 1, n
 *                      i1 = imax(1, j-mu)
 *                      i2 = imin(n, j+ml)
 *                      do 10 i = i1, i2
 *                         k = i - j + m
 *                         abd(k,j) = a(i,j)
 *                10    continue
 *                20 continue
 *
 *           This uses rows  ml+1  through  2*ml+mu+1  of  abd.
 *           in addition, the first  ml  rows in  abd  are used for
 *           elements generated during the triangularization.
 *           the total number of rows needed in  abd  is  2*ml+mu+1 .
 *           the  ml+mu by ml+mu  upper left triangle and the
 *           ml by ml  lower right triangle are not referenced.
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DGBFA(double *abd, int lda, int n, int ml, int mu, int *ipvt, int *info)
{
	double t;
	int i, i0, j, ju, jz, j0, j1, k, kp1, l, lm, m, mm, nm1;

	abd -= (lda+1);
	ipvt -= 1;

	m = ml+mu+1;
	*info = 0;

	/* zero initial fill-in columns */

	j0 = mu+2;
	j1 = imin(n, m)-1;
	if(j1 >= j0)
		for(jz=j0 ; jz <= j1  ; jz++) {
			i0 = m+1-jz;
			for(i=i0 ; i <= ml ; i++) 
				abd[i+jz*lda] = 0.0;
		}
	jz = j1;
	ju = 0;

	/* gaussian elimination with partial pivoting */

	nm1 = n-1;
	if(nm1 >= 1)
		for(k=1 ; k <= nm1  ; k++) {
			kp1 = k+1;

			/* zero next fill-in column */

			jz = jz+1;
			if(jz <= n)
				if(ml >= 1)
					for(i=1 ; i <= ml ; i++) 
						abd[i+jz*lda] = 0.0;

			/* find l = pivot index */

			lm = imin(ml, n-k);
			l = IDAMAX(lm+1, &abd[m+k*lda], 1)+m-1;
			ipvt[k] = l+k-m;

			/* zero pivot implies this column already triangularized */

			if(abd[l+k*lda] == 0.0)
				*info = k;
			else {

				/* interchange if necessary */

				if(l != m) {
					t = abd[l+k*lda];
					abd[l+k*lda] = abd[m+k*lda];
					abd[m+k*lda] = t;
				}

				/* compute multipliers */

				t = -1.0/abd[m+k*lda];
				DSCAL(lm, t, &abd[m+1+k*lda], 1);

				/* row elimination with column indexing */

				ju = imin(imax(ju, mu+ipvt[k]), n);
				mm = m;
				if(ju >= kp1)
					for(j=kp1 ; j <= ju  ; j++) {
						l = l-1;
						mm = mm-1;
						t = abd[l+j*lda];
						if(l != mm) {
							abd[l+j*lda] = abd[mm+j*lda];
							abd[mm+j*lda] = t;
						}
						DAXPY(lm, t, &abd[m+1+k*lda], 1, &abd[mm+1+j*lda], 1);
					}
			}
		}
	ipvt[n] = n;
	if(abd[m+n*lda] == 0.0)
		*info = n;
	return;
}

int dgbfa_(double *abd, int *lda, int *n, int *ml, int *mu, int *ipvt, int *info)
{
	DGBFA(abd, *lda, *n, *ml, *mu, ipvt, info);
}
