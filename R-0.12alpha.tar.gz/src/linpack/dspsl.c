/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSPSL solves the double symmetric system
 *     a * x = b
 *     using the factors computed by DSPFA.
 *
 *     On Entry
 *
 *        ap      double(n*(n+1)/2)
 *                the output from DSPFA.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *        kpvt    int(n)
 *                the pivot vector from DSPFA.
 *
 *        b       double(n)
 *                the right hand side vector.
 *
 *     On Return
 *
 *        b       the solution vector  x.
 *
 *     Error Condition
 *
 *        A division by zero may occur if  DSPCO  has set rcond == 0.0
 *        or  DSPFA  has set info != 0.
 *
 *     To compute  inverse(a) * c  where  c  is a matrix
 *     with  p  columns
 *           DSPFA(ap,n,kpvt,info)
 *           if (info != 0) go to...
 *           do 10 j = 1, p
 *              DSPSL(ap,n,kpvt,c(1,j))
 *        10 continue
 *
 *     LINPACK. This version dated 08/14/78.
 *     James Bunch, Univ. Calif. San Diego, Argonne Nat. Lab.
 *     C Translation by Ross Ihaka.
 */

#define ap(i)	ap[i]
#define kpvt(i)	kpvt[i]
#define b(i)	b[i]

void DSPSL(double *ap, int n, int *kpvt, double *b)
{
	double ak, akm1, bk, bkm1, denom, temp;
	int ik, ikm1, ikp1, k, kk, km1k, km1km1, kp;

	ap -= 1;
	kpvt -= 1;
	b -= 1;

	/* loop backward applying the transformations and */
	/* d inverse to b. */

	k = n;
	ik = (n*(n-1))/2;
	while (k != 0) {
		kk = ik+k;
		if(kpvt(k) >= 0) {

			/* 1 x 1 pivot block. */

			if(k != 1) {
				kp = kpvt(k);
				if(kp != k) {

					/* interchange. */

					temp = b(k);
					b(k) = b(kp);
					b(kp) = temp;
				}

				/* apply the transformation. */

				DAXPY(k-1, b(k), &ap(ik+1), 1, &b(1), 1);
			}

			/* apply d inverse. */

			b(k) = b(k)/ap(kk);
			k = k-1;
			ik = ik-k;
		}
		else {

			/* 2 x 2 pivot block. */

			ikm1 = ik-(k-1);
			if(k != 2) {
				kp = abs(kpvt(k));
				if(kp != k-1) {

					/* interchange. */

					temp = b(k-1);
					b(k-1) = b(kp);
					b(kp) = temp;
				}

				/* apply the transformation. */

				DAXPY(k-2, b(k), &ap(ik+1), 1, &b(1), 1);
				DAXPY(k-2, b(k-1), &ap(ikm1+1), 1, &b(1), 1);
			}

			/* apply d inverse. */

			km1k = ik+k-1;
			kk = ik+k;
			ak = ap(kk)/ap(km1k);
			km1km1 = ikm1+k-1;
			akm1 = ap(km1km1)/ap(km1k);
			bk = b(k)/ap(km1k);
			bkm1 = b(k-1)/ap(km1k);
			denom = ak*akm1-1.0;
			b(k) = (akm1*bk-bkm1)/denom;
			b(k-1) = (ak*bkm1-bk)/denom;
			k = k-2;
			ik = ik-(k+1)-k;
		}
	}

	/* loop forward applying the transformations. */

	k = 1;
	ik = 0;
	while (k <= n)
		if(kpvt(k) >= 0) {

			/* 1 x 1 pivot block. */

			if(k != 1) {

				/* apply the transformation. */

				b(k) = b(k)+DDOT(k-1, &ap(ik+1), 1, &b(1), 1);
				kp = kpvt(k);
				if(kp != k) {

					/* interchange. */

					temp = b(k);
					b(k) = b(kp);
					b(kp) = temp;
				}
			}
			ik = ik+k;
			k = k+1;
		}
		else {

			/* 2 x 2 pivot block. */

			if(k != 1) {

				/* apply the transformation. */

				b(k) = b(k)+DDOT(k-1, &ap(ik+1), 1, &b(1), 1);
				ikp1 = ik+k;
				b(k+1) = b(k+1)+DDOT(k-1, &ap(ikp1+1), 1, &b(1), 1);
				kp = abs(kpvt(k));
				if(kp != k) {

					/* interchange. */

					temp = b(k);
					b(k) = b(kp);
					b(kp) = temp;
				}
			}
			ik = ik+k+k+1;
			k = k+2;
		}
	return;
}

int dspsl_(double *ap, int *n, int *kpvt, double *b)
{
	DSPSL(ap, *n, kpvt, b);
}
