/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DCHDD downdates an augmented cholesky decomposition or the
 *     triangular factor of an augmented qr decomposition.
 *     Specifically, given an upper triangular matrix r of order p,  a
 *     row vector x, a column vector z, and a scalar y, DCHDD
 *     determineds a orthogonal matrix u and a scalar zeta such that
 *
 *                        (r   z )     (rr  zz)
 *                    u * (      )  =  (      ),
 *                        (0 zeta)     ( x   y)
 *
 *     where rr is upper triangular.  If r and z have been obtained
 *     from the factorization of a least squares problem, then
 *     rr and zz are the factors corresponding to the problem
 *     with the observation (x,y) removed.  In this case, if rho
 *     is the norm of the residual vector, then the norm of
 *     the residual vector of the downdated problem is
 *     sqrt(rho**2 - zeta**2). DCHDD will simultaneously downdate
 *     several triplets (z,y,rho) along with r.
 *     For a less terse description of what DCHDD does and how
 *     it may be applied, see the LINPACK guide.
 *
 *     The matrix u is determined as the product u(1)*...*u(p)
 *     where u(i) is a rotation in the (p+1,i)-plane of the
 *     form
 *
 *                       ( c(i)     -s(i)     )
 *                       (                    ).
 *                       ( s(i)       c(i)    )
 *
 *     The rotations are chosen so that c(i) is double.
 *
 *     The user is warned that a given downdating problem may
 *     be impossible to accomplish or may produce
 *     inaccurate results.  For example, this can happen
 *     if x is near a vector whose removal will reduce the
 *     rank of r.  Beware.
 *
 *     On Entry
 *
 *         r      double(ldr,p), where ldr >= p.
 *                r contains the upper triangular matrix
 *                that is to be downdated.  the part of  r
 *                below the diagonal is not referenced.
 *
 *         ldr    int.
 *                ldr is the leading dimension fo the array r.
 *
 *         p      int.
 *                p is the order of the matrix r.
 *
 *         x      double(p).
 *                x contains the row vector that is to
 *                be removed from r.  x is not altered by DCHDD.
 *
 *         z      double(ldz,nz), where ldz >= p.
 *                z is an array of nz p-vectors which
 *                are to be downdated along with r.
 *
 *         ldz    int.
 *                ldz is the leading dimension of the array z.
 *
 *         nz     int.
 *                nz is the number of vectors to be downdated
 *                nz may be zero, in which case z, y, and rho
 *                are not referenced.
 *
 *         y      double(nz).
 *                y contains the scalars for the downdating
 *                of the vectors z.  y is not altered by DCHDD.
 *
 *         rho    double(nz).
 *                rho contains the norms of the residual
 *                vectors that are to be downdated.
 *
 *     On Return
 *
 *         r
 *         z      contain the downdated quantities.
 *         rho
 *
 *         c      double(p).
 *                c contains the cosines of the transforming
 *                rotations.
 *
 *         s      double(p).
 *                s contains the sines of the transforming
 *                rotations.
 *
 *         info   int.
 *                info is set as follows.
 *
 *                   info = 0  if the entire downdating
 *                             was successful.
 *
 *                   info =-1  if r could not be downdated.
 *                             in this case, all quantities
 *                             are left unaltered.
 *
 *                   info = 1  if some rho could not be
 *                             downdated.  the offending rhos are
 *                             set to -1.
 *
 *     LINPACK. This version dated 08/14/78.
 *     G.W. Stewart, University of Maryland, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

#define r(i,j)  r[i+(j)*ldr]
#define z(i,j)  z[i+(j)*ldz]
#define rho(i)  rho[i]
#define x(i)    x[i]
#define y(i)    y[i]
#define c(i)    c[i]
#define s(i)    s[i]

void DCHDD(double *r, int ldr, int p, double *x, double *z, int ldz, int nz, double *y, double *rho, double *c, double *s, int *info)
{
	int i, ii, j;
	double a, alpha, azeta, norm;
	double t, zeta, b, xx;
	float scale;

        r -= (ldr+1);
        z -= (ldz+1);
        rho -= 1;
        x -= 1;
        y -= 1;
        c -= 1;
        s -= 1;

	/* solve the system trans(r)*a = x, placing the result */
	/* in the array s. */

	*info = 0;
	s(1) = x(1)/r(1, 1);
	if(p >= 2)
		for(j=2 ; j <= p  ; j++) {
			s(j) = x(j)-DDOT(j-1, &r(1, j), 1, &s(1), 1);
			s(j) = s(j)/r(j, j);
		}
	norm = DNRM2(p, &s(1), 1);
	if(norm >= 1.0)
		*info = -1;
	else {
		alpha = sqrt(1.0-norm*norm);

		/* determine the transformations. */

		for(ii=1 ; ii <= p  ; ii++) {
			i = p-ii+1;
			scale = alpha+fabs(s(i));
			a = alpha/scale;
			b = s(i)/scale;
			norm = sqrt(a*a+b*b);
			c(i) = a/norm;
			s(i) = b/norm;
			alpha = scale*norm;
		}

		/* apply the transformations to r. */

		for(j=1 ; j <= p  ; j++) {
			xx = 0.0;
			for(ii=1 ; ii <= j  ; ii++) {
				i = j-ii+1;
				t = c(i)*xx+s(i)*r(i, j);
				r(i, j) = c(i)*r(i, j)-s(i)*xx;
				xx = t;
			}
		}

		/* if required, downdate z and rho. */

		if(nz >= 1)
			for(j=1 ; j <= nz  ; j++) {
				zeta = y(j);
				for(i=1 ; i <= p  ; i++) {
					z(i, j) = (z(i, j)-s(i)*zeta)/c(i);
					zeta = c(i)*zeta-s(i)*z(i, j);
				}
				azeta = fabs(zeta);
				if(azeta <= rho(j))
					rho(j) = rho(j)*sqrt(1.0-fsquare(azeta/rho(j)));
				else {
					*info = 1;
					rho(j) = -1.0;
				}
			}
	}
	return;
}

int dchdd_(double *r, int *ldr, int *p, double *x, double *z, int *ldz, int *nz, double *y, double *rho, double *c, double *s, int *info)
{
	DCHDD(r, *ldr, *p, x, z, *ldz, *nz, y, rho, c, s, info);
}
