/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSPDI computes the determinant, inertia and inverse
 *     of a double symmetric matrix using the factors from
 *     DSPFA, where the matrix is stored in packed form.
 *
 *     On Entry
 *
 *        ap      double (n*(n+1)/2)
 *                the output from DSPFA.
 *
 *        n       int
 *                the order of the matrix a.
 *
 *        kpvt    int(n)
 *                the pivot vector from DSPFA.
 *
 *        work    double(n)
 *                work vector.  contents ignored.
 *
 *        job     int
 *                job has the decimal expansion  abc  where
 *                   if  c != 0, the inverse is computed,
 *                   if  b != 0, the determinant is computed,
 *                   if  a != 0, the inertia is computed.
 *
 *                for example, job = 111  gives all three.
 *
 *     On Return
 *
 *        Variables not requested by job are not used.
 *
 *        ap     contains the upper triangle of the inverse of
 *               the original matrix, stored in packed form.
 *               the columns of the upper triangle are stored
 *               sequentially in a one-dimensional array.
 *
 *        det    double(2)
 *               determinant of original matrix.
 *               determinant = det(1) * 10.0**det(2)
 *               with 1.0 <= fabs(det(1)) < 10.0
 *               or det(1) = 0.0.
 *
 *        inert  int(3)
 *               the inertia of the original matrix.
 *               inert(1)  =  number of positive eigenvalues.
 *               inert(2)  =  number of negative eigenvalues.
 *               inert(3)  =  number of zero eigenvalues.
 *
 *     Error Condition
 *
 *        A division by zero will occur if the inverse is requested
 *        and  DSPCO  has set rcond == 0.0
 *        or  DSPFA  has set  info != 0.
 *
 *     LINPACK. This version dated 08/14/78.
 *     James Bunch, Univ. Calif. San Diego, Argonne Nat. Lab.
 *     C Translation by Ross Ihaka.
 */

#define ap(i)		ap[i]
#define work(i)		work[i]
#define det(i)		det[i]
#define inert(i)	inert[i]
#define kpvt(i)		kpvt[i]

void DSPDI(double *ap, int n, int *kpvt, double *det, int *inert, double *work, int job)
{
	double akkp1, temp;
	double ten, d, t, ak, akp1;
	int ij, ik, ikp1, iks, j, jb, jk, jkp1;
	int k, kk, kkp1, km1, ks, ksj, kskp1, kstep;
	int noinv, nodet, noert;

	ap -= 1;
	work -= 1;
	det -= 1;
	inert -= 1;
	kpvt -= 1;

	noinv = (job % 10) == 0;
	nodet = (job % 100)/10 == 0;
	noert = (job % 1000)/100 == 0;

	if(!nodet || !noert) {
		if(!noert) {
			inert(1) = 0;
			inert(2) = 0;
			inert(3) = 0;
		}
		if(!nodet) {
			det(1) = 1.0;
			det(2) = 0.0;
			ten = 10.0;
		}
		t = 0.0;
		ik = 0;
		for(k=1 ; k <= n  ; k++) {
			kk = ik+k;
			d = ap(kk);

			/* check if 1 by 1 */

			if(kpvt(k) <= 0)

				/* 2 by 2 block */
				/* use det (d  s)  =  (d/t * c - t) * t,  t = fabs(s) */
				/* (s  c) */
				/* to avoid underflow/overflow troubles. */
				/* take two passes through scaling.  use  t  for flag. */

				if(t != 0.0) {
					d = t;
					t = 0.0;
				}
				else {
					ikp1 = ik+k;
					kkp1 = ikp1+k;
					t = fabs(ap(kkp1));
					d = (d/t)*ap(kkp1+1)-t;
				}

			if(!noert) {
				if(d > 0.0)
					inert(1) = inert(1)+1;
				if(d < 0.0)
					inert(2) = inert(2)+1;
				if(d == 0.0)
					inert(3) = inert(3)+1;
			}

			if(!nodet) {
				det(1) = d*det(1);
				if(det(1) != 0.0) {
					while (fabs(det(1)) < 1.0) {
						det(1) = ten*det(1);
						det(2) = det(2)-1.0;
					}
					while (fabs(det(1)) >= ten) {
						det(1) = det(1)/ten;
						det(2) = det(2)+1.0;
					}
				}
			}
			ik = ik+k;
		}
	}

	/* compute inverse(a) */

	if(!noinv) {
		k = 1;
		ik = 0;
		while (k <= n) {
			km1 = k-1;
			kk = ik+k;
			ikp1 = ik+k;
			kkp1 = ikp1+k;
			if(kpvt(k) >= 0) {

				/* 1 by 1 */

				ap(kk) = 1.0/ap(kk);
				if(km1 >= 1) {
					DCOPY(km1, &ap(ik+1), 1, &work(1), 1);
					ij = 0;
					for(j=1 ; j <= km1  ; j++) {
						jk = ik+j;
						ap(jk) = DDOT(j, &ap(ij+1), 1, &work(1), 1);
						DAXPY(j-1, work(j), &ap(ij+1), 1, &ap(ik+1), 1);
						ij = ij+j;
					}
					ap(kk) = ap(kk)+DDOT(km1, &work(1), 1, &ap(ik+1), 1);
				}
				kstep = 1;
			}
			else {

				/* 2 by 2 */

				t = fabs(ap(kkp1));
				ak = ap(kk)/t;
				akp1 = ap(kkp1+1)/t;
				akkp1 = ap(kkp1)/t;
				d = t*(ak*akp1-1.0);
				ap(kk) = akp1/d;
				ap(kkp1+1) = ak/d;
				ap(kkp1) = -akkp1/d;
				if(km1 >= 1) {
					DCOPY(km1, &ap(ikp1+1), 1, &work(1), 1);
					ij = 0;
					for(j=1 ; j <= km1  ; j++) {
						jkp1 = ikp1+j;
						ap(jkp1) = DDOT(j, &ap(ij+1), 1, &work(1), 1);
						DAXPY(j-1, work(j), &ap(ij+1), 1, &ap(ikp1+1), 1);
						ij = ij+j;
					}
					ap(kkp1+1) = ap(kkp1+1)+DDOT(km1, &work(1), 1, &ap(ikp1+1), 1);
					ap(kkp1) = ap(kkp1)+DDOT(km1, &ap(ik+1), 1, &ap(ikp1+1), 1);
					DCOPY(km1, &ap(ik+1), 1, &work(1), 1);
					ij = 0;
					for(j=1 ; j <= km1  ; j++) {
						jk = ik+j;
						ap(jk) = DDOT(j, &ap(ij+1), 1, &work(1), 1);
						DAXPY(j-1, work(j), &ap(ij+1), 1, &ap(ik+1), 1);
						ij = ij+j;
					}
					ap(kk) = ap(kk)+DDOT(km1, &work(1), 1, &ap(ik+1), 1);
				}
				kstep = 2;
			}

			/* swap */

			ks = abs(kpvt(k));
			if(ks != k) {
				iks = (ks*(ks-1))/2;
				DSWAP(ks, &ap(iks+1), 1, &ap(ik+1), 1);
				ksj = ik+ks;
				for(jb=ks ; jb <= k  ; jb++) {
					j = k+ks-jb;
					jk = ik+j;
					temp = ap(jk);
					ap(jk) = ap(ksj);
					ap(ksj) = temp;
					ksj = ksj-(j-1);
				}
				if(kstep != 1) {
					kskp1 = ikp1+ks;
					temp = ap(kskp1);
					ap(kskp1) = ap(kkp1);
					ap(kkp1) = temp;
				}
			}
			ik = ik+k;
			if(kstep == 2)
				ik = ik+k+1;
			k = k+kstep;
		}
	}
	return;
}

int dspdi_(double *ap, int *n, int *kpvt, double *det, int *inert, double *work, int *job)
{
	DSPDI(ap, *n, kpvt, det, inert, work, *job);
}
