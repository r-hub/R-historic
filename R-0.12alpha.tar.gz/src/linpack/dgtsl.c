/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGTSL given a general tridiagonal matrix and a right hand
 *     side will find the solution.
 *
 *     On Entry
 *
 *        n       int
 *                is the order of the tridiagonal matrix.
 *
 *        c       double(n)
 *                is the subdiagonal of the tridiagonal matrix.
 *                c(2) through c(n) should contain the subdiagonal.
 *                on output c is destroyed.
 *
 *        d       double(n)
 *                is the diagonal of the tridiagonal matrix.
 *                on output d is destroyed.
 *
 *        e       double(n)
 *                is the superdiagonal of the tridiagonal matrix.
 *                e(1) through e(n-1) should contain the superdiagonal.
 *                on output e is destroyed.
 *
 *        b       double(n)
 *                is the right hand side vector.
 *
 *     On Return
 *
 *        b       is the solution vector.
 *
 *        info    int
 *                = 0 normal value.
 *                = k if the k-th element of the diagonal becomes
 *                    exactly zero.  the subroutine returns when
 *                    this is detected.
 *
 *     LINPACK. This version dated 08/14/78.
 *     Jack Dongarra, Argonne National Laboratory.
 *     C Translation by Ross Ihaka.
 */

#define c(i)	c[i]
#define d(i)	d[i]
#define e(i)	e[i]
#define b(i)	b[i]

void DGTSL(int n, double *c, double *d, double *e, double *b, int *info)
{
	int k, kb, kp1, nm1, nm2;
	double t;

	c -= 1;
	d -= 1;
	e -= 1;
	b -= 1;

	*info = 0;
	c(1) = d(1);
	nm1 = n-1;
	if(nm1 >= 1) {
		d(1) = e(1);
		e(1) = 0.0;
		e(n) = 0.0;

		for(k=1 ; k <= nm1  ; k++) {
			kp1 = k+1;

			/* find the largest of the two rows */

			if(fabs(c(kp1)) >= fabs(c(k))) {

				/* interchange row */

				t = c(kp1);
				c(kp1) = c(k);
				c(k) = t;
				t = d(kp1);
				d(kp1) = d(k);
				d(k) = t;
				t = e(kp1);
				e(kp1) = e(k);
				e(k) = t;
				t = b(kp1);
				b(kp1) = b(k);
				b(k) = t;
			}

			/* zero elements */

			if(c(k) == 0.0) {
				*info = k;
				return;
			}
			t = -c(kp1)/c(k);
			c(kp1) = d(kp1)+t*d(k);
			d(kp1) = e(kp1)+t*e(k);
			e(kp1) = 0.0;
			b(kp1) = b(kp1)+t*b(k);
		}
	}
	if(c(n) == 0.0)
		*info = n;
	else {

		/* back solve */

		nm2 = n-2;
		b(n) = b(n)/c(n);
		if(n != 1) {
			b(nm1) = (b(nm1)-d(nm1)*b(n))/c(nm1);
			if(nm2 >= 1)
				for(kb=1 ; kb <= nm2  ; kb++) {
					k = nm2-kb+1;
					b(k) = (b(k)-d(k)*b(k+1)-e(k)*b(k+2))/c(k);
				}
		}
	}
	return;
}

int dgtsl_(int *n, double *c, double *d, double *e, double *b, int *info)
{
	DGTSL(*n, c, d, e, b, info);
}
