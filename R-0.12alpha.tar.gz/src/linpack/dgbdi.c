/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGBDI computes the determinant of a band matrix
 *     using the factors computed by DGBCO or DGBFA.
 *     if the inverse is needed, use DGBSL  n  times.
 *
 *     On Entry
 *
 *        abd     double(lda, n)
 *                the output from DGBCO or DGBFA.
 *
 *        lda     int
 *                the leading dimension of the array  abd .
 *
 *        n       int
 *                the order of the original matrix.
 *
 *        ml      int
 *                number of diagonals below the main diagonal.
 *
 *        mu      int
 *                number of diagonals above the main diagonal.
 *
 *        ipvt    int(n)
 *                the pivot vector from DGBCO or DGBFA.
 *
 *     On Return
 *
 *        det     double(2)
 *                determinant of original matrix.
 *                determinant = det(1) * 10.0**det(2)
 *                with  1.0 <= fabs(det(1)) < 10.0
 *                or  det(1) = 0.0.
 *
 *     LINPACK. This version dated 08/14/78 .
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C Translation by Ross Ihaka.
 */

void DGBDI(double *abd, int lda, int n, int ml, int mu, int *ipvt, double *det)
{
	double ten;
	int i, m;

	abd -= (lda+1);
	ipvt -= 1;
	det -= 1;

	m = ml+mu+1;
	det[1] = 1.0;
	det[2] = 0.0;
	ten = 10.0;
	for(i=1 ; i <= n  ; i++) {
		if(ipvt[i] != i)
			det[1] = -det[1];
		det[1] = abd[m+i*lda]*det[1];
		if(det[1] == 0.0)
			break;
		while (fabs(det[1]) < 1.0) {
			det[1] = ten*det[1];
			det[2] = det[2]-1.0;
		}
		while (fabs(det[1]) >= ten) {
			det[1] = det[1]/ten;
			det[2] = det[2]+1.0;
		}
	}
	return;
}

int dgbdi_(double *abd, int *lda, int *n, int *ml, int *mu, int *ipvt, double *det)
{
	DGBDI(abd, *lda, *n, *ml, *mu, ipvt, det);
}
