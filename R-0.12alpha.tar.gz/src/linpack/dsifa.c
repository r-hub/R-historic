/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DSIFA factors a double symmetric matrix by elimination
 *     with symmetric pivoting.
 *
 *     To solve  a*x = b, follow DSIFA by DSISL.
 *     To compute  inverse(a)*c, follow DSIFA by DSISL.
 *     To compute  determinant(a), follow DSIFA by DSIDI.
 *     To compute  inertia(a), follow DSIFA by DSIDI.
 *     To compute  inverse(a), follow DSIFA by DSIDI.
 *
 *     On Entry
 *
 *        a       double(lda,n)
 *                the symmetric matrix to be factored.
 *                only the diagonal and upper triangle are used.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     On Return
 *
 *        a       a block diagonal matrix and the multipliers which
 *                were used to obtain it.
 *                the factorization can be written  a = u*d*trans(u)
 *                where  u  is a product of permutation and unit
 *                upper triangular matrices, trans(u) is the
 *                transpose of  u, and  d  is block diagonal
 *                with 1 by 1 and 2 by 2 blocks.
 *
 *        kpvt    int(n)
 *                an int vector of pivot indices.
 *
 *        info    int
 *                = 0  normal value.
 *                = k  if the k-th pivot block is singular. this is
 *                     not an error condition for this subroutine,
 *                     but it does indicate that DSISL or DSIDI may
 *                     divide by zero if called.
 *
 *     LINPACK. This version dated 08/14/78.
 *     James Bunch, Univ. Calif. San Diego, Argonne Nat. Lab.
 *     C Translation by Ross Ihaka.
 */

#define a(i,j)		a[i+(j)*lda]
#define kpvt(i)		kpvt[i]

#define FALSE		0
#define TRUE		1

void DSIFA(double *a, int lda, int n, int *kpvt, int *info)
{
	double ak, akm1, bk, bkm1, denom, mulk, mulkm1, t;
	double absakk, alpha, colmax, rowmax;
	int imax, imaxp1, j, jj, jmax, k, km1, km2, kstep;
	int swap;

	a -= (lda+1);
	kpvt -= 1;

	/* initialize */

	/* alpha is used in choosing pivot block size. */

	alpha = (1.0+sqrt(17.0))/8.0;

	*info = 0;

	/* main loop on k, which goes from n to 1. */

	k = n;
	for(;;) {

		/* leave the loop if k=0 or k=1. */

		if(k == 0)
			return;
		if(k <= 1)
			break;

		/* this section of code determines the kind of */
		/* elimination to be performed.  when it is completed, */
		/* kstep will be set to the size of the pivot block, and */
		/* swap will be set toTRUE if an interchange is */
		/* required. */

		km1 = k-1;
		absakk = fabs(a(k, k));

		/* determine the largest off-diagonal element in */
		/* column k. */

		imax = IDAMAX(k-1, &a(1, k), 1);
		colmax = fabs(a(imax, k));
		if(absakk >= alpha*colmax) {
			kstep = 1;
			swap =FALSE;
		}
		else {

			/* determine the largest off-diagonal element in */
			/* row imax. */

			rowmax = 0.0;
			imaxp1 = imax+1;
			for(j=imaxp1 ; j <= k ; j++) 
				rowmax = fmax(rowmax, fabs(a(imax, j)));
			if(imax != 1) {
				jmax = IDAMAX(imax-1, &a(1, imax), 1);
				rowmax = fmax(rowmax, fabs(a(jmax, imax)));
			}
			if(fabs(a(imax, imax)) >= alpha*rowmax) {
				kstep = 1;
				swap =TRUE;
			}
			else if(absakk < alpha*colmax*colmax/rowmax) {
				kstep = 2;
				swap = (imax != km1);
			}
			else {
				kstep = 1;
				swap =FALSE;
			}
		}
		if(fmax(absakk, colmax) == 0.0) {

			/* column k is zero.  set info and iterate the loop. */

			kpvt(k) = k;
			*info = k;
		}
		else if(kstep != 2) {

			/* 1 x 1 pivot block. */

			if(swap) {

				/* perform an interchange. */

				DSWAP(imax, &a(1, imax), 1, &a(1, k), 1);
				for(jj=imax ; jj <= k  ; jj++) {
					j = k+imax-jj;
					t = a(j, k);
					a(j, k) = a(imax, j);
					a(imax, j) = t;
				}
			}

			/* perform the elimination. */

			for(jj=1 ; jj <= km1  ; jj++) {
				j = k-jj;
				mulk = -a(j, k)/a(k, k);
				t = mulk;
				DAXPY(j, t, &a(1, k), 1, &a(1, j), 1);
				a(j, k) = mulk;
			}

			/* set the pivot array. */

			kpvt(k) = k;
			if(swap)
				kpvt(k) = imax;
		}
		else {

			/* 2 x 2 pivot block. */

			if(swap) {

				/* perform an interchange. */

				DSWAP(imax, &a(1, imax), 1, &a(1, k-1), 1);
				for(jj=imax ; jj <= km1  ; jj++) {
					j = km1+imax-jj;
					t = a(j, k-1);
					a(j, k-1) = a(imax, j);
					a(imax, j) = t;
				}
				t = a(k-1, k);
				a(k-1, k) = a(imax, k);
				a(imax, k) = t;
			}

			/* perform the elimination. */

			km2 = k-2;
			if(km2 != 0) {
				ak = a(k, k)/a(k-1, k);
				akm1 = a(k-1, k-1)/a(k-1, k);
				denom = 1.0-ak*akm1;
				for(jj=1 ; jj <= km2  ; jj++) {
					j = km1-jj;
					bk = a(j, k)/a(k-1, k);
					bkm1 = a(j, k-1)/a(k-1, k);
					mulk = (akm1*bk-bkm1)/denom;
					mulkm1 = (ak*bkm1-bk)/denom;
					t = mulk;
					DAXPY(j, t, &a(1, k), 1, &a(1, j), 1);
					t = mulkm1;
					DAXPY(j, t, &a(1, k-1), 1, &a(1, j), 1);
					a(j, k) = mulk;
					a(j, k-1) = mulkm1;
				}
			}

			/* set the pivot array. */

			kpvt(k) = 1-k;
			if(swap)
				kpvt(k) = -imax;
			kpvt(k-1) = kpvt(k);
		}
		k = k-kstep;
	}
	kpvt(1) = 1;
	if(a(1, 1) == 0.0)
		*info = 1;
	return;
}

int dsifa_(double *a, int *lda, int *n, int *kpvt, int *info)
{
	DSIFA(a, *lda, *n, kpvt, info);
}
