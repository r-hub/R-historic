/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Linpack.h>

/*
 *     DGECO factors a double matrix by gaussian elimination
 *     and estimates the condition of the matrix.
 *
 *     If  rcond  is not needed, DGEFA is slightly faster.
 *     To solve  a*x = b , follow DGECO by DGESL.
 *     To compute  inverse(a)*c , follow DGECO by DGESL.
 *     To compute  determinant(a) , follow DGECO by DGEDI.
 *     To compute  inverse(a) , follow DGECO by DGEDI.
 *
 *     On Entry
 *
 *        a       double(lda, n)
 *                the matrix to be factored.
 *
 *        lda     int
 *                the leading dimension of the array  a.
 *
 *        n       int
 *                the order of the matrix  a.
 *
 *     On Return
 *
 *        a       an upper triangular matrix and the multipliers
 *                which were used to obtain it.
 *                the factorization can be written  a = l*u  where
 *                l  is a product of permutation and unit lower
 *                triangular matrices and  u  is upper triangular.
 *
 *        ipvt    int(n)
 *                an int vector of pivot indices.
 *
 *        rcond   double
 *                an estimate of the reciprocal condition of  a.
 *                for the system  a*x = b , relative perturbations
 *                in  a  and  b  of size  epsilon  may cause
 *                relative perturbations in  x  of size  epsilon/rcond.
 *                if  rcond  is so small that the int expression
 *                           1.0 + rcond == 1.0
 *                is true, then  a  may be singular to working
 *                precision.  in particular,  rcond  is zero  if
 *                exact singularity is detected or the estimate
 *                underflows.
 *
 *        z       double(n)
 *                a work vector whose contents are usually unimportant.
 *                if  a  is close to a singular matrix, then  z  is
 *                an approximate null vector in the sense that
 *                norm(a*z) = rcond*norm(a)*norm(z).
 *
 *     LINPACK. This version dated 08/14/78.
 *     Cleve Moler, University of New Mexico, Argonne National Lab.
 *     C translation by Ross Ihaka.
 *
 */

void DGECO(double *a, int lda, int n, int *ipvt, double *rcond, double *z)
{
	double ek, t, wk, wkm;
	double anorm, s, sm, ynorm;
	int info, j, k, kb, kp1, l;

	a -= (lda+1);
	ipvt -= 1;
	z -= 1;
	
	/* compute 1-norm of a */

	anorm = 0.0;
	for(j=1 ; j <= n ; j++) 
		anorm = fmax(anorm, DASUM(n, &a[1+j*lda], 1));

	/* factor */

	DGEFA(&a[lda+1], lda, n, &ipvt[1], &info);

	/* rcond = 1/(norm(a)*(estimate of norm(inverse(a)))). */
	/* estimate = norm(z)/norm(y) where  a*z = y  and  trans(a)*y = e. */
	/* trans(a)  is the transpose of a.  the components of  e  are */
	/* chosen to cause maximum local growth in the elements of w  where */
	/* trans(u)*w = e.  the vectors are frequently rescaled to avoid */
	/* overflow. */

	/* solve trans(u)*w = e */

	ek = 1.0;
	for(j=1 ; j <= n ; j++) 
		z[j] = 0.0;
	for(k=1 ; k <= n  ; k++) {
		if(z[k] != 0.0)
			ek = fsign(ek, -z[k]);
		if(fabs(ek-z[k]) > fabs(a[k+k*lda])) {
			s = fabs(a[k+k*lda])/fabs(ek-z[k]);
			DSCAL(n, s, &z[1], 1);
			ek = s*ek;
		}
		wk = ek-z[k];
		wkm = -ek-z[k];
		s = fabs(wk);
		sm = fabs(wkm);
		if(a[k+k*lda] == 0.0) {
			wk = 1.0;
			wkm = 1.0;
		}
		else {
			wk = wk/a[k+k*lda];
			wkm = wkm/a[k+k*lda];
		}
		kp1 = k+1;
		if(kp1 <= n) {
			for(j=kp1 ; j <= n  ; j++) {
				sm = sm+fabs(z[j]+wkm*a[k+j*lda]);
				z[j] = z[j]+wk*a[k+j*lda];
				s = s+fabs(z[j]);
			}
			if(s < sm) {
				t = wkm-wk;
				wk = wkm;
				for(j=kp1 ; j <= n ; j++) 
					z[j] = z[j]+t*a[k+j*lda];
			}
		}
		z[k] = wk;
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);

	/* solve trans(l)*y = w */

	for(kb=1 ; kb <= n  ; kb++) {
		k = n+1-kb;
		if(k < n)
			z[k] = z[k]+DDOT(n-k, &a[k+1+k*lda], 1, &z[k+1], 1);
		if(fabs(z[k]) > 1.0) {
			s = 1.0/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
		}
		l = ipvt[k];
		t = z[l];
		z[l] = z[k];
		z[k] = t;
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);

	ynorm = 1.0;

	/* solve l*v = y */

	for(k=1 ; k <= n  ; k++) {
		l = ipvt[k];
		t = z[l];
		z[l] = z[k];
		z[k] = t;
		if(k < n)
			DAXPY(n-k, t, &a[k+1+k*lda], 1, &z[k+1], 1);
		if(fabs(z[k]) > 1.0) {
			s = 1.0/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
			ynorm = s*ynorm;
		}
	}
	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);
	ynorm = s*ynorm;

	/* solve  u*z = v */

	for(kb=1 ; kb <= n  ; kb++) {
		k = n+1-kb;
		if(fabs(z[k]) > fabs(a[k+k*lda])) {
			s = fabs(a[k+k*lda])/fabs(z[k]);
			DSCAL(n, s, &z[1], 1);
			ynorm = s*ynorm;
		}
		if(a[k+k*lda] != 0.0)
			z[k] = z[k]/a[k+k*lda];
		if(a[k+k*lda] == 0.0)
			z[k] = 1.0;
		t = -z[k];
		DAXPY(k-1, t, &a[1+k*lda], 1, &z[1], 1);
	}

	/* make znorm = 1.0 */

	s = 1.0/DASUM(n, &z[1], 1);
	DSCAL(n, s, &z[1], 1);
	ynorm = s*ynorm;

	if(anorm != 0.0)
		*rcond = ynorm/anorm;
	else
		*rcond = 0.0;
	return;
}

int dgeco_(double *a, int *lda, int *n, int *ipvt, double *rcond, double *z)
{
	DGECO(a, *lda, *n, ipvt, rcond, z);
}
