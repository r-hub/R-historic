/*
 *  Linpack-in-C: Software for Numerical Linear Algebra.
 *  Copyright (C) 1996 Ross Ihaka
 *
 *  This library is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <Blas.h>

double DASUM(int n, double *dx, int incx)
{
	double sum;
	int i;
	if (n <= 0) return 0.0;
	sum = 0.0;
	if (incx < 0) dx += (- n + 1) * incx;
	for (i=0; i<n; i++) {
		sum += fabs(*dx);
		dx += incx;
	}
	return sum;
}

void DAXPY(int n, double da, double *dx, int incx, double *dy, int incy)
{
	int i, ix, iy;
	if (n <= 0 || da == 0.0) return;
	if (incx < 0) dx += (- n + 1) * incx;
	if (incy < 0) dy += (- n + 1) * incy;
	for (i=0; i<n; i++) {
		*dy += da * *dx;
		dx += incx;
		dy += incy;
	}
}

void DCOPY(int n, double *dx, int incx, double *dy, int incy)
{
	int i;
	if (n <= 0) return;
	if (incx < 0) dx += (- n + 1) * incx;
	if (incy < 0) dy += (- n + 1) * incy;
	for (i=0; i<n; i++) {
		*dy = *dx;
		dx += incx;
		dy += incy;
	}
}

double DDOT(int n, double *dx, int incx, double *dy, int incy)
{
	double sum;
	int i;
	if (n <= 0) return 0.0;
	sum = 0.0;
	if (incx < 0) dx += (- n + 1) * incx;
	if (incy < 0) dy += (- n + 1) * incy;

	for (i=1; i<=n; i++) {
		sum += (*dx) * (*dy);
		dx += incx;
		dy += incy;
	}
	return sum;
}

double DMACH(int job)
{
	double eps, tiny, huge, s;
	eps = 1.0;
	do {
		eps = eps / 2.0;
		s = 1.0 + eps;
	}
	while(s > 1.0);
	eps = 2.0 * eps;
	s = 1.0;
	do {
		tiny = s;
		s = s / 16.0;
	}
	while(s * 1.0 != 0.0);
	tiny = (tiny / eps) * 100.0;
	huge = 1.0 / tiny;

	if (job==1) return eps;
	if (job==2) return tiny;
	if (job==3) return huge;
	return 0.0;
}

#ifdef NEWER_DNRM2

/* This version of DNRM2 is that distributed with LAPACK */
/* It is marginally faster than the one distributed distributed */
/* with LINPACK, but it is much less accurate.  For that reason */
/* I have continued with the older (uglier) version below. */

double DNRM2(int n, double *dx, int incx)
{
	double absxi, scale, ssq;
	int i;
	if (n < 1 || incx == 0) return 0.0;
	if (n == 1) return fabs(*dx);
	if (incx < 0) dx += (- n + 1) * incx;
	scale = 0.0;
	ssq = 1.0;
	for(i=0 ; i<n ; i++) {
		if (*dx != 0.0) {
			absxi = fabs(*dx);
			if (scale < absxi) {
				ssq = ssq * fsquare(scale/absxi) + 1.0;
				scale = absxi;
			}
			else {
				ssq += fsquare(absxi/scale);
			}
		}
		dx += incx;
	}
	return scale * sqrt(ssq);
}

#else

/*
 *     euclidean norm of the n-vector stored in dx() with storage
 *     increment incx .
 *     if    n .le. 0 return with result = 0.
 *     if n .ge. 1 then incx must be .ge. 1
 *
 *           c.l.lawson, 1978 jan 08
 *     modified to correct problem with negative increment, 8/21/90.
 *     modified to correct failure to update ix, 1/25/92.
 *
 *     four phase method     using two built-in constants that are
 *     hopefully applicable to all machines.
 *         cutlo = maximum of  dsqrt(u/eps)  over all known machines.
 *         cuthi = minimum of  dsqrt(v)      over all known machines.
 *     where
 *         eps = smallest no. such that eps + 1. .gt. 1.
 *         u   = smallest positive no.   (underflow limit)
 *         v   = largest  no.            (overflow  limit)
 *
 *     brief outline of algorithm..
 *
 *     phase 1    scans zero components.
 *     move to phase 2 when a component is nonzero and .le. cutlo
 *     move to phase 3 when a component is .gt. cutlo
 *     move to phase 4 when a component is .ge. cuthi/m
 *     where m = n for x() real and m = 2*n for complex.
 *
 *     values for cutlo and cuthi..
 *     from the environmental parameters listed in the imsl converter
 *     document the limiting values are as follows..
 *     cutlo, s.p.   u/eps = 2**(-102) for  honeywell.  close seconds are
 *                   univac and dec at 2**(-103)
 *                   thus cutlo = 2**(-51) = 4.44089e-16
 *     cuthi, s.p.   v = 2**127 for univac, honeywell, and dec.
 *                   thus cuthi = 2**(63.5) = 1.30438e19
 *     cutlo, d.p.   u/eps = 2**(-67) for honeywell and dec.
 *                   thus cutlo = 2**(-33.5) = 8.23181d-11
 *     cuthi, d.p.   same as s.p.  cuthi = 1.30438d19
 *     data cutlo, cuthi / 8.232d-11,  1.304d19 /
 *     data cutlo, cuthi / 4.441e-16,  1.304e19 /
 */

static double zero = 0.0;
static double one = 1.0;
static double cutlo = 8.232e-11;
static double cuthi = 1.304e+19;

double DNRM2 (int n, double *dx, int incx)
{
	int i, ix, j, next;
	double hitest, sum, xmax, tmp;

	if (n < 1 || incx == 0) return zero;
	if (n == 1) return fabs(*dx);
	if (incx < 0) dx += (- n + 1) * incx;
	sum = zero;
	ix = 0;

		/* phase 1 - scan zeros */
		/* inspection only, no arithmetic */

	while(*dx == zero) {
		/* sum += *dx */
		dx += incx;
		ix += 1;
		if(ix == n) return zero;
	}

		/* phase 2 - sum is small */
		/* scale to avoid destructive underflow */

	xmax = fabs(*dx);
	while(fabs(*dx) <= cutlo) {
		if(fabs(*dx) <= xmax ) {
			tmp = *dx / xmax;
			sum += tmp * tmp;
		}
		else {
			tmp = xmax / *dx;
			sum = one + sum * tmp * tmp;
			xmax = fabs(*dx);
		}
		dx += incx;
		ix += 1;
		if(ix == n) return xmax * sqrt(sum);
	}

		/* phase 3 - sum is intermediate */
		/* calculations are unscaled. */

	sum = (sum * xmax) * xmax;
	hitest = cuthi/n;

	while(fabs(*dx) < hitest) {
		sum += (*dx) * (*dx);
		dx += incx;
		ix += 1;
		if(ix == n) return sqrt(sum);
	}

		/* phase 4 - sum is large */
		/* scale to avoid overflow */

	sum = (sum / *dx) / *dx;
	xmax = fabs(*dx);

	for(;;) {
		if(fabs(*dx) <= xmax ) {
			tmp = *dx / xmax;
			sum += tmp * tmp;
		}
		else {
			tmp = xmax / *dx;
			sum = one + sum * tmp * tmp;
			xmax = fabs(*dx);
		}
		dx += incx;
		ix += 1;
		if(ix == n) break;
	}
	return xmax * sqrt(sum);
}
#endif

void DROT(int n, double *dx, int incx, double *dy, int incy, double c, double s)
{
	double dtemp;
	int i;
	if (n <= 0) return;
	if (incx < 0) dx += (- n + 1) * incx;
	if (incy < 0) dy += (- n + 1) * incy;
	for (i=0; i<n; i++) {
		dtemp  = c * (*dx) + s * (*dy);
		*dy    = c * (*dy) - s * (*dx);
		*dx    = dtemp;
		dx += incx;
		dy += incy;
	}
}

void DROTG(double *da, double *db, double *c, double *s)
{
	double r, scale, z, roe;

	roe = *db;
	if (fabs(*da) > fabs(*db)) {
		roe = *da;
	}
	scale = fabs(*da) + fabs(*db);
	if (scale == 0.0) {
		*c = 1.0;
		*s = 0.0;
		r = 0.0;
	}
	else {
		r = scale * sqrt(fsquare(*da / scale) + fsquare(*db / scale));
		r = fsign(1.0, roe) * r;
		*c = *da / r;
		*s = *db / r;
	}
	z = *s;
	if (fabs(*c) > 0.0 && fabs(*c) <= *s) {
		z = 1.0 / *c;
	}
	*da = r;
	*db = z;
}

void DSCAL(int n, double da, double *dx, int incx)
{
	int i;
	if (n <= 0) return;
	if (incx < 0) dx += (- n + 1) * incx;
	for (i=0; i<n; i++) {
		*dx = da * (*dx);
		dx += incx;
	}
}

void DSWAP(int n, double *dx, int incx, double *dy, int incy)
{
	double dtemp;
	int i;
	if (n <= 0) return;
	if (incx < 0) dx += (- n + 1) * incx;
	if (incy < 0) dy += (- n + 1) * incy;
	for (i=1; i<=n; i++) {
		dtemp = *dx;
		*dx = *dy;
		*dy = dtemp;
		dx += incx;
		dy += incy;
	}
}

int IDAMAX(int n, double *dx, int incx)
{
	int i, imax, ix;
	double xmax;
	if (n < 1) return 0;
	if (n == 1) return 1;
	if (incx < 0) dx += (- n + 1) * incx;
	imax = 0;
	xmax = fabs(*dx);
	dx += incx;
	for (i=1; i<n; i++) {
		if (fabs(*dx) > xmax) {
			imax = i;
			xmax = fabs(*dx);
		}
		dx += incx;
	}
	return imax+1;
}
