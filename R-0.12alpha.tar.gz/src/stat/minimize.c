/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Mathlib.h"
#include "Platform.h"
#include "Defn.h"

static void prtstp(int code)
{
	switch(code) {
	case 0:
  		Rprintf("Step of maximum length (STEPMX) taken\n");
		break;
	case 1:
		Rprintf("Relative gradient close to zero.\n");
		Rprintf("Current iterate is probably solution.\n");
		break;
	case 2:
		Rprintf("Successive iterates within tolerance.\n");
		Rprintf("Current iterate is probably solution.\n");
		break;
	case 3:
		Rprintf("Last global step failed to locate a point lower than x.\n");
		Rprintf("Either x is an approximate local minimum of the function\n");
		Rprintf("or steptl or gradtl is too small.\n");
		break;
	case 4:
		Rprintf("Iteration limit exceeded.  Algorithm failed.\n");
		break;
	case 5:
		Rprintf("Maximum step size exceeded 10 consecutive times.\n");
		Rprintf("Either the function is unbounded below,\n");
		Rprintf("becomes asymptotic to a finite values\n");
		Rprintf("from above in some direction\n");
		Rprintf("or stepmx is too small.\n");
	}
}

static double dotp(int n, double *x, double *y)
{
	int i;
	double sum = 0.0;
	for(i=0 ; i<n ; i++)
		sum += x[i] * y[i];
	return sum;
}


static double rnorm2(int n, double *x)
{
	return dotp(n, x, x);
}


static void ltsolve(int nr, int n, double *a, double *x, double *b)
{
	int i, ip1, j, nm1;
	double sum;

	x[n-1] = b[n-1]/a[n-1+(n-1)*nr];
	for(i=n-2 ; i>=0 ; i--) {
		sum = 0.0;
		for(j=i+1 ; j<n ; j++)
			sum += a[j+i*nr] * x[j];
		x[i] = (b[i] - sum)/a[i+i*nr];
	}
}


static void lsolve(int nr, int n, double *a, double *x, double *b)
{
	int i, iminus1, j;
	double sum;

	x[0] = b[0]/a[0];
	for(i=1 ; i<n ; i++) {
		sum = 0.0;
		iminus1 = i - 1;
		for(j=0 ; j<=iminus1 ; j++)
			sum += a[i+j*nr]*x[j];
		x[i] = (b[i] - sum)/a[i+i*nr];
	}
}

static void cholsolve(int nr, int n, double *a, double *x, double *b)
{
	lsolve(nr, n, a, x, b);
	ltsolve(nr, n, a, x, x);
}

static void scalarmultiply(int n, double s, double *v, double *z)
{
	int i;
	for(i=0 ; i<n ; i++)
		z[i] = s * v[i];
}

static void mvmltl(int nr, int n, double *a, double *x, double *y)
{
	int i, j;
	double sum;
	for(i=0 ; i<n ; i++) {
		sum = 0;
		for(j=0 ; j<=i ; j++)
			sum += a[i+j*nr] * x[j];
		y[i] = sum;
	}
}

static void mvmltu(int nr, int n, double *a, double *x, double *y)
{
	int i, j;
	double sum;
	for(i=0 ; i<n ; i++) {
		sum = 0;
		for(j=i ; j<n ; j++)
			sum += a[j+i*nr] * x[j];
		y[i] = sum;
	}
}

static void qraux1(int nr, int n, double *r, int i)
{
	int j;
	double tmp;
	for(j=0 ; j<n ; j++) {
		tmp = r[i+j*nr];
		r[i+j*nr] = r[i+1+j*nr];
		r[i+1+j*nr] = tmp;
	}
}

static void qraux2(int nr, int n, double *r, int i, double a, double b)
{
	double den, c, s, y, z;
	int j;
	den = sqrt(a * a + b * b);
	c = a / den;
	s = b / den;
	for(j=i ; j<n ; j++) {
		y = r[i+j*nr];
		z = r[i+1+j*nr];
		r[i+j*nr] = c * y - s * z;
		r[i+1+j*nr] = s * y + c * z;
	}
}


static void qrupdate(int nr, int n, double *a, double *u, double *v)
{
	int k, km1, i, j;
	double t1, t2;

		/* determine last non-zero element in u[] */

	k = n-1;
	while(u[k] == 0 && k > 0)
		k = k-1;

		/* (k-1) Jacobi rotations transform */
		/*     r + u(v+) --> (r*) + (u(1)*e1)(v+) */
		/* which is upper hessenberg */

	for(i=k-1 ; i>=0 ; i--) {
		if(u[i] == 0) {
			qraux1(nr, n, a, i);
			u[i] = u[i+1];
		}
		else {
			t1 = u[i];
			t2 = -u[i+1];
			qraux2(nr, n, a, i, t1, t2);
			u[i] = sqrt(u[i]*u[i]+u[i+1]*u[i+1]);
		}
	}

		/* r <-- r + (u(1)*e1)(v+) */

	for(j=0 ; j<n ; j++)
		a[j*nr] += u[0]*v[j];

		/* (k-1) Jacobi rotations transform upper hessenberg r */
		/* to upper triangular (r*) */

	km1 = k-1;
	for(i=0 ; i<km1 ; i++) {
		if(a[i+i*nr] == 0) {
			qraux1(nr, n, a, i);
		}
		else {
			t1 = a[i+i*nr];
			t2 = -a[i+1+i*nr];
			qraux2(nr, n, a, i, t1, t2);
		}
	}
}

static void inithessfac(int nr, int n, double *a, double *sx)
{
	int i, j;
	for(j=0 ; j<n ; j++) {
		a[j+j*nr] = sx[j];
		for(i=j+1 ; i<n ; i++)
			a[i+j*nr] = 0;
	}
}

static void secfac(int nr, int n, double *x, double *g, double *a,
	double *xpls, double *gpls, double *pepsm, int *pitncnt,
	double *prnf, int *piagflg, int *noupdt,
	double *s, double *y, double *u, double *w)
{
	int i, iagflg, im1, itncnt, j, skpupd;
	double alp, den1, den2, epsm, reltol, rnf, snrm2, ynrm2;

	epsm = *pepsm;
	itncnt = *pitncnt;
	rnf = *prnf;
	iagflg = *piagflg;

	if(itncnt == 1) *noupdt = 1;
	for(i=0 ; i<n ; i++) {
		s[i] = xpls[i]-x[i];
		y[i] = gpls[i]-g[i];
	}

	den1 = dotp(n, s, y);
	snrm2 = rnorm2(n, s);
	ynrm2 = rnorm2(n, y);

	if(den1 < sqrt(epsm)*snrm2*ynrm2) return;

	mvmltu(nr, n, a, s, u);
	den2 = dotp(n, u, u);

		/* l <-- sqrt(den1/den2)*l */

	alp = sqrt(den1/den2);
	if(*noupdt) {
		for(j=0 ; j<n ; j++) {
			u[j] = alp*u[j];
			for(i=j ; i<n ; i++)
				a[i+j*nr] = alp * a[i+j*nr];
		}
		*noupdt = 0;
		den2 = den1;
		alp = 1.0;
	}
	skpupd = 1;

		/* w = l(l+)s = hs */

	mvmltl(nr, n, a, u, w);

	if(iagflg == 0) reltol = sqrt(rnf);
	else reltol = rnf;

        i = 0;
	while(i< n && skpupd) {
		if(fabs(y[i]-w[i]) >= reltol*fmax(fabs(g[i]),fabs(gpls[i])))
			skpupd = 0;
		else
			i = i+1;
	}
	if(skpupd) return;

		/* w=y-alp*l(l+)s */

	for(i=0 ; i<n ; i++)
		w[i] = y[i]-alp*w[i];

		/* alp=1/sqrt(den1*den2) */

	alp = alp/den1;

		/* u=(l+)/sqrt(den1*den2) = (l+)s/sqrt((y+)s * (s+)l(l+)s) */

	for(i=0 ; i<n ; i++)
		u[i] = alp*u[i];

		/* copy l into upper triangular part.  zero l. */

	for(i=1 ; i<n ; i++) {
		for(j=0 ; j<i ; j++) {
			a[j+i*nr] = a[i+j*nr];
			a[i+j*nr] = 0;
		}
	}

		/* find q, (l+) such that  q(l+) = (l+) + u(w+) */

	qrupdate(nr, n, a, u, w);

		/* Upper triangular part and diagonal of a now contain updated */
		/* cholesky decomposition of hessian.  Copy back to lower */
		/* triangular part. */

	for(i=1 ; i<n ; i++) {
		for(j=0 ; j<i ; j++)
			a[i+j*nr] = a[j+i*nr];
	}
}

static void lnsrch(
	int n, double *x, double *f, double *g, double *p,
	double *xpls, double *fpls, double (*fcn)(), int *mxtake,
	int *iretcd, double *stepmx, double *steptl, double *sx)
{
	double pfpls, sfpls, t1, t2, t3, almbda, plmbda, tlmbda, rmnlmb;
	double scl, rln, sln, slp, tmp;
	double a, b, disc;
	int i;

	*mxtake = 0;
	*iretcd = 2;
	tmp = 0;
	for (i=0; i < n; i++)
		tmp += sx[i] * sx[i] * p[i] * p[i];
	sln = sqrt(tmp);
	if (sln > *stepmx) {
		scl = *stepmx / sln;
		scalarmultiply(n, scl, p, p);
		sln = *stepmx;
	}
	slp = dotp(n, g, p);
	rln = 0;
	for (i=0; i<n; i++) {
		rln = fmax(rln, fabs(p[i])/fmax(fabs(x[i]), 1.0/sx[i]));
	}
	rmnlmb = *steptl / rln;
	almbda = 1;
	while(*iretcd >= 2) {
		for (i=0; i<n; i++)
			xpls[i] = x[i] + almbda * p[i];
		*fpls = fcn(xpls, n);
		if(*fpls==NA_REAL)*fpls=1e+20;
		sfpls = *fpls;

		if (sfpls <= *f + slp * 1.0e-4 * almbda) {
			*iretcd = 0;
			if (almbda == 1.0 && sln > *stepmx * 0.99)
				*mxtake = 1;
			return;
		}
		else {
			if (almbda < rmnlmb) {
				*iretcd = 1;
				return;
			}
		}
		if (almbda == 1.0) {
			tlmbda = -slp / ((*fpls - *f - slp) * 2.0);
		}
		else {
			t1 = *fpls - *f - almbda * slp;
			t2 = pfpls - *f - plmbda * slp;
			t3 = 1.f / (almbda - plmbda);
			a = t3 * (t1 / (almbda * almbda) - t2 / (plmbda * plmbda));
			b = t3 * (t2 * almbda / (plmbda * plmbda) - t1 * plmbda / (almbda * almbda));
			disc = b * b - a * 3.0 * slp;
			if (disc > b * b)
				tlmbda = (-b+fsign(1.0,a)*sqrt(disc))/(3.0*a);
			else
				tlmbda = (-b-fsign(1.0,a)*sqrt(disc))/(3.0*a);
			if (tlmbda > almbda * 0.5)
				tlmbda = almbda * 0.5;
		}
		plmbda = almbda;
		pfpls = *fpls;

		/* WEIRD BUG - making the .1f below */
		/* 0.1 can lose LOTS of accuracy */

		if (tlmbda < almbda * .1)
			almbda *= .1f;
		else
			almbda = tlmbda;
	}
}

static void fstofd(int n, double *xpls, double (*fcn)(), double *fpls,
	double *g, double *sx, double *rnoise)
{
	double xtmpj, stepsz, fhat;
	double tmp1, tmp2;
	int j;
	for(j=0 ; j<n ; j++) {
		stepsz = sqrt(*rnoise)*fmax(fabs(xpls[j]),1.0/sx[j]);
		xtmpj = xpls[j];
		xpls[j] = xtmpj + stepsz;
		fhat = fcn(xpls, n);
		xpls[j] = xtmpj;
		g[j] = (fhat - *fpls)/stepsz;
	}
}

static void optstp(int n, double *xpls, double *fpls, double *gpls,
	double *x, int *itncnt, int *icscmx, int *itrmcd, double *gradtl,
	double *steptl, double *sx, double *fscale, int *itnlim,
	int *iretcd, int *mxtake, int *ipr)
{
	double d, rgx, relgrd, rsx, relstp;
	int jtrmcd, i;

	*itrmcd = 0;
	
		/* last global step failed to */
		/* locate a point lower than x */

	if (*iretcd == 1)
		jtrmcd = 3;
	else {
	
			/* Find direction in which relative gradient */
			/* maximum.  Check whether within tolerance */

		d = fmax(fabs(*fpls), *fscale);
		rgx = 0.0;
		for(i=0 ; i<n ; i++) {
			relgrd = fabs(gpls[i])*fmax(fabs(xpls[i]),1.0/sx[i])/d;
			rgx = fmax(rgx, relgrd);
		}
		jtrmcd = 1;
		if (rgx > *gradtl) {
			if (*itncnt == 0) return;

				/* Find direction in which relative stepsize */
				/* maximum.  Check whether within tolerance. */

			rsx = 0.0;
			for(i=0 ; i<n ; i++) {
				relstp = fabs(xpls[i]-x[i])/fmax(fabs(xpls[i]),1.0/sx[i]);
				rsx = fmax(rsx, relstp);
			}
			jtrmcd = 2;
			if (rsx > *steptl) {

					/* check iteration limit */

				jtrmcd = 4;
				if (*itncnt < *itnlim)

						/* Check number of consecutive */
						/* steps \ stepmx */

					if (!*mxtake) {
						*icscmx = 0;
						return;
					}
					else {
						prtstp(0);
						*icscmx = *icscmx+1;
						if (*icscmx < 10)
							return;
						jtrmcd = 5;
					}
			}
		}
	}

		/* Print termination code. */

	*itrmcd = jtrmcd;
	prtstp(*itrmcd);
	return;
}

static void result(int n, double *x, double *f, double *g,
	double *p, int *itncnt, int *iflg, int *ipr)
{
	int i;

		/*  print iteration number */

	Rprintf("Iterate k = %d\n", *itncnt);

		/* print step */

	if(iflg != 0) {
		Rprintf("Step:\n");
		printRealVector(p, n, 1);
	}

		/* print current iterate */

	Rprintf("Parameter:\n");
	printRealVector(x, n, 1);

		/* print function value */

	Rprintf("Function Value\n");
	printRealVector(f, 1, 1);

		/* print gradient */

	Rprintf("Gradient:\n");
	printRealVector(g, n, 1);

	Rprintf("\n");
	return;
}

static void uminck(int n, double *typsiz, double *sx, double *fscale,
	double *gradtl, int itnlim, int ndigit, int *termcode)
{
	int i;

		/* check problem dimensions */

	if (n <= 0) {
		Rprintf("Illegal dimension, n = %d\n", n);
		*termcode = -1;
		return;
	}

	if (n == 1 && *termcode%2 == 0) {
		Rprintf("minimize is intended for multidimensional problems\n");
		*termcode = -2;
		return;
	}

		/* compute scale matrix */

	for(i=0 ; i<n ; i++) {
		if (typsiz[i] == 0.0)
			typsiz[i] = 1.0;
		else if (typsiz[i] < 0.0)
			typsiz[i] = -typsiz[i];
		sx[i] = 1.0/typsiz[i];
	}

	/* check function scale */

	if (*fscale == 0.0)
		*fscale = 1.0;
	if (*fscale < 0.0)
		*fscale = -*fscale;

		/* check gradient tolerance */

	if (*gradtl < 0.0) {
		Rprintf("illegal tolerance.  gradtl =");
		printRealVector(gradtl, 1, 0);
		*termcode = -3;
		return;
	}

		/* check iteration limit */

	if (itnlim <= 0) {
		Rprintf("illegal iteration limit.  itnlim = %d\n", itnlim);
		*termcode = -4;
		return;
	}


		/* check number of digits of accuracy in function fcn */

	 if (ndigit <= 0) {
		Rprintf("minimization function has no good digits.  ndigit = %d\n", ndigit);
		*termcode = -5;
	}

	return;
}

static void optdrv(
	int nr, int n, double *x, double (*fcn)(),
	double *typsiz, double *fscale, int *msg, int *ndigit,
	int *itnlim, int *ipr, double *gradtl, double *stepmx,
	double *steptl, double *xpls, double *fpls, double *gpls,
	int *itrmcd, double *a, double *g, double *p, double *sx,
	double *wrk0, double *wrk1, double *wrk2, double *wrk3)
{
	double analtl, epsm, f, rnf;
	int zero, one;
	int mxtake, noupdt;
	int i, iagflg, icscmx, itncnt, iretcd;

	zero = 0;
	one = 1;

		/* initialization */

	for(i=0 ; i<n ; i++)
		p[i] = 0.0;

	itncnt = 0;
	iretcd = -1;
	uminck(n, typsiz, sx, fscale, gradtl, *itnlim, *ndigit, msg);
	if (*msg < 0) return;

	rnf = pow(10.0,(double)(-*ndigit));
	analtl = fmax(0.01, sqrt(rnf));

	if ((*msg/8)%2 != 1) {
		Rprintf("Typical x\n");
		printRealVector(typsiz, n, 1);
		Rprintf("diagonal scaling matrix for x\n");
		printRealVector(sx, n, 1);
		Rprintf("Typical f =");
		printRealVector(fscale, 1, 0);
		Rprintf("Number of good digits in fcn = %d\n", *ndigit);
		Rprintf("Iteration limit = %d\n", *itnlim);
		Rprintf("Maximum step size = ");
		printRealVector(stepmx, 1, 0);
		Rprintf("Step tolerance    = ");
		printRealVector(steptl, 1, 0);
		Rprintf("Gradient tolerance= ");
		printRealVector(gradtl, 1, 0);
		Rprintf("Rel noise in fcn  = ");
		printRealVector(&rnf, 1, 0);
		Rprintf("anal-fd tolerance = ");
		printRealVector(&analtl, 1, 0);
	}

		/* evaluate fcn(x) */

	f = fcn(x, n);


		/* the call to subroutine grdchk has */
		/* been replaced by the following */

	fstofd(n, x, fcn, &f, g, sx, &rnf);

	optstp(n, x, &f, g, wrk1, &itncnt, &icscmx,
		itrmcd, gradtl, steptl, sx, fscale, itnlim,
		&iretcd, &mxtake, ipr);

	if (*itrmcd == 0) {

			/* hessian will be obtained by secant */
			/* updates.  get initial hessian. */

		inithessfac(nr, n, a, sx);
		if ((*msg/8)%2 == 0)
			result(n, x, &f, g, p, &itncnt, &one, ipr);

		for(;;) {
				/* iteration */

			itncnt = itncnt+1;

				/* solve for newton step:  a p = -g */

			for(i=0 ; i<n ; i++)
				wrk1[i] = -g[i];

			cholsolve(nr, n, a, p, wrk1);

				/* decide whether to accept newton step  xpls=x + p */
				/* or to choose xpls by a global strategy. */

			lnsrch(n, x, &f, g, p, xpls, fpls, fcn, &mxtake, &iretcd, stepmx, steptl, sx);

				/* get gradient */

			fstofd(n, xpls, fcn, fpls, gpls, sx, &rnf);

				/* check whether stopping criteria satisfied */

			optstp(n, xpls, fpls, gpls, x, &itncnt, &icscmx, itrmcd, gradtl, steptl, sx, fscale, itnlim, &iretcd, &mxtake, ipr);
			if (*itrmcd != 0)
				break;

				/* evaluate hessian at xpls */

			epsm = pow(10.0,(double)(-*ndigit));
			secfac(nr, n, x, g, a, xpls, gpls, &epsm, &itncnt, &rnf, &iagflg, &noupdt, wrk0, wrk1, wrk2, wrk3);
			if ((*msg/16)%2 == 1)
				result(n, xpls, fpls, gpls, p, &itncnt, &one, ipr);

				/* x <-- xpls */
				/* g <-- gpls */
				/* f <-- fpls */

			f = *fpls;
			for(i=0 ; i<n ; i++) {
				x[i] = xpls[i];
				g[i] = gpls[i];
			}
		}

		if (*itrmcd != 3)
			goto L10;
	}

		/* termination */
		/* reset xpls,fpls,gpls */
		/* if previous iterate solution */

	*fpls = f;
	for(i=0 ; i<n ; i++) {
		xpls[i] = x[i];
		gpls[i] = g[i];
	}
   L10:	if ((*msg/8)%2 == 0)
		result(n, xpls, fpls, gpls, p, &itncnt, &zero, ipr);
	*msg = 0;
	return;
}

int optif(int *pnr, int *pn, double *x, void *fcn, double *typsiz,
	double *fscale, int *msg, int *ndigit, int *itnlim, int *ipr,
	double *gradtl, double *stepmx, double *steptl, double *xpls,
	double *fpls, double *gpls, int *itrmcd, double *a, double *wrk)
{
	int n, nr;
	n = *pn;
	nr = *pnr;

	optdrv(nr, n, x, fcn, typsiz, fscale, msg, ndigit,
		itnlim, ipr, gradtl, stepmx, steptl, xpls, fpls, gpls,
		itrmcd, a, &wrk[0*n], &wrk[1*n], &wrk[2*n], &wrk[3*n],
		&wrk[4*n], &wrk[5*n], &wrk[6*n]);
	return;
}

int fdhess(int *pn, double *x, double *fval, double (*fun)(),
	double *h, int *nfd, double *step, double *f,
	int *ndigit, double *typx)
{
	double eta, fii, fij, tempi, tempj;
	int i, j, n;

	n = *pn;

	eta = pow(pow(10.0,(double)(-*ndigit)),(1.0/3.0));

	for(i=0 ; i<n ; i++) {
		step[i] = eta * fmax(x[i], typx[i]);
		if (typx[i] < 0.0)
			step[i] = -step[i];
		tempi = x[i];
		x[i] = x[i] + step[i];
		step[i] = x[i] - tempi;
		f[i] = fun(x, n);
		x[i] = tempi;
	}

	for(i=0 ; i<n ; i++) {
		tempi = x[i];
		x[i] = x[i] + 2.0 * step[i];
		fii = fun(x, n);
		h[i+i*n] = ((*fval - f[i]) + (fii - f[i]))/(step[i]*step[i]);
		x[i] = tempi + step[i];
		if (i < n-1) {
			for(j=i+1 ; j<n ; j++) {
				tempj = x[j];
				x[j] = x[j] + step[j];
				fij = fun(x, n);
				h[i+j*n] = ((*fval-f[i])+(fij-f[j]))/(step[i]*step[j]);
				h[j+i*n] = h[i+j*n];
				x[j] = tempj;
			}
		}
		x[i] = tempi;
	}
	return;
}
