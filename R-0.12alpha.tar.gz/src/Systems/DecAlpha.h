		/* DEC Alpha running OSF/1 V2.1 (Rev. 250) */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define Alpha
#define Unix
/* #define Readline			/* uncomment for GNU readline support */
#define SVIDArith
#define DLSupport
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
