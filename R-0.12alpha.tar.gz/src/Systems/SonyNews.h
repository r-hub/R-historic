		/* NewsOS 4.1C (NWS1250) */
		/* gcc 2.6.3 / gcc 2.7.0 and sony f77. */
		/* (Berkeley F77, version 2.0 SCCS level 6). */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#define SonyNews
#define remove unlink
#define Unix
#define PosixArith
#define DLSupport
#define Proctime
#define F77_SYMBOL(x)	x ## _
#define F77_QSYMBOL(x)	#x ## "_"

#endif
