/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include "Graphics.h"
#include "rotated.h"

void error(char*);

	/* Start of Tunable Defaults */

#define CURSOR		XC_crosshair	/* Default cursor */


	/* End of Tunable Defaults */

/* R Device Driver code */

	/* Graphics Parameters for last driver call. */

static double cex = 1.0;
static double srt = 0.0;
static unsigned col = -1;
static int lty = -1;
static rcolor fg;
static rcolor bg;

static int windowWidth;
static int windowHeight;
static int resize = 0;

static Display *display;			/* Display */
static int screen;				/* Screen */
static int depth;				/* Pixmap depth */
static Window rootWindow;			/* Root Window */
static Window window;				/* Graphics Window */
static Cursor gcursor;				/* Graphics Cursor */

static GC wgc;					/* GC for window */

static XSetWindowAttributes attributes;		/* Window attributes */
static XEvent event;				/* Event */

static Colormap cmap;				/* Default color map */
static XColor fgcolor;				/* Foreground color */
static XColor bgcolor;				/* Background color */
static int blackpixel;				/* Black */
static int whitepixel;				/* White */

static int fontface = -1;
static int fontsize = -1;

static void ProcessEvents(void);
static void X11_NewPlot(void);

	/* ---- Utility Functions ---- */

#define MM_PER_INCH 25.4

static double pixelWidth(void)
{
	double width, widthMM;
	width = DisplayWidth(display, screen);
	widthMM = DisplayWidthMM(display, screen);
	return (widthMM / width) / MM_PER_INCH;
}

static double pixelHeight(void)
{
	double height, heightMM;
	height = DisplayHeight(display, screen);
	heightMM = DisplayHeightMM(display, screen);
	return (heightMM / height) / MM_PER_INCH;
}

	/* Font information array. */
	/* Point sizes: 6-24 */
	/* Faces: plain, bold, oblique, bold-oblique */
	/* Symbol may be added later */

#define NFONT 19

static XFontStruct *fontarray[NFONT][4] = {
	{NULL, NULL, NULL, NULL},	/*  6 */
	{NULL, NULL, NULL, NULL},	/*  7 */
	{NULL, NULL, NULL, NULL},	/*  8 */
	{NULL, NULL, NULL, NULL},	/*  9 */
	{NULL, NULL, NULL, NULL},	/* 10 */
	{NULL, NULL, NULL, NULL},	/* 11 */
	{NULL, NULL, NULL, NULL},	/* 12 */
	{NULL, NULL, NULL, NULL},	/* 13 */
	{NULL, NULL, NULL, NULL},	/* 14 */
	{NULL, NULL, NULL, NULL},	/* 15 */
	{NULL, NULL, NULL, NULL},	/* 16 */
	{NULL, NULL, NULL, NULL},	/* 17 */
	{NULL, NULL, NULL, NULL},	/* 18 */
	{NULL, NULL, NULL, NULL},	/* 19 */
	{NULL, NULL, NULL, NULL},	/* 20 */
	{NULL, NULL, NULL, NULL},	/* 21 */
	{NULL, NULL, NULL, NULL},	/* 22 */
	{NULL, NULL, NULL, NULL},	/* 23 */
	{NULL, NULL, NULL, NULL},	/* 24 */
};

static int missingfont[NFONT][4] = {
	{0, 0, 0, 0},	/*  6 */
	{0, 0, 0, 0},	/*  7 */
	{0, 0, 0, 0},	/*  8 */
	{0, 0, 0, 0},	/*  9 */
	{0, 0, 0, 0},	/* 10 */
	{0, 0, 0, 0},	/* 11 */
	{0, 0, 0, 0},	/* 12 */
	{0, 0, 0, 0},	/* 13 */
	{0, 0, 0, 0},	/* 14 */
	{0, 0, 0, 0},	/* 15 */
	{0, 0, 0, 0},	/* 16 */
	{0, 0, 0, 0},	/* 17 */
	{0, 0, 0, 0},	/* 18 */
	{0, 0, 0, 0},	/* 19 */
	{0, 0, 0, 0},	/* 20 */
	{0, 0, 0, 0},	/* 21 */
	{0, 0, 0, 0},	/* 22 */
	{0, 0, 0, 0},	/* 23 */
	{0, 0, 0, 0},	/* 24 */
};

/*
static char *fontname_R6 = "-adobe-helvetica-%s-%s-*-*-*-%d-100-100-*-*-*-*";
*/
static char *fontname_R6 = "-adobe-helvetica-%s-%s-*-*-*-%d-*-*-*-*-*-*";
static char *fontname_R5 = "-adobe-helvetica-%s-%s-*-*-*-%d-*-*-*-*-*-*";
static char *fontname;

static char *slant[]  = {"r", "o"};
static char *weight[] = {"medium", "bold"};

static int usefixed = 0;
static XFontStruct *fixedfont;
static XFontStruct *font;

static XFontStruct *RLoadFont(int face, int size)
{
#ifdef DEBUG
	XFontStruct *tmp;
#endif
	char buf[128];
	sprintf(buf, fontname, weight[(face-1)%2], slant[((face-1)/2)%2], 10 * size);
#ifdef DEBUG
	Rprintf("loading:\n%s\n",buf);
	tmp = XLoadQueryFont(display, buf);
	if(tmp) Rprintf("success\n"); else Rprintf("failure\n");
	return tmp;
#else
	return XLoadQueryFont(display, buf);
#endif
}

	/* Quiz the server about fonts. */
	/* 1) Try for 100dpi (X11R6) font */
	/* 2) Try for *dpi (X11R6) font */
	/* 3) Try "fixed" and if that fails, bail out */

static int SetBaseFont()
{
	fontface = 1;
	fontsize = GP->ps;
	fontname = fontname_R6;
	font = fontarray[fontsize-6][fontface-1] = RLoadFont(fontface, fontsize);
	if(!font) {
		fontname = fontname_R5;
		font = fontarray[fontsize-6][fontface-1] = RLoadFont(fontface, fontsize);
	}
	if(!font) {
		usefixed = 1;
		font = fixedfont = XLoadQueryFont(display, "fixed");
		if(!fixedfont)
			return 0;
	}
	return 1;
}

	/* Set the font size and face */
	/* If the font of this size and at that the specified */
	/* rotation is not present it is loaded. */
	/* 0 = plain text, 1 = bold */
	/* 2 = oblique, 3 = bold-oblique */

#define SMALLEST 8
#define LARGEST 24

static void SetFont(int face, int size)
{
	if(face < 1 || face > 4) face = 1;
	size = 2 * size / 2;
	if(size < SMALLEST) size = SMALLEST;
	if(size > LARGEST) size = LARGEST;

	if(!usefixed && (size != fontsize  || face != fontface)) {
		while(size < GP->ps) {
			if(fontarray[size-6][face-1]) goto found;
			if(!missingfont[size-6][face-1]) {
				fontarray[size-6][face-1] = RLoadFont(face, size);
				if(fontarray[size-6][face-1]) goto found;
				missingfont[size-6][face-1] = 1;
			}
			size += 2;
		}
		while(size >= GP->ps) {
			if(fontarray[size-6][face-1]) goto found;
			if(!missingfont[size-6][face-1]) {
				fontarray[size-6][face-1] = RLoadFont(face, size);
				if(fontarray[size-6][face-1]) goto found;
				missingfont[size-6][face-1] = 1;
			}
			size -= 2;
		}
		size = GP->ps;
		face = 1;
	found:
		font = fontarray[size-6][face-1];
		fontface = face;
		fontsize = size;
		XSetFont(display, wgc, font->fid);
	}
}

static void SetColor(unsigned color)
{
	if(color != col) {
		fgcolor.red =   ((color >>  8) & 255) << 8;
		fgcolor.green = ((color >> 16) & 255) << 8;
		fgcolor.blue =  ((color >> 24) & 255) << 8;
		if(XAllocColor(display, cmap, &fgcolor) == 0)
			error("color allocation error\n");
		blackpixel = fgcolor.pixel;
		col = color;
		XSetState(display, wgc, blackpixel, whitepixel, GXcopy, AllPlanes);
	}
}

static void SetLinetype(unsigned newlty)
{
	unsigned char dashlist[8];
	int i, ndash;

	if(newlty != lty) {
		if(newlty == 0) {
			XSetLineAttributes(display, wgc, 1, LineSolid, CapRound, JoinRound);
			lty = newlty;
		}
		else {
			lty = newlty;
			ndash = 0;
			for(i=0 ; i<8 && newlty&15 ; i++) {
				dashlist[ndash++] = newlty&15;
				newlty = newlty>>4;
			}
			XSetDashes(display, wgc, 0, dashlist, ndash);
			XSetLineAttributes(display, wgc, 1, LineOnOffDash, CapRound, JoinRound);
		}
	}
}

static int X11_Open(char *dsp, double w, double h)
{
	int iw, ih, result;
	XGCValues gcv;
	XColor exact;

	/* open the default display */
	/* return value of 0 indicates failure */

	if ((display = XOpenDisplay(dsp)) == NULL)
		return 0;
	if (!SetBaseFont()) {
		Rprintf("can't find X11 font\n");
		XCloseDisplay(display);
		return 0;
	}

		/* Default Screen and Root Window */

	screen = XDefaultScreen(display);
	rootWindow = XDefaultRootWindow(display);
	depth = XDefaultDepth(display, screen);

		/* Foreground and Background Colors */

	bg =  DP->bg  = GP->bg  = RGB(255,255,255);
	fg =  DP->fg  = GP->fg  = RGB(0,0,0);
	col = DP->col = GP->col = fg;

	cmap = DefaultColormap(display, screen);

	result = XAllocNamedColor(display, cmap, "white", &exact, &bgcolor);
	if (result == 0) error("color allocation error\n");

	result = XAllocNamedColor(display, cmap, "black", &exact, &fgcolor);
	if (result == 0) error("color allocation error\n");

	whitepixel = bgcolor.pixel;
	blackpixel = fgcolor.pixel;

		/* Try to create a simple window */
		/* Want to know about exposures */
		/* and window-resizes and locations */

	attributes.background_pixel = whitepixel;
	attributes.border_pixel = blackpixel;
	attributes.backing_store = Always;
	attributes.event_mask = ButtonPressMask
	    | ExposureMask
	    | StructureNotifyMask;

	windowWidth = iw = w/pixelWidth();
	windowHeight = ih = h/pixelHeight();

	if ((window = XCreateWindow(
		display,
		rootWindow,
		DisplayWidth(display, screen) - iw - 10, 10, iw, ih, 1,
		DefaultDepth(display, screen),
		InputOutput,
		DefaultVisual(display, screen),
		CWEventMask | CWBackPixel | CWBorderPixel | CWBackingStore,
		&attributes)) == 0)
		return 0;

	XChangeProperty( display, window, XA_WM_NAME, XA_STRING,
		8, PropModeReplace, "R Graphics", 13);

	gcursor = XCreateFontCursor(display, CURSOR);
	XDefineCursor(display, window, gcursor);

		/* map the window */

	XSelectInput(display, window,
		   ExposureMask | ButtonPressMask | StructureNotifyMask);
	XMapWindow(display, window);
	XSync(display, 0);

		/* gobble expose events */

	XNextEvent(display, &event);
	if (event.xany.type == Expose) {
		while (event.xexpose.count)
			XNextEvent(display, &event);
	}

		/* set the graphics context */

	gcv.arc_mode = ArcChord;
	wgc = XCreateGC(display, window, GCArcMode, &gcv);
	XSetState(display, wgc, blackpixel, whitepixel, GXcopy, AllPlanes);
	XSetFont(display, wgc, font->fid);
	SetLinetype(0);
	return 1;
}

static double X11_StrWidth(char *str)
{
	int size = GP->cex * GP->ps + 0.5;
	SetFont(GP->font, size);
	return (double)XTextWidth(font, str, strlen(str));
}

static XRectangle clip;

static void X11_Clip(int x0, int x1, int y0, int y1)
{
	if (x0 < x1) {
		clip.x = x0;
		clip.width = x1 - x0;
	}
	else {
		clip.x = x1;
		clip.width = x0 - x1;
	}
	if (y0 < y1) {
		clip.y = y0;
		clip.height = y1 - y0;
	}
	else {
		clip.y = y1;
		clip.height = y0 - y1;
	}
	XSetClipRectangles(display, wgc, 0, 0, &clip, 1, Unsorted);
}

static void X11_Resize()
{
	ProcessEvents();
	if (resize) {
		DP->left = 0.0;
		DP->right = windowWidth;
		DP->bottom = windowHeight;
		DP->top = 0.0;
		resize = 0;
	}
}

static void X11_NewPlot()
{
	int result;

	if(bg != DP->bg) {
		bg = DP->bg;
		bgcolor.red =   ((bg>> 8)&255)<<8;
		bgcolor.green = ((bg>>16)&255)<<8;
		bgcolor.blue =  ((bg>>24)&255)<<8;
		result = XAllocColor(display, cmap, &bgcolor);
		if (result == 0) error("color allocation error\n");
		whitepixel = bgcolor.pixel;
		XSetWindowBackground(display, window, whitepixel);
	}
	XClearWindow(display, window);
	XSync(display, 0);
}

static void X11_Close(void)
{
	int i, j;

	/* Free Resources Here */
	for(i=0 ; i<NFONT ; i++)
		for(j=0 ; j<4 ; j++) {
			if(fontarray[i][j] != NULL) {
				XUnloadFont(display, fontarray[i][j]->fid);
				fontarray[i][j] = NULL;
			}
			missingfont[i][j] = 0;
		}
	XCloseDisplay(display);
	/*
	XVertEnd();
	*/
}

static void X11_StartPath()
{
	SetColor(GP->col);
	SetLinetype(GP->lty);
}

static void X11_EndPath()
{
}

static int xlast;
static int ylast;

static void X11_MoveTo(int x, int y)
{
	xlast = x;
	ylast = y;
}

static void X11_LineTo(int x, int y)
{
	XDrawLine(display, window, wgc, xlast, ylast, x, y);
	xlast = x;
	ylast = y;
	XSync(display, 0);
}

static void X11_Rect(int x0, int y0, int x1, int y1, int fill)
{
	int tmp;
	if (x0 > x1) {
		tmp = x0;
		x0 = x1;
		x1 = tmp;
	}
	if (y0 > y1) {
		tmp = y0;
		y0 = y1;
		y1 = tmp;
	}
	SetColor(GP->col);
	if (fill) XFillRectangle(display, window, wgc, x0, y0, x1 - x0, y1 - y0);
	else XDrawRectangle(display, window, wgc, x0, y0, x1 - x0, y1 - y0);
	XSync(display, 0);
}

static void X11_Circle(int x, int y, int r, int col, int border)
{
	if(col != NA_INTEGER) {
		SetColor(col);
		XFillArc(display, window, wgc, x-r, y-r, 2*r, 2*r, 0, 23040);
	}
	if(border != NA_INTEGER) {
		SetLinetype(GP->lty);
		SetColor(border);
		XDrawArc(display, window, wgc, x-r, y-r, 2*r, 2*r, 0, 23040);
	}
}

static void X11_Polygon(int n, int *x, int *y)
{
	XPoint *points;
	char *vmax, *vmaxget();
	int i;
	
	if((points=(XPoint*)R_alloc(n, sizeof(XPoint))) == NULL)
		error("out of memory while drawing polygon\n");
	for(i=0 ; i<n ; i++) {
		points[i].x = x[i];
		points[i].y = y[i];
	}
	SetColor(GP->col);
	XFillPolygon(display, window, wgc, points, n, Complex, CoordModeOrigin);
	XSync(display, 0);
	vmaxset(vmax);
}


static double deg2rad = 0.01745329251994329576;

static void X11_Text(int x, int y, char *str, double xc, double yc, int rot)
{
	int len, size;
	double xx, yy, xl, yl;

	size = GP->cex * GP->ps + 0.5;
	SetFont(GP->font, size);
	SetColor(GP->col);
	len = strlen(str);
	if(xc != 0.0 || yc != 0) {
		xx = x;
		yy = y;
		xl = X11_StrWidth(str);
		yl = GP->cex * GP->cra[1];
		xx += -xc * xl * cos(deg2rad * rot) + yc * yl * sin(deg2rad * rot);
		yy -= -xc * xl * sin(deg2rad * rot) - yc * yl * cos(deg2rad * rot);
		X11_MoveTo((int)xx, (int)yy);
	}
	XRotDrawString(display, font, (double)rot, window, wgc, xlast, ylast, str);
	XSync(display, 0);
}

static int X11_Locator(int *x, int *y)
{
	ProcessEvents();	/* discard pending events */
	XSync(display, 1);
	XNextEvent(display, &event);
	if (event.xbutton.button == Button1 /* || event.xbutton.button==Button2 */ ) {
		*x = event.xbutton.x;
		*y = event.xbutton.y;
		fprintf(stderr, "\07");
		fflush(stderr);
		XSync(display, 0);
		return 1;
	}
	else {
		XSync(display, 0);
		return 0;
	}
}

static void ProcessEvents(void)
{
	while (XPending(display)) {
		XNextEvent(display, &event);
		if (event.xany.type == Expose) {
			while (event.xexpose.count) {
				XNextEvent(display, &event);
			}
		}
		else if (event.type == ConfigureNotify) {
			windowWidth = event.xconfigure.width;
			windowHeight = event.xconfigure.height;
			resize = 1;
		}
	}
}

/* Set Graphics mode - not needed for X11 */
static void X11_Mode(int mode)
{
	if(mode == 0) XSync(display, 0);
}


/* Hold the Picture Onscreen - not needed for X11 */
static void X11_Hold()
{
}


/*
 * The arguments to X11DeviceDriver are
 *	cpars[0] = display name
 *	npars[0] = width (inches)
 *	npars[1] = height (inches)
 */

int X11DeviceDriver(char **cpars, int ncpars, double *npars, int nnpars)
{
	int ps;
	DevInit = 0;

	if(ncpars != 1 || nnpars != 3)
		error("invalid device parameters (x11)\n");

		/* Font will load at first use */

	ps = npars[2];
	if(ps < 6 || ps > 24) ps = 12;
	ps = 2*(ps/2);

	fontface = -1;
	fontsize = -1;
	GP->font = 1;
	GP->ps = ps;

	if (!X11_Open(cpars[0], npars[0], npars[1]))
		return 0;
	ProcessEvents();

	DevOpen = X11_Open;
	DevClose = X11_Close;
	DevResize = X11_Resize;
	DevNewPlot = X11_NewPlot;
	DevClip = X11_Clip;
	DevStartPath = X11_StartPath;
	DevEndPath = X11_EndPath;
	DevMoveTo = X11_MoveTo;
	DevLineTo = X11_LineTo;
	DevStrWidth = X11_StrWidth;
	DevText = X11_Text;
	DevRect = X11_Rect;
	DevCircle = X11_Circle;
	DevPolygon = X11_Polygon;
	DevLocator = X11_Locator;
	DevMode = X11_Mode;
	DevHold = X11_Hold;

		/* Window Dimensions in Pixels */

	GP->left = 0;			/* left */
	GP->right = windowWidth;	/* right */
	GP->bottom = windowHeight;	/* bottom */
	GP->top = 0;			/* top */

		/* Nominal Character Sizes in Pixels */

	GP->cra[0] = font->max_bounds.rbearing - font->min_bounds.lbearing;
	GP->cra[1] = font->max_bounds.ascent + font->max_bounds.descent;

		/* Character Addressing Offsets */
		/* These are used to plot a single plotting character */
		/* so that it is exactly over the plotting point */

	GP->xCharOffset = 0.4900;
	GP->yCharOffset = 0.3333;
	GP->yLineBias = 0.1;

		/* Inches per Raster Unit */
		/* Using nominal 100dpi */

	GP->ipr[0] = 1.0 / pixelWidth();
	GP->ipr[1] = 1.0 / pixelHeight();

	GP->canResizePlot = 1;
	GP->canChangeFont = 0;
	GP->canRotateText = 1;
	GP->canResizeText = 1;
	GP->canClip = 1;

	DevInit = 1;
	cex = 1.0;
	lty = 0;
	xlast = 250;
	ylast = 250;
	return 1;
}
