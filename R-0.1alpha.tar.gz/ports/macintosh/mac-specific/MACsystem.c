/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <signal.h>
#include <stdarg.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>
/*#include <SegLoad.h>*/
#include "Defn.h"


/* JRH 21/11/95 */
extern FILE* yyin;

	/*--- I / O -- S u p p o r t -- C o d e ---*/

/* ReadKBD(char *buf, int len) */
/* WriteConsole(char *buf, int len) */
/* The code for these functions is tightly integrated with the event loop */
/* handler and so they are actually in MACdialog.c */


/* On an exception (handled via a longjump) this is called so that */
/* future loser input is taken from the keyboard */

void ResetConsole()
{
        R_Console = 1;
}


/* Under UNIXoid systems this is called to flush the standard output */
/* Here it serves no function.  Q: Does it serve any purpose at all? */

void FlushConsole()
{
        /* Placeholder */
}


/* On UNIXoid systems the user can generate EOF by typing ^D. */
/* The resulting file error flag is reset with a call to this */
/* function.  On the MAC we assume that ^D is literal. */

void ClearerrConsole()
{
        /* Placeholder */
}


/* On UNIXoid systems this function is called when bailing out at */
/* the end of session.  On the MAC we use a dialog box instead. */
/* It is probably redundant anyway. */

void Consolegets(char *buf, int buflen)
{
        /* Placeholder */
}



	/*--- I n i t i a l i z a t i o n -- C o d e ---*/


/* At startup we fire up our console package and then enter the */
/* the read-eval-print loop.  We might also choose to set values */
/* for R_nsize and R_vsize from resources here.  These are the */
/* values which give the number of cons cells and the size of the */
/* vector heap (in bytes) to the memory management system. */
/* Beware that this results in two very large non-moveable memory */
/* blocks being allocated when mainloop is called. */
/* In an ideal world this should probably happen before any MAC */
/* user interface stuff happens so that the blocks sit as low */
/* in the heap as possible.  Q: How would we signal an error */
/* to the loser if these allocations failed? */

int main()
{
	InitConsole("\pR Dialog", 24, 80);
	mainloop();
}


/* R_StartUp:  This code looks to see if we are restoring a saved */
/* image.  If so, we get its name and set the working directory */
/* to the right folder. */

void RStartUp(void)
{
        char filename[FILENAME_MAX];
        short message, count;
        int i;
        AppFile theFile;

        CountAppFiles(&message, &count);
        R_Init = 1;
        if (count <= 0) {
                R_Unnamed = 1;
                return;
        }
        if (message == 1)
                Rprintf("Can't print the image - restoring it instead\n");
        GetAppFiles((short) 1, &theFile);
        SetVol(NULL, theFile.vRefNum);
        strcpy(R_ImageName, PtoCstr(theFile.fName));
        R_Unnamed = 0;
        RenameConsole(R_ImageName);
        restore_image(R_ImageName);
        return;
}


/* Set the watch cursor when busy */

void RBusy(int yes)
{
	if(yes) WatchCursor(); else IBeamCursor();
}



	/*--- P l a t f o r m -- D e p e n d e n t -- F u n c t i o n s ---*/


/* Interrogate the machine about its parameters. */
/* At present we only return the name, but we should */
/* probably have things like values from "limits.h" and */
/* "float.h" as well fpr numerical purposes. */

SEXP do_machine(SEXP call, SEXP op, SEXP args, SEXP env)
{
        return mkString("Macintosh");
}


/* This only makes sense on systems with a shell interface although */
/* we might arrange to turn control over to the finder or whatever its */
/* currently called here */

SEXP do_system(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	errorcall(call, "\"system\" is only available on Unix");
}

static long SetFileSignature(char* fname)
{
        FileParam pb;
        VolumeParam vpb;
        ParmBlkPtr pbp;
        char pname[FILENAME_MAX];



/* set up the saved file (the image) so it invokes the R application */

		strcpy( fname, pname );
        pb.ioNamePtr = c2pstr(pname);
        pb.ioFVersNum = 0;
        pb.ioFDirIndex = 0;
        pb.ioVRefNum = 0;
        if (PBGetFInfoSync( (ParmBlkPtr)&pb) == noErr) {
                pb.ioFlFndrInfo.fdType = 'RIMG'; /*_ftype;*/
                pb.ioFlFndrInfo.fdCreator = 'RGRI'; /*_fcreator;*/
                PBSetFInfoSync((ParmBlkPtr)&pb);
        }

/* see how much room there is on the volume */
        vpb.ioVolIndex = 0;
        vpb.ioNamePtr = NULL;
        vpb.ioVRefNum = 0;
        if (PBGetVInfo((ParmBlkPtr)&vpb, 0) == noErr) {
                return (vpb.ioVFrBlk * vpb.ioVAlBlkSiz);
        }
}


SEXP do_dumpb(SEXP call, SEXP op, SEXP args, SEXP env)
{
        FILE *fp;
	long Vsize;

        switch (length(args)) {
        case 1:
                op = CAR(args);
                if (TYPEOF(op) != STRSXP)
                        error("invalid argument to dump\n");
                sysdump(CHAR(STRING(op)[0]));
                jump_to_toplevel();
                break;
        default:
                error("incorrect number of arguments to dump\n");
        }
        visible = 0;
        return nilValue;
}

void sysdump(char* fname)
{
        FILE *fp;
        long Vsize;

        fp = fopen(fname, "wb");
        if( !fp )
                error("dump: unable to open file\n");
	Vsize=SetFileSignature(fname);
        if (R_Console == 0)
                fclose(yyin);
        ResetConsole();
        FlushConsole();
        dump_image(fp,1,Vsize,fname);
        jump_to_toplevel();
}
