/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

extern FILE* yyin;

static void sysdump(char* , int); 


/*--- I / O -- S u p p o r t -- C o d e ---*/

/* These routines provide hooks for supporting console I/O. */
/* Under raw Unix these routines simply provide a connection */
/* to the stdio library.  Under a Motif interface the routines */
/* would be considerably more complex */


/* Fill a text buffer with user typed console input. */
/* This routine is only called when R_Console == 1. */

int ReadKBD(char *buf, int len)
{
#ifdef OLD
	if (fgets(buf, len, yyin) == NULL)
#endif
	if (fgets(buf, len, stdin) == NULL)
		return 0;
	else
		return 1;
}

/* Write a text buffer to the console. */
/* All system output is filtered through this routine. */

void WriteConsole(char *buf, int len)
{
	printf("%s", buf);
}

/* Reset so that input comes from the console */
/* This is used after error messages so that if the system */
/* was ``source'ing from a file, input is redirected from the console */

void ResetConsole()
{
	R_Console = 1;
	yyin = stdin;
}

/* This is stdio support to ensure that console file buffers are flushed. */

void FlushConsole()
{
	if (R_Console == 1)
		fflush(stdin);
}

/* This is stdio support to reset if the used types EOF on the console. */

void ClearerrConsole()
{
	if (R_Console == 1)
		clearerr(stdin);
}

void Consolegets(char *buf, int buflen)
{
	fgets(buf, buflen, stdin);
}


	/*--- I n i t i a l i z a t i o n -- C o d e ---*/

int argc;
char **argv;

int main(int xargc, char **xargv)
{
	int value;
	char *item;

	argc = xargc;
	argv = xargv;

	/* On Unix the console is a file */
	/* we just use stdio to write on it */
	Rconsolefile = stdout;
	Routputfile = stdout;
	Rsinkfile = NULL;

#ifdef FreeBSD
	/* Set up the math library for */
	/* POSIX exception handling */
	_LIB_VERSION = _POSIX_;
#endif

	item = getenv("R_NSIZE");
	if(item) { 
		sscanf(item, "%d", &value);
		if(value < R_nsize || value > 1000000)
			REprintf("warning: invalid vector heap size ignored\n");
		else
			R_nsize = value;
	}

	item = getenv("R_VSIZE");
	if(item) { 
		sscanf(item, "%d", &value);
		if(value < 1 || value > 100)
			REprintf("warning: invalid vector heap size ignored\n");
		else
			R_vsize = value*1000000;
	}

	mainloop();
	return 0;
}

void RStartUp()
{
	char *file, *path;
	FILE *fp;

	R_Unnamed = 1;
	if (argc > 1) {
		if (strcmp(argv[1], "-") == 0) {
			R_Init = 2;
			return;
		}
		strcpy(R_ImageName, argv[1]);
		R_Unnamed = 0;
		goto restore;
	}

	file = "R-Image";
	if ((fp = fopen(file, "r"))) {
		fclose(fp);
		strcpy(R_ImageName, file);
		R_Unnamed = 0;
		goto restore;
	}

	if ((path = getenv("RHOME"))) {
		sprintf(R_ImageName, "%s/%s", path, file);
		if ((fp = fopen(R_ImageName, "r")) != NULL) {
			fclose(fp);
			R_Unnamed = 1;
			goto restore;
		}
	}

	sprintf(R_ImageName, "%s/%s", "/usr/local/R", file);
	if ((fp = fopen(R_ImageName, "r"))) {
		fclose(fp);
		R_Unnamed = 1;
		goto restore;
	}

restore:
	restore_image(R_ImageName);
	return;
}

void RCleanUp()
{
	char buf[128];

	if( R_DirtyImage ) {
ask:
		ClearerrConsole();
		FlushConsole();

		REprintf("Save workspace image? [y/n/c]: ");
		Consolegets(buf, 128);

		switch (buf[0]) {
		case 'y':
		case 'Y':
			sysdump(R_ImageName, 0);
			break;
		case 'n':
		case 'N':
			break;
		case 'c':
		case 'C':
			jump_to_toplevel();
			break;
		default:
			goto ask;
		}
	}
	KillDevice();
	exit(0);
}

void RBusy(int which)
{
}

/* Declarations to keep f77 happy */
int MAIN_() {return 0;}
int __main() {return 0;}


	/*--- P l a t f o r m -- D e p e n d e n t -- F u n c t i o n s ---*/


SEXP do_machine(SEXP call, SEXP op, SEXP args, SEXP env)
{
	return mkString("Unix");
}

SEXP do_system(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	FILE *fp;
	char *x = "r", buf[120];
	int read, i, j;
	SEXP tlist = nilValue, tchar, rval;

	checkArity(op, args);
	if (!isString(CAR(args)))
		errorcall(call, "character argument expected\n");
	if (isLogical(CADR(args)))
		read = INTEGER(CADR(args))[0];
	if (read) {
		PROTECT(tlist);
		fp = popen(CHAR(STRING(CAR(args))[0]), x);
		for (i = 0; fgets(buf, 120, fp); i++) {
			read = strlen(buf);
			buf[read - 1] = '\0';
			tchar = mkChar(buf);
			UNPROTECT(1);
			PROTECT(tlist = CONS(tchar, tlist));
		}
		pclose(fp);
		rval = allocVector(STRSXP, i);;
		for (j = (i - 1); j >= 0; j--) {
			STRING(rval)[j] = CAR(tlist);
			tlist = CDR(tlist);
		}
		UNPROTECT(1);
		return (rval);
	}
	else {
		system(CHAR(STRING(CAR(args))[0]));
		visible = 0;
		return (nilValue);
	}
}

/* Binary image dumps invoked when the "dump" function is used. */

SEXP do_dumpb(SEXP call, SEXP op, SEXP args, SEXP env)
{
	switch (length(args)) {
	case 1:
		op = CAR(args);
		if (TYPEOF(op) != STRSXP || LENGTH(op) != 1)
			error("invalid argument to dump\n");
		sysdump(CHAR(STRING(op)[0]), 1);
		break;
	default:
		error("incorrect number of arguments to dump\n");
	}
	visible = 0;
	return nilValue;
}

/* Binary dump workhorse. This function should open the image file. */
/* On some systems it should check to make sure that there is room */
/* to store the image on the specified device. */

void sysdump(char* fname, int jump) 
{
	FILE *fp;

	fp = fopen(fname, "wb");
	if( !fp )
		error("dump: unable to open file\n");
	if (R_Console == 0)
		fclose(yyin);
	ResetConsole();
	FlushConsole();
	dump_image(fp,0,0,fname);
	if(jump)
		jump_to_toplevel();
}
