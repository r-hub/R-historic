/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Graphics.h"

/*
 *  Heap and Pointer Protection Stack Size
 *
 *  STACKSIZE	= Size of the pointer protection stack (way too big)
 *  NSIZE	= Number of cons cells
 *  VSTACK	= Vector heap size in bytes
 *
 *  These compiled in values are minima and it should be possible to
 *  override them in a platform dependent way.
 */

#define STACKSIZE	10000L
#define NSIZE		72000L
#define VSIZE		500000L

int R_nsize = NSIZE;
int R_vsize = VSIZE;
int R_ssize = STACKSIZE;

/*
 * Global Variables
 *
 * Each of these sould be prefixed by R_.
 * One day ...
 */

SEXP globalEnv;
SEXP *argStack;
int stacksize = STACKSIZE;
int stacktop = 0;
int nsize;
int vsize;
int visible;
SEXPREC *nheap;
VECREC *vheap;
SEXP freeSEXP;
SEXP currentExp;
SEXP currentCall;
SEXP returnedValue;
SEXP *SYMBOL_TABLE;
jmp_buf stack_state;
RCONTEXT toplevel;
RCONTEXT *toplevelcontext;
RCONTEXT *globalcontext;
FILE *Rinputfile = NULL;
FILE *Rconsolefile = NULL;
FILE *Routputfile = NULL;
FILE *Rsinkfile = NULL;

FILE *yyin;
int browselevel;
VECREC *R_vtop;
long R_nvcell;
long R_collected;
int R_Console;

SEXP nilValue;
SEXP trueValue;
SEXP falseValue;
SEXP unboundValue;
SEXP missingArg;
SEXP commentSxp;
SEXP ParseText;

int ParseCnt;
int ParseError = 0;

SEXP Bracket2Symbol;
SEXP BracketSymbol;
SEXP ClassSymbol;
SEXP DimNamesSymbol;
SEXP DimSymbol;
SEXP DollarSymbol;
SEXP DotsSymbol;
SEXP DropSymbol;
SEXP LevelsSymbol;
SEXP ModeSymbol;
SEXP NamesSymbol;
SEXP NarmSymbol;
SEXP RowNamesSymbol;
SEXP SeedsSymbol;
SEXP TspSymbol;

int max_int;
double max_float;
int na_logical;
int na_integer;
int na_factor;
double na_real;
SEXP na_string;

char R_ImageName[256];
int R_Unnamed;
int R_DirtyImage;
int R_Init = 0;

void InitGlobalEnv()
{
	globalEnv = emptyEnv();
}

int evaldepth = 0;
int evalcnt = 0;

/*
 *  Main Loop:
 *
 *  It is assumed that at this point that operating system specific
 *  tasks (dialog window creation etc) have been performed.  We can
 *  now print a greeting, run the .First function and then enter the
 *  read-eval-print loop.
 */

void mainloop()
{
	SEXP cmd;
	int pflag;

	/* We always start interactive */
	R_Console = 1;

	Rprintf("\nR Version 0.1 Alpha, Copyright (C) 1995 Robert Gentleman and Ross Ihaka\n\n");
	Rprintf("R is free software and comes with ABSOLUTELY NO WARRANTY.\n");
	Rprintf("You are welcome to redistribute it under certain conditions.\n");
	Rprintf("Type `license()' for details.\n\n");


	InitMemory(R_nsize, R_vsize);
	InitNames();
	InitGlobalEnv();
	InitFunctionHashing();
	InitOptions();
	InitEd();
	InitArithmetic();
	R_Unnamed = 1;
	R_DirtyImage = 0;

	/* Initialize global context for error handling. */
	toplevel.nextcontext = NULL;
	toplevel.cstacktop = 0;
	toplevel.callflag = 0;

	/* The following section of code is where loading */
	/* of the initial Image happens.  Any errors which */
	/* If this the call to restore_image will die in */
	/* halfway graceful manner */

	R_Init = 0;
	setjmp(toplevel.cjmpbuf);
	if(R_Init == 0) {
		globalcontext = toplevelcontext = &toplevel;
		/* Initialized at declaration
		   or over-ridden in system dependent code.
		Rinputfile = NULL;
		Routputfile = NULL;
		*/
		R_Init = 1;
		RStartUp();
	}

	/* On initial entry to R, this code runs the .First */
	/* function.  It would be relatively easy to run */
	/* .First after each restore by moving the setjmp */
	/* call below to here and tweeking the value of R_Init */
	/* in the restoration code */

	R_Init = 0;
	setjmp(toplevel.cjmpbuf);
	globalcontext = toplevelcontext = &toplevel;
	if(R_Init == 0) {
		R_Init = 1;
		if (R_Unnamed) {
			strcpy(R_ImageName, "R-Image");
		}
		PROTECT(cmd = install(".First"));
		currentExp = findVar(cmd, globalEnv);
		if (currentExp != unboundValue && TYPEOF(currentExp) == CLOSXP) {
			PROTECT(currentExp = lang1(cmd));
			currentCall = nilValue;
			currentExp = eval(currentExp, globalEnv);
			UNPROTECT(1);
		}
		UNPROTECT(1);
	}

	/* This is the business end of the read-eval-print loop. */
	/* On image restoration the section above is executed, */
	/* but usually it is just from here down. */

	setjmp(toplevel.cjmpbuf);
	globalcontext = toplevelcontext = &toplevel;
	signal(SIGINT, onintr);
	ResetConsole();
	pflag = 1;
	browselevel = 0;
	commentSxp = CONS(nilValue, nilValue);
	CAR(commentSxp) = commentSxp;

	for (;;) {
	again:	stacktop = 0;
		if ((pflag == 1 || pflag == 2 || pflag == 3) && R_Console == 1)
			yyprompt((char*) CHAR(R_options_prompt));
		currentExp = NULL;
		yyinit();
		pflag = yyparse();
		if ((pflag == 1) || (pflag == 2))
			goto again;
		if (pflag == 0) {
			if (R_Console == 1)
				goto finished;
			fclose(yyin);
			ResetConsole();
#ifdef BISON
			yyrestart(yyin);
#endif
			pflag = 1;
			goto again;
		}
		if (currentExp) {
			evaldepth = 0;
			PROTECT(currentExp);
			RBusy(1);
			currentCall = nilValue;
			currentExp = eval(currentExp, globalEnv);
			UNPROTECT(1);
			if (visible)
				PrintValue(currentExp);
		}
	}
finished:
	PROTECT(cmd = install(".Last"));
	currentExp = findVar(cmd, globalEnv);
	if (currentExp != unboundValue && TYPEOF(currentExp) == CLOSXP) {
		PROTECT(currentExp = lang1(cmd));
		currentCall = nilValue;
		currentExp = eval(currentExp, globalEnv);
		UNPROTECT(1);
	}
	UNPROTECT(1);
	RCleanUp();
}

SEXP do_browser(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RCONTEXT *savetoplevelcontext;
	RCONTEXT *saveglobalcontext;
	RCONTEXT thiscontext;
	int savestack;
	int savebrowselevel;
	int saveevaldepth;
	int pflag = 1;
	SEXP topExp;

	savebrowselevel = browselevel + 1;

	/* save evaluator state information */
	savestack = stacktop;
	PROTECT(topExp = currentExp);
	savetoplevelcontext = toplevelcontext;
	saveglobalcontext = globalcontext;
	saveevaldepth = evaldepth;

	/* new context */
	thiscontext.nextcontext = NULL;
	thiscontext.cstacktop = 0;
	thiscontext.callflag = 0;
	thiscontext.cenvir = NULL;
	thiscontext.cloenv = rho;
	thiscontext.conexit = NULL;
	thiscontext.cend = NULL;
	setjmp(thiscontext.cjmpbuf);
	globalcontext = toplevelcontext = &thiscontext;
	browselevel = savebrowselevel;

	for (;;) {
	again:	stacktop = savestack;
		if ((pflag == 1 || pflag == 2 || pflag == 3) && R_Console == 1)
			yyprompt("Browse[%d]> ", browselevel);
		currentExp = NULL;
		yyinit();
		pflag = yyparse();
		if ((pflag == 1) || (pflag == 2))
			goto again;
		if (pflag == 0) {
			if (R_Console == 1) {
				ClearerrConsole();
				Rprintf("\n");
				goto finished;
			}
			fclose(yyin);
			ResetConsole();
#ifdef BISON
			yyrestart(yyin);
#endif
			pflag = 1;
			goto again;
		}
		if (currentExp) {
			evaldepth = saveevaldepth;
			PROTECT(currentExp);
			RBusy(1);
			currentCall = nilValue;
			currentExp = eval(currentExp, rho);
			UNPROTECT(1);
			if (visible)
				PrintValue(currentExp);
		}
	}
finished:
	UNPROTECT(1);
	stacktop = savestack;
	currentExp = topExp;
	toplevelcontext = savetoplevelcontext;
	globalcontext = saveglobalcontext;
	evaldepth = saveevaldepth;
	browselevel--;
	visible = 0;
	return nilValue;
}

SEXP do_quit(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	if(browselevel) {
		warning("can't quit from browser\n");
		visible = 0;
		return nilValue;
	}
	RCleanUp();
	exit(0);
	/*NOTREACHED*/
}

int yywrap()
{
	return feof(yyin);
}

void yyprompt(char *format,...)
{
	va_list(ap);
	if (DevInit)
		DevHold();
	va_start(ap, format);
	REvprintf(format, ap);
	va_end(ap);
	fflush(stdout);
	RBusy(0);
}
