/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define COUNTING

/* #define Macintosh */

#ifdef Macintosh
#include <fp.h>
#define PosixArith
#define QUICKDRAW_GRAPHICS
#else
#include <math.h>
#endif
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <limits.h>
#include <float.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include <time.h>

#define HSIZE		211	/* The size of the hash table for symbols */
#define MAXDIM		25	/* up to 25-way arrays only */
#define MAXELTSIZE	512	/* the largest number of characters in a vector element */

typedef int SEXPTYPE;
 
/*	Fundamental Data Types 
 *
 *	These are largely lisp influenced structures, with the
 *	exception of LGLSXP, FACTSXP, ORDSXP, INTSXP, REALSXP and STRSXP
 *	which are the element types for S-like data objects.
 */

#define NILSXP		0	/* nil */
#define SYMSXP		1	/* symbols */
#define LISTSXP		2	/* lists & dotted pairs */
#define CLOSXP		3	/* closures */
#define ENVSXP		4	/* environments */
#define PROMSXP		5	/* evaluated/unevaluated closure arguments */
#define LANGSXP		6	/* language constructs (special lists) */
#define SPECIALSXP	7	/* special forms */
#define BUILTINSXP	8	/* builtin non-special forms */
#define CHARSXP		9	/* "scalar" string type (internal only)*/
#define LGLSXP		10	/* logical vectors */
#define FACTSXP		11	/* unordered factors */
#define ORDSXP		12	/* ordered factors */
#define INTSXP		13	/* integer vectors */
#define REALSXP		14	/* real variables */
#define STRSXP		15	/* string vectors */
#define DOTSXP		16	/* dot-dot-dot object */
#define FRAMESXP	17	/* data frames */
#define ANYSXP		18	/* make "any" args work */

typedef struct SEXPREC {
	struct {
		unsigned int type  :  5;
		unsigned int obj   :  1;
		unsigned int named :  2;
		unsigned int gp    : 16;
		unsigned int mark  :  1;
		unsigned int       :  7;
	} sxpinfo;
	struct SEXPREC *attrib; 	/* Attributes */
	union {
		struct {
			int	length;
			union {
				char		*c;
				int		*i;
				double		*f;
				struct SEXPREC	**s;
			} type;
		} vecsxp;
		struct {
			int		offset;
		} primsxp;
		struct {
			struct SEXPREC *pname;
			struct SEXPREC *value;
			struct SEXPREC *internal;
		} symsxp;
		struct {
			struct SEXPREC *carval;
			struct SEXPREC *cdrval;
			struct SEXPREC *tagval;
		} listsxp;
		struct {
			struct SEXPREC *frame;
			struct SEXPREC *enclos;
		} envsxp;
		struct {
			struct SEXPREC *formals;
			struct SEXPREC *body;
			struct SEXPREC *env;
		} closxp;
		struct {
			struct SEXPREC *value;
			struct SEXPREC *expr;
			struct SEXPREC *env;
		} promsxp;
	} u;
} SEXPREC, *SEXP;


typedef SEXP (*CCODE)();

typedef struct {
	char	*name;		/* print name */
	CCODE	cfun;		/* c-code address */
	int	code;		/* offset within c-code */
	int	eval;		/* evaluate args? */
	int	arity;		/* function arity */
	int	gram;		/* pretty-print info */
	int	mark;		/* mark info for restore */
} FUNTAB_ENTRY;

	/* General Cons Cell Attributes */
#define ATTRIB(x)	((x)->attrib)
#define OBJECT(x)	((x)->sxpinfo.obj)
#define MARK(x)		((x)->sxpinfo.mark)
#define TYPEOF(x)	((x)->sxpinfo.type)
#define NAMED(x)	((x)->sxpinfo.named)

	/* Primitive Access Macros */
#define PRIMFUN(x)	(FunTab[(x)->u.primsxp.offset].cfun)
#define PRIMNAME(x)	(FunTab[(x)->u.primsxp.offset].name)
#define PRIMVAL(x)	(FunTab[(x)->u.primsxp.offset].code)
#define PRIMARITY(x)	(FunTab[(x)->u.primsxp.offset].arity)
#define PPINFO(x)	(FunTab[(x)->u.primsxp.offset].gram)


	/* Symbol Access Macros */
#define PRINTNAME(x)	((x)->u.symsxp.pname)
#define SYMVALUE(x)	((x)->u.symsxp.value)
#define INTERNAL(x)	((x)->u.symsxp.internal)


	/* Vector Access Macros */
#define LENGTH(x)	((x)->u.vecsxp.length)
#define CHAR(x)		((x)->u.vecsxp.type.c)
#define STRING(x)	((x)->u.vecsxp.type.s)
#define LOGICAL(x)	((x)->u.vecsxp.type.i)
#define FACTOR(x)	((x)->u.vecsxp.type.i)
#define INTEGER(x)	((x)->u.vecsxp.type.i)
#define REAL(x)		((x)->u.vecsxp.type.f)
#define LEVELS(x)	((x)->sxpinfo.gp)

	/* List Access Macros */
	/* These also work for ... objects */
#define LISTVAL(x)	((x)->u.listsxp)
#define TAG(e)		((e)->u.listsxp.tagval)
#define CAR(e)		((e)->u.listsxp.carval)
#define CDR(e)		((e)->u.listsxp.cdrval)
#define CAAR(e)		CAR(CAR(e))
#define CDAR(e)		CDR(CAR(e))
#define CADR(e)		CAR(CDR(e))
#define CDDR(e)		CDR(CDR(e))
#define CADDR(e)	CAR(CDR(CDR(e)))
#define CADDDR(e)	CAR(CDR(CDR(CDR(e))))
#define CONS(a, b)	cons((a), (b))
#define LCONS(a, b)	lcons((a), (b))			/* language lists */
#define MISSING(x)	((x)->sxpinfo.gp)	/* for closure calls */
#define SETCDR(x,y)	{SEXP X=(x), Y=(y); if(X != nilValue) CDR(X)=Y; else error("bad value");} 

	/* Closure Access Macros */
#define FORMALS(x)	((x)->u.closxp.formals)
#define BODY(x)		((x)->u.closxp.body)
#define CLOENV(x)	((x)->u.closxp.env)

	/* Environment Access Macros */
#define FRAME(x)	((x)->u.envsxp.frame)
#define ENCLOS(x)	((x)->u.envsxp.enclos)
#define NARGS(x)	((x)->sxpinfo.gp)	/* for closure calls */

	/* Promise Access Macros */
#define PREXPR(x)	((x)->u.promsxp.expr)
#define PRENV(x)	((x)->u.promsxp.env)
#define PRVALUE(x)	((x)->u.promsxp.value)

#define PROTECT(s)	protect(s)
#define UNPROTECT(n)	unprotect(n)

typedef struct {
	union {
		SEXP		backpointer;
		double		align;
	} u;
} VECREC, *VECP;

typedef struct RCONTEXT {
	struct RCONTEXT *nextcontext;
	jmp_buf cjmpbuf;
	int cstacktop;
	int callflag;
	SEXP cenvir;
	SEXP cloenv;
	SEXP conexit;
	void (*cend)();
} RCONTEXT, *context;

#define BACKPOINTER(v)	((v).u.backpointer)
#define BYTE2VEC(n)	(((n)>0)?(((n)-1)/sizeof(VECREC)+1):0)
#define INT2VEC(n)	(((n)>0)?(((n)*sizeof(int)-1)/sizeof(VECREC)+1):0)
#define FLOAT2VEC(n)	(((n)>0)?(((n)*sizeof(double)-1)/sizeof(VECREC)+1):0)
#define PTR2VEC(n)	(((n)>0)?(((n)*sizeof(SEXP)-1)/sizeof(VECREC)+1):0)

	/* Miscellaneous Definitions */

#define streql(s, t)	(!strcmp((s), (t)))

	/* Arithmetic and Relation Operators */

#define	PLUSOP	1
#define	MINUSOP	2
#define	TIMESOP	3
#define	DIVOP	4
#define	POWOP	5
#define	MODOP	6

#define	EQOP	1
#define	NEOP	2
#define	LTOP	3
#define	LEOP	4
#define	GEOP	5
#define	GTOP	6

extern int		errno;

extern SEXP		globalEnv;
extern SEXP		*argStack;
extern int		stacktop;
extern int		stacksize;
extern int		R_nsize;
extern int		R_vsize;
extern int		R_ssize;
extern int		nsize;
extern int		vsize;
extern int		visible;
extern SEXPREC		*nheap;
extern VECREC		*vheap;
extern SEXP		freeSEXP;
extern SEXP		currentExp;
extern SEXP		currentCall;
extern SEXP		returnedValue;
extern jmp_buf		stack_state;
extern SEXP		*SYMBOL_TABLE;
extern RCONTEXT		*globalcontext;
extern RCONTEXT 	*toplevelcontext;
extern FILE		*Rconsolefile;	/* Where error messages go */
extern FILE		*Routputfile;	/* Where output is currently going */
extern FILE		*Rsinkfile;	/* Current sink file */
extern FILE		*Rinputfile;	/* Where input is coming from */
extern FUNTAB_ENTRY	FunTab[];
extern VECREC   	*R_vtop;	/* free pointer for vector heap */
extern long		R_nvcell;	/* bytes allocated of vector heap */
extern long		R_collected;
extern int		R_Console;	/* indicates whether we are reading */
					/* from the console or not	*/
extern int		R_Init;
extern int		R_Unnamed;
extern int		R_DirtyImage;
extern char		R_ImageName[256];

extern SEXP		nilValue;
extern SEXP		trueValue;
extern SEXP		falseValue;
extern SEXP		unboundValue;
extern SEXP		missingArg;

extern SEXP		Bracket2Symbol;
extern SEXP		BracketSymbol;
extern SEXP		ClassSymbol;
extern SEXP		DimNamesSymbol;
extern SEXP		DimSymbol;
extern SEXP		DollarSymbol;
extern SEXP		DotsSymbol;
extern SEXP		DropSymbol;
extern SEXP		LevelsSymbol;
extern SEXP		ModeSymbol;
extern SEXP		NamesSymbol;
extern SEXP		NarmSymbol;
extern SEXP		ParseText;
extern SEXP		RowNamesSymbol;
extern SEXP		SeedsSymbol;
extern SEXP		TspSymbol;
extern SEXP		commentSxp;

extern int		ParseCnt;
extern int		ParseError;
extern int		max_int;
extern double		max_float;
extern int		na_logical;
extern int		na_integer;
extern int		na_factor;
extern double		na_real;
extern SEXP		na_string;

extern SEXP		R_options_prompt;
extern SEXP		R_options_editor;
extern SEXP		R_options_continue;
extern int		R_options_expressions;
extern int		R_options_width;
extern int		R_options_digits;
extern SEXP		R_options_contrasts[2];
 
#define MAX_INTEGER	max_int
#define MAX_REAL	max_float
#define NA_LOGICAL	na_logical
#define NA_INTEGER	na_integer
#define NA_FACTOR	na_factor
#define NA_REAL		na_real
#define NA_STRING	na_string

/* GUI HOOKS */
int cget(void);
void uncget(int);
void writecons(char*, int);
void ResetConsole(void);
void FlushConsole(void);
void ClearerrConsole(void);

SEXP allocArray(SEXPTYPE, SEXP);
SEXP allocMatrix(SEXPTYPE, int, int);
SEXP allocSExp(SEXPTYPE);
SEXP allocString(int);
SEXP allocVector(SEXPTYPE, int);
SEXP allocList(int);
SEXP append(SEXP, SEXP);
SEXP applyClosure(SEXP, SEXP, SEXP, SEXP);
SEXP applyRelOp(int, int, int);
SEXP asChar(SEXP);
int asInteger(SEXP);
int asLogical(SEXP);
double asReal(SEXP);
SEXP arraySubscript(int, SEXP, SEXP);
void begincontext(RCONTEXT*, int, SEXP, SEXP);
void CacheOptions(void);
void checkArity(SEXP, SEXP);
void CheckFormals(SEXP);
SEXP classgets(SEXP, SEXP);
SEXP coerceVector(SEXP, SEXPTYPE);
SEXP coerceList(SEXP, SEXPTYPE);
void compactPhase(void);
int conformable(SEXP, SEXP);
SEXP cons(SEXP, SEXP);
void copyListMatrix(SEXP, SEXP, int);
void copyMatrix(SEXP, SEXP, int);
void copyVector(SEXP, SEXP);
void CustomPrintValue(SEXP);
void defineVar(SEXP, SEXP, SEXP);
SEXP deparse1(SEXP,int);
SEXP dimgets(SEXP, SEXP);
SEXP dimnamesgets(SEXP, SEXP);
void dhsv2rgb(double,double,double,double*,double*,double*);
SEXP DropDims(SEXP);
void dump_image(FILE*, int, long, char*);
SEXP duplicate(SEXP);
SEXP emptyEnv(void);
void endcontext(RCONTEXT*);
void error(char*, ...);
void errorcall(SEXP, char*, ...);
SEXP eval(SEXP, SEXP);
SEXP evalList(SEXP, SEXP);
SEXP extendEnv(SEXP, SEXP, SEXP);
int factorsConform(SEXP, SEXP);
void findcontext(int, SEXP);
SEXP findVar(SEXP, SEXP);
SEXP findVar1(SEXP, SEXP, SEXPTYPE, int);
SEXP findVarInFrame(SEXP, SEXP);
SEXP findFun(SEXP, SEXP);
SEXP frameSubscript(int, SEXP, SEXP);
void gc(void);
SEXP getAttrib(SEXP, SEXP);
int get1index(SEXP,SEXP);
void gsetVar(SEXP, SEXP, SEXP);
int hashpjw(char*);
int IndexWidth(int);
void InitArithmetic(void);
void InitEd(void);
void InitFunctionHashing(void);
void InitGlobalEnv(void);
void InitMemory(int, int);
void InitNames(void);
void InitOptions(void);
void initStack(void);
SEXP install(char*);
void internalTypeCheck(SEXP, SEXP, SEXPTYPE);
int isArray(SEXP);
int isFactor(SEXP);
int isFrame(SEXP);
int isFunction(SEXP);
int isInteger(SEXP);
int isLanguage(SEXP);
int isList(SEXP);
int isLogical(SEXP);
int isMatrix(SEXP);
int isNull(SEXP);
int isNumeric(SEXP);
int isObject(SEXP);
int isOrdered(SEXP);
void isort(int*, int);
int isReal(SEXP);
int isString(SEXP);
int isSymbol(SEXP);
int isTs(SEXP);
int isUnordered(SEXP);
int isUserBinop(SEXP);
int isVector(SEXP);
int isVectorizable(SEXP);
void jump_to_toplevel(void);
void KillDevice(void);
SEXP lang1(SEXP);
SEXP lang2(SEXP, SEXP);
SEXP lang3(SEXP, SEXP, SEXP);
SEXP lang4(SEXP, SEXP, SEXP, SEXP);
SEXP lcons(SEXP, SEXP);
int length(SEXP);
SEXP levelsgets(SEXP, SEXP);
SEXP list1(SEXP);
SEXP list2(SEXP, SEXP);
SEXP list3(SEXP, SEXP, SEXP);
SEXP list4(SEXP, SEXP, SEXP, SEXP);
SEXP listAppend(SEXP, SEXP);
unsigned int LTYpar(SEXP, int);
void mainloop(void);
SEXP makeSubscript(SEXP, SEXP);
void markPhase(void);
void markSExp(SEXP);
SEXP mat2indsub(SEXP, SEXP);
SEXP matchArg(SEXP, SEXP*);
SEXP matchPar(char*, SEXP*);
SEXP mkCLOSXP(SEXP, SEXP, SEXP);
SEXP mkEnv(SEXP, SEXP, SEXP);
SEXP mkPRIMSXP (int, int);
SEXP mkPROMISE(SEXP, SEXP);
SEXP mkQUOTE(SEXP);
SEXP mkSYMSXP(SEXP, SEXP);
SEXP mkChar(char*);
SEXP mkFalse(void);
SEXP mkString(char*);
SEXP mkTrue(void);
SEXP namesgets(SEXP, SEXP);
int ncols(SEXP);
int nrows(SEXP);
SEXP nthcdr(SEXP, int);
void onintr();
SEXP parseSubargs(char*, SEXP, SEXP);
int pmatch(SEXP, SEXP, int);
void PrintDefaults(void);
void PrintValue(SEXP);
SEXP promiseArgs(SEXP, SEXP);
void protect(SEXP);
char *R_alloc(long, int);
void RBusy(int);
void RCleanUp(void);
void RStartUp(void);
void REvprintf(const char*, va_list);
void REprintf(char*, ...);
int restore_image(char*);
SEXP rownamesgets(SEXP,SEXP);
void Rprintf(char*, ...);
char *Rsprintf(char*, ...);
void Rvprintf(const char*, va_list);
void rsort(double *x, int);
int Rstrlen(char*);
void ResetComment();
void scanPhase(void);
SEXP setAttrib(SEXP, SEXP, SEXP);
void setIVector(int*, int, int);
void setRVector(double*, int, double);
void setSVector(SEXP*, int, SEXP);
void setVar(SEXP, SEXP, SEXP);
SEXP setVarInFrame(SEXP, SEXP, SEXP);
void sortVector(SEXP);
void ssort(SEXP*,int);
SEXPTYPE str2type(char*);
int StringTrue(char*);
void suicide(char*);
void SymbolShortcuts(void);
SEXP sysparent(int);
int tsConform(SEXP,SEXP);
SEXP tspgets(SEXP, SEXP);
SEXP type2str(SEXPTYPE);
void unbindVar(SEXP, SEXP);
void UNIMPLEMENTED(char *s);
void unmarkPhase(void);
void unprotect(int);
char *vmaxget(void);
void vmaxset(char*);
void WrongArgCount(char*);
void warning(char*, ...);
void yyinit(void);
int yyparse(void);
void yyprompt(char *format, ...);
int yywrap(void);
