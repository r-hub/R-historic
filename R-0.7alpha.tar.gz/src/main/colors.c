/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Graphics.h"

/*
 *	Internal Color and Linetype Representation
 *
 *	Colors are stored internally in integers.  Each integer is
 *	broken into four bytes.  The three most significant bytes
 *	are used to contain levels of red, green and blue.  These
 *	levels are integers in the range [0,100].  This range is
 *	more ``human compatible'' than the natural machine range
 *	of [0,255].  The low order byte is used to index into a
 *	color table with col= in function calls.  The fact that
 *	RGB specifications and indexes are mutually exclusive means
 *	that either can be used in in a col= specification.  In addition
 *	colors can be named using an internal table which provides
 *	a set of standard color names eg. "red", "green", ...
 *
 *	Linetypes are stored internally in integers.  An integer
 *	is interpreted as containing a sequence of 8 4-bit integers
 *	which give the lengths of up to 8 on-off line segments.
 *	The lengths are typically interpreted as pixels on a screen
 *	and as "points" in postscript.
 *
 *	Note: On a typical machine the value NA_INTEGER can be used
 *	to indicate an invalid value for both linetype for color.
 */

int ValidColor(int col)
{
	return (col & 255)==0;
}

static int ScaleColor(double x)
{
	if(x == NA_REAL || x < 0.0 || x > 1.0)
		error("invalid color intensity\n");
	return (int)(255*x);
}

SEXP do_hsv(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP c, h, s, v;
	double hh, ss, vv, r, g, b;
	int i, min, max, nh, ns, nv;

	checkArity(op, args);

	PROTECT(h = coerceVector(CAR(args),REALSXP));
	PROTECT(s = coerceVector(CADR(args),REALSXP));
	PROTECT(v = coerceVector(CADDR(args),REALSXP));

	nh = LENGTH(h); ns = LENGTH(s); nv = LENGTH(v);
	max = nh; if(max < ns) max = ns; if(max < nv) max = nv;
	min = nh; if(min > ns) min = ns; if(min > nv) min = nv;
	if(min <= 0) errorcall(call, "invalid argument length\n");

	c = allocVector(INTSXP, max);
	for(i=0 ; i<max ; i++) {
		hh = REAL(h)[i%nh];
		ss = REAL(s)[i%ns];
		vv = REAL(v)[i%nv];
		if(hh < 0 || hh > 1 || ss < 0 || ss > 1 || vv < 0 || vv > 1)
			errorcall(call, "invalid HSV color\n");
		hsv2rgb(hh,ss,vv,&r,&g,&b);
		((unsigned*)INTEGER(c))[i] = RGB(ScaleColor(r),ScaleColor(g),ScaleColor(b));
	}
	UNPROTECT(3);
	return c;
}

SEXP do_rgb(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP c, r, g, b;
	int i, min, max, nr, ng, nb;
	unsigned int ri, gi, bi;

	checkArity(op, args);

	PROTECT(r = coerceVector(CAR(args),REALSXP));
	PROTECT(g = coerceVector(CADR(args),REALSXP));
	PROTECT(b = coerceVector(CADDR(args),REALSXP));

	nr = LENGTH(r); ng = LENGTH(g); nb = LENGTH(b);
	max = nr; if(max < ng) max = ng; if(max < nb) max = nb;
	min = nr; if(min > ng) min = ng; if(min > nb) min = nb;
	if(min <= 0) errorcall(call, "invalid argument length\n");

	c = allocVector(INTSXP, max);
	for(i=0 ; i<max ; i++) {
		ri = ScaleColor(REAL(r)[i%nr]);
		gi = ScaleColor(REAL(g)[i%ng]);
		bi = ScaleColor(REAL(b)[i%nb]);
		((unsigned*)INTEGER(c))[i] = RGB(ri,gi,bi);
	}
	UNPROTECT(3);
	return c;
}

SEXP do_gray(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP lev, ans;
	double level;
	int i, ilevel, nlev;

	checkArity(op, args);

	lev = CAR(args) = coerceVector(CAR(args),REALSXP);
	nlev = LENGTH(CAR(args));
	ans = allocVector(INTSXP, nlev);
	for(i=0 ; i<nlev ; i++) {
		level = REAL(lev)[i];
		if(level == NA_REAL || level < 0 || level > 1)
			errorcall(call, "invalid gray level\n");
		ilevel = 255 * level;
		((unsigned*)INTEGER(ans))[i] = RGB(ilevel,ilevel,ilevel);
	}
	return ans;
}

static SEXP Colors(void)
{
	return install(".Colors");
}

static SEXP ColorTableSymbol(void)
{
	return install(".ColorTable");
}

static SEXP colorRGB;
static SEXP colorNames;
static int nColors;

void OpenColorList(void)
{
	colorRGB = SYMVALUE(Colors());
	colorNames = getAttrib(colorRGB, R_NamesSymbol);
	nColors = LENGTH(colorRGB);
	if(!isInteger(colorRGB) || isNull(colorNames))
		error("invalid list of system colors\n");
}

/* Compare strings ignoring case and squeezing out blanks */
static int ColorNamesMatch(char *s, char *t)
{
	for(;;) {
		if(*s == '\0' && *t == '\0') return 1;
		if(*s == ' ') {
			s++; continue;
		}
		if(*t == ' ') {
			t++; continue;
		}
		if(tolower(*s++) != tolower(*t++)) return 0;
	}
}

unsigned int NameToRGB(char *name)
{
	int i;
	for(i=0 ; i<nColors ; i++)
		if(ColorNamesMatch(CHAR(STRING(colorNames)[i]),name))
			return (unsigned)(INTEGER(colorRGB)[i]);
	error("invalid color name\n");
	/*NOTREACHED*/
}

void OpenColorTable(void)
{
	colorRGB = SYMVALUE(ColorTableSymbol());
	nColors = LENGTH(colorRGB);
	if(!isInteger(colorRGB))
		error("invalid or missing color table\n");
}

unsigned int NumberToRGB(unsigned int num)
{
	if(num & 255) {
		num = num & 255;
		if(num > nColors)
			error("invalid color table index\n");
		return ((unsigned int*)INTEGER(colorRGB))[num-1];
	}
	return num;
}

SEXP do_colorrgb(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, colors;
	int i, n;
	checkArity(op,args);

	/* color.rgb(NULL) = 255 (an invalid color) */

	if(isNull(colors = CAR(args)))
		return allocVector(INTSXP, 0);

	if(isString(colors)) {
		n = LENGTH(colors);
		ans = allocVector(INTSXP, n);
		OpenColorList();
		for(i=0 ; i<n ; i++)
			((unsigned*)INTEGER(ans))[i] =  NameToRGB(CHAR(STRING(colors)[i]));
	}
	else if(isInteger(colors)) {
		n = LENGTH(colors);
		ans = allocVector(INTSXP, n);
		OpenColorTable();
		for(i=0 ; i<n ; i++)
			((unsigned*)INTEGER(ans))[i] =  NumberToRGB((unsigned int)(INTEGER(colors)[i]));
	}
	else if(isReal(colors)) {
		n = LENGTH(colors);
		ans = allocVector(INTSXP, n);
		OpenColorTable();
		for(i=0 ; i<n ; i++)
			((unsigned*)INTEGER(ans))[i] =  NumberToRGB((unsigned int)(REAL(colors)[i]));
	}
	else
		errorcall(call, "invalid color\n");
	return ans;
}

unsigned int RGBpar(SEXP value, int index)
{
	if(isString(value)) {
		OpenColorList();
		return NameToRGB(CHAR(STRING(value)[index]));
	}
	else if(isInteger(value)) {
		OpenColorTable();
		if(INTEGER(value)[index] == NA_INTEGER) return NA_INTEGER;
		return NumberToRGB((unsigned int)(INTEGER(value)[index]));
	}
	else if(isReal(value)) {
		OpenColorTable();
		if(INTEGER(value)[index] == NA_REAL) return NA_INTEGER;
		return NumberToRGB((unsigned int)(REAL(value)[index]));
	}
	else if(isLogical(value)) {
		OpenColorTable();
		if(LOGICAL(value)[index] == NA_LOGICAL) return NA_INTEGER;
		if(LOGICAL(value)[index]) return GP->col;
		return NA_INTEGER;
	}
	else error("invalid color parameter\n");
	/*NOTREACHED*/
}

typedef struct {
	char *name;
	unsigned int pattern;
} LineTYPE;

static LineTYPE linetype[] = {
	{ "solid",	LTY_SOLID},
	{ "dashed",	LTY_DASHED},
	{ "dotted",	LTY_DOTTED},
	{ "dotdash",	LTY_DOTDASH},
	{ NULL,		0},
};

static int nlinetype = (sizeof(linetype)/sizeof(LineTYPE)-1);

unsigned int LTYpar(SEXP value, int index)
{
	char *p;
	int i, code, shift, digit;

	if(isString(value)) {
		for(i=0 ; linetype[i].name ; i++) {
			if(!strcmp(CHAR(STRING(value)[index]),linetype[i].name))
				return linetype[i].pattern;
		}
		code = 0;
		shift = 0;
		for(p=CHAR(STRING(value)[index]); *p ; p++) {
			if(*p < '1' || *p > '9')
				return NA_INTEGER;
			digit = *p - '0';
			code = code + (digit<<shift);
			shift = shift + 4;
		}
		return code;
	}
	else if(isInteger(value)) {
		code = INTEGER(value)[index];
		if(code==NA_INTEGER || code <= 0)
			return NA_INTEGER;
		code = (code-1) % nlinetype;
		return linetype[code].pattern;
	}
	else if(isReal(value)) {
		code = REAL(value)[index];
		if(code==NA_REAL || code <= 0)
			return NA_INTEGER;
		code = (code-1) % nlinetype;
		return linetype[code].pattern;
	}
	else error("invalid line type\n");
	/*NOTREACHED*/
}

SEXP LTYget(unsigned int lty)
{
	SEXP ans;
	int i, ndash;
	char dash[8];
	unsigned int l;

	for(i=0 ; linetype[i].name ; i++) {
		if(linetype[i].pattern == lty)
			return mkString(linetype[i].name);
	}

	l = lty; ndash = 0;
	for(i=0; i<8 && l&15 ; i++) {
		dash[ndash++] = l&15;
		l = l>>4;
	}
	PROTECT(ans = allocVector(STRSXP, 1));
	STRING(ans)[0] = allocString(ndash);
	for(i=0 ; i<ndash ; i++) {
		CHAR(STRING(ans)[0])[i] = dash[i] + '0';
	}
	UNPROTECT(1);
	return ans;
}

SEXP do_linetype(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, ltys;
	int i, n;

	checkArity(op,args);

	if(isNull(ltys = CAR(args)))
		return allocVector(INTSXP, 0);

	if(isString(ltys) || isInteger(ltys) || isReal(ltys)) {
		n = LENGTH(ltys);
		ans = allocVector(INTSXP, n);
		for(i=0 ; i<n ; i++)
			((unsigned*)INTEGER(ans))[i] =  LTYpar(ltys,i);
	}
	else
		errorcall(call, "invalid lty\n");
	return ans;
}
