/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

	/* The following table shows the codes which have been */
	/* assigned to the type combinations in assignments of */
	/* the form  "x[s] <- y".  Here the type of y is given */
	/* across the top of the table and the type of x at the */
	/* side. */

		/*--------------------------------*/
		/*      LGL FACT ORD INT REAL STR */
		/*  LGL   1    7  13  19   25  31 */
		/* FACT   2    8  14  20   26  32 */
		/*  ORD   3    9  15  21   27  33 */
		/*  INT   4   10  16  22   28  34 */
		/* REAL   5   11  17  23   29  35 */
		/*  STR   6   12  18  24   30  36 */
		/*--------------------------------*/

	/* The following table (which is laid out as described */
	/* above) contains "*" for those combinations where the */
	/* assignment has been implemented.  Some assignments */
	/* do not make a great deal of sense and we have chosen */
	/* to leave them unimplemented, although the addition */
	/* of new assignment combinations represents no great */
	/* difficulty. */

		/*--------------------------------*/
		/*      LGL FACT ORD INT REAL STR */
		/*  LGL   *    ?   ?   *    *   * */
		/* FACT   ?    *                * */
		/*  ORD   ?        *            * */
		/*  INT   *            *    *   * */
		/* REAL   *            *    *   * */
		/*  STR   *    *   *   *    *   * */
		/*--------------------------------*/

	/* The question marks in this table indicate combinations */
	/* which should probably be implemented, but which as yet */
	/* have not been.  The reason for the LGL row and column */
	/* are because we want to allow any assignment of the form */
	/* "x[s] <- NA" (col) and because the interpreted "ifelse" */
	/* requires assignment into a logical object. */


static void CompatibleFactorsCheck(SEXP x, SEXP y)
{
	if(!factorsConform(x,y))
		error("incompatible factors in subset assignment\n");
}

static void SetArgsforUseMethod(SEXP x)
{
	char buf[4];
	int i=1;

	if( TAG(x) == R_NilValue)
		TAG(x) = install("x");
	for(x=CDR(x); x!=R_NilValue ; x=CDR(x)) {
		if(TAG(x) == R_NilValue) {
			if(i<10)
				sprintf(buf,"..%d",i);
			else
				sprintf(buf,".%d",i);
			TAG(x)=install(buf);
			i++;
		}
	}
}

static SEXP vectorAssign(SEXP x, SEXP s, SEXP y)
{
	SEXP dim, index;
	int i, ii, iy, n, ny, which;

		/* Check to see if we have special matrix */
		/* subscripting.  If we do, make a real */
		/* subscript vector. */

	if(isNull(x) && isNull(y)) {
		return R_NilValue;
	}

	dim = getAttrib(x, R_DimSymbol);
	if (isMatrix(s) && isArray(x) &&
			(isInteger(s) || isReal(s)) &&
			ncols(s) == length(dim)) {
		s = mat2indsub(dim, s);
	}
	PROTECT(s);

	ny = length(y);
	PROTECT(index = makeSubscript(x, s));
	n = length(index);

	if (n > 0 && ny == 0)
		error("nothing to replace with\n");

	if (n > 0 && n % ny)
		error("no of items to replace is not a multiple of replacement length\n");

	which = TYPEOF(x)-CHARSXP + (STRSXP-CHARSXP) * (TYPEOF(y)-LGLSXP);

		/* Here we make sure that the LHS has */
		/* been coerced into a form which can */
		/* accept elements from the RHS. */

	switch(which) {
	case  1:
	case  4:
	case  5:
	case 22:
	case 23:
	case 29:
	case 36:
		break;
	case  8:
	case 15:
		CompatibleFactorsCheck(x, y);
		break;
	case 19:
		x = coerceVector(x, INTSXP);
		break;
	case 25:
	case 28:
		x = coerceVector(x, REALSXP);
		break;
	case  6:
	case 12:
	case 18:
	case 24:
	case 30:
		y = coerceVector(y, STRSXP);
		break;
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
		x = coerceVector(x, STRSXP);
		break;
	default:
		error("incompatible types in subset assignment\n");
	}

	PROTECT(x);

		/* Nasty bug fixed here.  When array elements */
		/* are being permuted the rhs must be duplicated */
		/* or the elements get trashed. */

	if (x == y) PROTECT(y = duplicate(y));
	else PROTECT(y);

		/* Note that we are now committed. */
		/* Since we are mutating existing */
		/* objects any changes we make now */
		/* are (likely to be) permanent. */
		/* Beware! */

	switch(which) {
	case  1:
	case  4:
	case  8:
	case 15:
	case 19:
	case 22:
		for (i=0; i<n; i++) {
			ii = INTEGER(index)[i];
			if(ii == NA_INTEGER) continue;
			ii = ii - 1;
			INTEGER(x)[ii] = INTEGER(y)[i % ny];
		}
		break;
	case  5:
	case 23:
		for (i=0; i<n; i++) {
			ii = INTEGER(index)[i];
			if(ii == NA_INTEGER) continue;
			ii = ii - 1;
			iy = INTEGER(y)[i % ny];
			if(iy == NA_INTEGER)
				REAL(x)[ii] = NA_REAL;
			else
				REAL(x)[ii] = iy;
		}
		break;
	case 25:
	case 28:
	case 29:
		for (i=0; i<n; i++) {
			ii = INTEGER(index)[i];
			if(ii == NA_INTEGER) continue;
			ii = ii - 1;
			REAL(x)[ii] = REAL(y)[i % ny];
		}
		break;
	case  6:
	case 12:
	case 18:
	case 24:
	case 30:
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
	case 36:
		for (i=0; i<n; i++) {
			ii = INTEGER(index)[i];
			if(ii == NA_INTEGER) continue;
			ii = ii - 1;
			STRING(x)[ii] = STRING(y)[i % ny];
		}
		break;
	}
	UNPROTECT(4);
	return x;
}

static SEXP matrixAssign(SEXP x, SEXP s, SEXP y)
{
	int i, j, ii, jj, ij, iy, k, which;
	int nr, ny;
	int nrs, ncs;
	SEXP sr, sc;

	if (!isMatrix(x))
		error("incorrect number of subscripts on array\n");

	nr = nrows(x);
	ny = LENGTH(y);

		/* s has been protected. */
		/* No GC problems here. */

	sr = CAR(s) = arraySubscript(0, CAR(s), x);
	sc = CADR(s) = arraySubscript(1, CADR(s), x);
	nrs = LENGTH(sr);
	ncs = LENGTH(sc);

	if ((length(sr) * length(sc)) % length(y))
		error("no of items to replace is not a multiple of replacement length\n");

	which = TYPEOF(x)-CHARSXP + (STRSXP-CHARSXP) * (TYPEOF(y)-LGLSXP);

	switch(which) {
	case  4:
	case  5:
	case 22:
	case 23:
	case 29:
	case 36:
		break;
	case  8:
	case 15:
		CompatibleFactorsCheck(x, y);
		break;
	case 19:
		x = coerceVector(x, INTSXP);
		break;
	case 25:
	case 28:
		x = coerceVector(x, REALSXP);
		break;
	case  6:
	case 12:
	case 18:
	case 24:
	case 30:
		y = coerceVector(y, STRSXP);
		break;
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
		x = coerceVector(x, STRSXP);
		break;
	default:
		error("incompatible types in subset assignment\n");
	}

	PROTECT(x);

		/* Nasty bug fixed here.  When array elements */
		/* are being permuted the rhs must be duplicated */
		/* or the elements get trashed. */

	if (x == y) PROTECT(y = duplicate(y));
	else PROTECT(y);

	k = 0;
	switch(which) {
	case  1:
	case  4:
	case  8:
	case 15:
	case 19:
	case 22:
		for (j = 0; j < ncs; j++) {
			jj = INTEGER(sc)[j];
			if(jj == NA_INTEGER) continue;
			jj = jj - 1;
			for (i = 0; i < nrs; i++) {
				ii = INTEGER(sr)[i];
				if(ii == NA_INTEGER) continue;
				ii = ii - 1;
				ij = ii + jj * nr;
				INTEGER(x)[ij] = INTEGER(y)[k];
				k = (k + 1) % ny;
			}
		}
		break;
	case  5:
	case 23:
		for (j = 0; j < ncs; j++) {
			jj = INTEGER(sc)[j];
			if(jj == NA_INTEGER) continue;
			jj = jj - 1;
			for (i = 0; i < nrs; i++) {
				ii = INTEGER(sr)[i];
				if(ii == NA_INTEGER) continue;
				ii = ii - 1;
				ij = ii + jj * nr;
				iy = INTEGER(y)[k];
				if(iy == NA_INTEGER)
					REAL(x)[ij] = NA_REAL;
				else
					REAL(x)[ij] = iy;
				k = (k + 1) % ny;
			}
		}
		break;
	case 25:
	case 28:
	case 29:
		for (j = 0; j < ncs; j++) {
			jj = INTEGER(sc)[j];
			if(jj == NA_INTEGER) continue;
			jj = jj - 1;
			for (i = 0; i < nrs; i++) {
				ii = INTEGER(sr)[i];
				if(ii == NA_INTEGER) continue;
				ii = ii - 1;
				ij = ii + jj * nr;
				REAL(x)[ij] = REAL(y)[k];
				k = (k + 1) % ny;
			}
		}
		break;
	case  6:
	case 12:
	case 18:
	case 24:
	case 30:
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
	case 36:
		for (j = 0; j < ncs; j++) {
			jj = INTEGER(sc)[j];
			if(jj == NA_INTEGER) continue;
			jj = jj - 1;
			for (i = 0; i < nrs; i++) {
				ii = INTEGER(sr)[i];
				if(ii == NA_INTEGER) continue;
				ii = ii - 1;
				ij = ii + jj * nr;
				STRING(x)[ij] = STRING(y)[k];
				k = (k + 1) % ny;
			}
		}
		break;
	default:
		error("incompatible types in subset assignment\n");
	}
	UNPROTECT(2);
	return x;
}

static SEXP arrayAssign(SEXP x, SEXP s, SEXP y)
{
	int i, j, ii, iy, jj, k, n, ny, which;
	int **subs, *index, *bound, *offset;
	SEXP dims, tmp;
	char *vmax = vmaxget();

	PROTECT(dims = getAttrib(x, R_DimSymbol));
	if (dims == R_NilValue || (k = LENGTH(dims)) != length(s))
		error("incorrect number of subscripts\n");

	subs = (int**)R_alloc(k, sizeof(int*));
	index = (int*)R_alloc(k, sizeof(int));
	bound = (int*)R_alloc(k, sizeof(int));
	offset = (int*)R_alloc(k, sizeof(int));

	ny = LENGTH(y);

		/* Expand the list of subscripts. */
		/* s is protected, so no GC problems here */

	tmp = s;
	for (i = 0; i < k; i++) {
		CAR(tmp) = arraySubscript(i, CAR(tmp), x);
		tmp = CDR(tmp);
	}

	n = 1;
	tmp = s;
	for (i = 0; i < k; i++) {
		index[i] = 0;
		subs[i] = INTEGER(CAR(tmp));
		bound[i] = LENGTH(CAR(tmp));
		n *= bound[i];
		tmp = CDR(tmp);
	}

	if (n % length(y))
		error("no of elements to replace is not a multiple of replacement length\n");

	offset[0] = 1;
	for (i = 1; i < k; i++)
		offset[i] = offset[i - 1] * INTEGER(dims)[i - 1];

        which = TYPEOF(x)-CHARSXP + (STRSXP-CHARSXP) * (TYPEOF(y)-LGLSXP);

	switch(which) {
	case  4:
	case  5:
	case 22:
	case 23:
	case 29:
	case 36:
		break;
	case  8:
	case 15:
		CompatibleFactorsCheck(x, y);
		break;
	case 19:
		x = coerceVector(x, INTSXP);
		break;
	case 25:
	case 28:
		x = coerceVector(x, REALSXP);
		break;
	case  6:
	case 12:
	case 18:
	case 24:
	case 30:
		y = coerceVector(y, STRSXP);
		break;
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
		x = coerceVector(x, STRSXP);
		break;
	default:
		error("incompatible types in subset assignment\n");
	}

	PROTECT(x);

		/* Nasty bug fixed here.  When array elements */
		/* are being permuted the rhs must be duplicated */
		/* or the elements get trashed. */

	if (x == y) PROTECT(y = duplicate(y));
	else PROTECT(y);

	for (i = 0; i < n; i++) {
		ii = 0;
		for (j = 0; j < k; j++) {
			jj = subs[j][index[j]];
			if(jj == NA_INTEGER) goto next_i;
			ii += (jj - 1) * offset[j];
		}

		switch (which) {
		case  1:
		case  4:
		case  8:
		case 15:
		case 19:
		case 22:
			INTEGER(x)[ii] = INTEGER(y)[i % ny];
			break;
		case  5:
		case 23:
			iy = INTEGER(y)[i % ny];
			if(iy == NA_INTEGER)
				REAL(x)[ii] = NA_REAL;
			else
				REAL(x)[ii] = iy;
			break;
		case 25:
		case 28:
		case 29:
			REAL(x)[ii] = REAL(y)[i % ny];
			break;
		case  6:
		case 12:
		case 18:
		case 24:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
			STRING(x)[ii] = STRING(y)[i % ny];
			break;
		}
		if (n > 1) {
			j = 0;
			while (++index[j] >= bound[j]) {
				index[j] = 0;
				j = ++j % k;
			}
		}
	next_i:
		;
	}
	UNPROTECT(3);
        vmaxset(vmax);
	return x;
}

static SEXP SimpleListAssign(SEXP x, SEXP s, SEXP y)
{
	SEXP index, yi, yp;
	int i, ii, n, nx, ny;

	if (length(s) > 1)
		error("invalid number of subscripts to list assign\n");

	PROTECT(index = makeSubscript(x, CAR(s)));
	n = length(index);

		/* The shallow copy here is so that */
		/* permuting a list's elements will work */

	if(isList(y) || isFrame(y) || isLanguage(y) ) {
		PROTECT(y);
		ny = NAMED(y);
		yi = allocList(length(y));
		for(yp=yi ; yp!=R_NilValue ; yp=CDR(yp)) {
			CAR(yp) = CAR(y);
			NAMED(CAR(yp)) = ny | NAMED(CAR(y));
			y = CDR(y);
		}
		UNPROTECT(1);
		PROTECT(y = yi);
	}
	else PROTECT(y = CONS(y, R_NilValue));
	ny = length(y);
	nx = length(x);

	if (n > 0 && ny == 0)
		error("nothing to replace with\n");

	if (n > 0 && n % ny)
		error("no of items to replace is not a multiple of replacement length\n");

	for (i=0; i<n; i++) {
		ii = INTEGER(index)[i];
		if(ii == NA_INTEGER) continue;
		ii = ii - 1;
		yi = CAR(nthcdr(y, i % ny));
		if(NAMED(y) || NAMED(yi)) yi = duplicate(yi);
		else NAMED(yi) = 1;
		CAR(nthcdr(x, ii % nx)) = yi;
	}
	UNPROTECT(2);
	return x;
}

static SEXP listRemove(SEXP x, SEXP s)
{
	SEXP a, pa, px;
	int i, ii, *ind, ns, nx;
	char *h;

	h = vmaxget();
	nx = length(x);
	PROTECT(s = makeSubscript(x, s));
	ns = length(s);
	ind = (int*)R_alloc(nx, sizeof(int));
	for(i=0 ; i<nx ; i++)
		ind[i] = 1;
	for(i=0 ; i<ns ; i++) {
		ii = INTEGER(s)[i];
		if(ii != NA_INTEGER)
			ind[ii - 1] = 0;
	}
	PROTECT(a = CONS(R_NilValue, R_NilValue));
	px = x;
	pa = a;
	for(i=0 ; i<nx ; i++) {
		if(ind[i]) {
			CDR(pa) = px;
			px = CDR(px);
			pa = CDR(pa);
			CDR(pa) = R_NilValue;
		}
		else {
			px = CDR(px);
		}
	}
	UNPROTECT(2);
	vmaxset(h);
	return CDR(a);
}

SEXP listAssign1(SEXP x, SEXP subs, SEXP y)
{
	SEXP ax, ay, px, py;
	int i, nsubs, ny;

	nsubs = length(subs);
	switch (nsubs) {
	case 0:
		break;
	case 1:
		if(y == R_NilValue)
			x = listRemove(x, CAR(subs));
		else
			x = SimpleListAssign(x, subs, y);
		break;
	default:
	  	PROTECT(ax = allocArray(STRSXP, getAttrib(x, R_DimSymbol)));
		for(px=x, i=0 ; px!=R_NilValue ; px = CDR(px))
			STRING(ax)[i++] = CAR(px);
		setAttrib(ax, R_DimNamesSymbol, getAttrib(x, R_DimNamesSymbol));
		if(isList(y)) {
			ny = length(y);
			PROTECT(ay = allocVector(STRSXP, ny));
			for(py=y, i=0 ; py!=R_NilValue ; py = CDR(py))
				STRING(ay)[i++] = CAR(py);
		}
		else {
			ny = 1;
			PROTECT(ay = allocVector(STRSXP, 1));
			STRING(ay)[0] = y;
		}
		if(nsubs == 2) ax = matrixAssign(ax, subs, ay);
		else ax = arrayAssign(ax, subs, ay);
		for(px=x, i=0 ; px!=R_NilValue ; px = CDR(px))
			CAR(px) = duplicate(STRING(ax)[i++]);
		UNPROTECT(2);
		break;
	}
}

static SEXP frameAssign(SEXP x, SEXP s, SEXP y)
{
	int i, j, ii, jj, ij, k;
	int nr, nc, ncy;
	int nrs, ncs;
	SEXP sr, sc, ss, xp, yp;

	nr = length(CAR(x));
	nc = length(x);

		/* s has been protected. */
		/* No GC problems here. */

	if (length(s) == 1) {
		PROTECT(sr = frameSubscript(0, R_NilValue, x));
		PROTECT(sc = frameSubscript(1, CAR(s), x));
	}
	else if (length(s) == 2) {
		PROTECT(sr = frameSubscript(0, CAR(s), x));
		PROTECT(sc = frameSubscript(1, CADR(s), x)); 
	}
	else error("incorrect number of subscripts on data frame\n");

	nrs = LENGTH(sr);
	ncs = LENGTH(sc);

	if(isList(y) || isFrame(y)) PROTECT(y);
	else PROTECT(y = CONS(y, R_NilValue));
	ncy = length(y);

        PROTECT(ss = allocList(2));

	for(i=0 ; i<ncs ; i++) {
		ii = INTEGER(sc)[i]-1;
	 	xp = nthcdr(x, ii%nc);
		yp = nthcdr(y, ii%ncy);

		if ((length(sr) * length(sc)) % length(CAR(yp)))
			error("no of items to replace is not a multiple of replacement length\n");

		if(isMatrix(CAR(xp))) {
			CAR(ss) = sr;
			CADR(ss) = arraySubscript(1,  R_MissingArg, CAR(xp));
			CAR(xp) = matrixAssign(CAR(xp), ss, CAR(yp));
		}
		else {
			CAR(xp) = vectorAssign(CAR(xp), sr, CAR(yp));
		}
	}
	UNPROTECT(4);
	return x;
}

/* 
   we don't want to evaluate the last arg 
   it has already been evaluated 
*/
static SEXP EvalSubassignArgs(SEXP el, SEXP rho)
{
        SEXP h, t;
        if(CDR(el) == R_NilValue)
                return el;
        if(CAR(el) == R_MissingArg)
                PROTECT(h = R_MissingArg);
        else
                PROTECT(h = eval(CAR(el), rho));
        t = EvalSubassignArgs(CDR(el), rho);
        UNPROTECT(1);
        h = CONS(h, t);
        TAG(h) = TAG(el);
        return h;
}  

static void SubAssignArgs(SEXP args, SEXP *x, SEXP *s, SEXP *y)
{
	SEXP p;
	*x = CAR(args);
	*s = p = CDR(args);
	while(CDDR(p) != R_NilValue)
		p = CDR(p);
	*y = CADR(p);
	CDR(p) = R_NilValue;
}

	/* The [<- operator.  x is the vector that is */
	/* to be assigned into, y is the vector  that */
	/* is going to provide the new values and s is */
	/* the vector of subscripts that are going to */
	/* be replaced.  On entry (CAR(args)) and the last */
	/* argument have been evaluated been the remainder */
	/* of args have not. */
	/* If this was called directly the CAR(args) and the last */
	/* arg won't have been. */

SEXP do_subassign(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP subs, x, y;
	int i, nsubs;
	RCNTXT cntxt;

	if(isObject(CAR(args)) && CAR(call) != install("[<-.default")) {
		/*SetArgsforUseMethod(args); */
		begincontext(&cntxt,CTXT_RETURN, call, rho, rho, args);
		if(usemethod("[<-", call, args, rho, &y)) {
			endcontext(&cntxt);
			return y;
		}
		endcontext(&cntxt);
        }
	PROTECT(CDR(args) = EvalSubassignArgs(CDR(args), rho));
	if (NAMED(CAR(args)) == 2) {
		x = CAR(args) = duplicate(CAR(args));
	}
	SubAssignArgs(args, &x, &subs, &y);

		/* We can't modify an object which is named in */
		/* another environment.  NAMED(x)==2 indicates */
		/* that x was obtained through a promise evaluation */
		/* and hence it may be bound to a symbol elsewhere. */
		/* This will duplicate more often than necessary, */
		/* but saves over always duplicating. */

	nsubs = length(subs);
	if (isVector(x)) {
		switch (nsubs) {
		case 0:
			break;
		case 1:
			x = vectorAssign(x, CAR(subs), y);
			break;
		case 2:
			x = matrixAssign(x, subs, y);
			break;
		default:
			x = arrayAssign(x, subs, y);
			break;
		}
	}
	else if(isList(x) || isLanguage(x)) {
		x = listAssign1(x, subs, y);
	}
	else error("type error in subset assignment\n");

		/* Note the setting of NAMED(x) to zero here. */
		/* This means that the following assignment will */
		/* not duplicate the value.  This works because */
		/* at this point, x is guaranteed to have have */
		/* at most one symbol bound to it.  It does mean */
		/* that there will be multiple reference problems */
		/* if "[<-" is used in a naked fashion. */

	UNPROTECT(1);
	NAMED(x) = 0;
	return x;
}


	/* The [[<- assignment, it should be fast. */
	/* args[1] = object being subscripted */
	/* args[2] = list of subscripts */
	/* args[3] = replacement values */

SEXP do_subassign2(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP dims, index, names, subs, x, y, obj;
	int i, ndims, nsubs, offset, which;
	RCNTXT cntxt;

	if(isObject(CAR(args)) && CAR(call) != install("[[<-.default") ) {
		/*SetArgsforUseMethod(args);*/
		begincontext(&cntxt,CTXT_RETURN, call, rho, rho, args);
		if(usemethod("[[<-", call, args, rho, &y)) {
			endcontext(&cntxt);
			return y;
		}
		endcontext(&cntxt);
        }

	PROTECT(CDR(args) = EvalSubassignArgs(CDR(args), rho));
	SubAssignArgs(args, &x, &subs, &y);
	if(isNull(x) && isNull(y)) {
		UNPROTECT(1);
		return R_NilValue;
	}
	if (NAMED(x) == 2) {
		CAR(args) = x = duplicate(x);
	}
	dims = getAttrib(x, R_DimSymbol);
	ndims = length(dims);
	nsubs = length(subs);
	if (!isList(x) && !isLanguage(x) && length(y) > 1)
		error("number of elements supplied larger than number of elements to replace\n");

	if (isVector(x)) {
		if (nsubs == 1) {
			offset = get1index(CAR(subs), getAttrib(x, R_NamesSymbol));
			if (offset < 0 || offset >= LENGTH(x))
				error("[[]] subscript out of bounds\n");
		}
		else {
			if (ndims != nsubs)
				error("[[]] improper number of subscripts\n");
			PROTECT(index = allocVector(INTSXP, ndims));
			names = getAttrib(x, R_DimNamesSymbol);
			for (i = 0; i < ndims; i++) {
				INTEGER(index)[i] = get1index(CAR(subs), isList(names) ? CAR(names) : R_NilValue);
				subs = CDR(subs);
				if (INTEGER(index)[i] < 0 || INTEGER(index)[i] >= INTEGER(dims)[i])
					error("[[]] subscript out of bounds\n");
			}
			offset = 0;
			for (i = (ndims - 1); i > 0; i--)
				offset = (offset + INTEGER(index)[i]) * INTEGER(dims)[i - 1];
			offset += INTEGER(index)[0];
			UNPROTECT(1);
		}
		which = TYPEOF(x)-CHARSXP + (STRSXP-CHARSXP) * (TYPEOF(y)-LGLSXP);
		switch (which) {
			case  8:
			case 15:
				CompatibleFactorsCheck(x, y);
				break;
			case 28:
				x = coerceVector(x, REALSXP);
				break;
		}
		switch (which) {
			case  8:
			case 15:
			case  1:
			case 22:
				INTEGER(x)[offset] = INTEGER(y)[0];
				break;
			case  5:
			case 23:
				if(INTEGER(y)[0] == NA_INTEGER)
					REAL(x)[offset] = NA_REAL;
				else
					REAL(x)[offset] = INTEGER(y)[0];
				break;
			case 28:
			case 29:
				REAL(x)[offset] = REAL(y)[0];
				break;
			case 36:
				STRING(x)[offset] = STRING(y)[0];
				break;
			default:
				error("incompatible types in subset assignment\n");
		}
	}
	else if (isList(x) || isLanguage(x) ) {
		if(NAMED(y)) y = duplicate(y);
		PROTECT(y);
		if(nsubs == 1) {
			if(isNull(y)) {
				x = listRemove(x, CAR(subs));
			}
			else {
				PROTECT(y = CONS(y, R_NilValue));
				x = SimpleListAssign(x, subs, y);
				UNPROTECT(1);
			}
		}
		else {
			if (ndims != nsubs)
				error("[[]] improper number of subscripts\n");
			PROTECT(index = allocVector(INTSXP, ndims));
			names = getAttrib(x, R_DimNamesSymbol);
			for (i = 0; i < ndims; i++) {
				INTEGER(index)[i] = get1index(CAR(subs), CAR(names));
				subs = CDR(subs);
				if (INTEGER(index)[i] < 0 || INTEGER(index)[i] >= INTEGER(dims)[i])
					error("[[]] subscript out of bounds\n");
			}
			offset = 0;
			for (i = (ndims - 1); i > 0; i--)
				offset = (offset + INTEGER(index)[i]) * INTEGER(dims)[i - 1];
			offset += INTEGER(index)[0];
			CAR(nthcdr(x, offset)) = duplicate(y);
			UNPROTECT(1);
		}
		UNPROTECT(1);
	}
	else error("type error in subset assignment\n");

	UNPROTECT(1);
	NAMED(x) = 0;
	return x;
}

#ifdef OLD
static void FrameClassFix(SEXP x)
{
	SEXP xcar, xp;
	int nr = -1;
	for(xp=x ; xp!=R_NilValue ; xp=CDR(xp)) {
		xcar = CAR(xp);
		if(isArray(xcar)) {
			if(isMatrix(xcar)) {
				if(nr == -1)
					nr = nrows(xcar);
				else if(nr != nrows(xcar))
					goto unclass;
			}
			else goto unclass;
		}
		else if(isVector(xcar)) {
			if(nr == -1)
				nr = length(xcar);
			else if(nr != length(xcar))
				goto unclass;
				
		}
		else goto unclass;
	}
	return;
unclass:
	PROTECT(x);
	setAttrib(x, R_ClassSymbol, R_NilValue);
	UNPROTECT(1);
	return;
}
#endif
  
SEXP do_subassign3(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, nlist, val, t;

	checkArity(op, args);

	PROTECT(x = CAR(args));

	if (!isList(x) && !isLanguage(x))
		error("$ used on non-list\n");

	val = CADDR(args);
	if(NAMED(val)) val = duplicate(val);
	PROTECT(val);

	nlist = CADR(args);
	if (isString(nlist))
		nlist = install(CHAR(STRING(nlist)[0]));

	if(TAG(x) == nlist ) {
		if(val == R_NilValue)
			x= CDR(x);
		else
			CAR(x)= val;
	}
	else {
		for (t = x; t != R_NilValue; t = CDR(t))
			if (TAG(CDR(t)) == nlist) {
				if( val == R_NilValue )
					CDR(t)=CDDR(t);
				else
					CAR(CDR(t)) = val;
				break;
			}
			else if (CDR(t) == R_NilValue && val != R_NilValue) {
				SETCDR(t, allocSExp(LISTSXP));
				TAG(CDR(t)) = nlist;
				CADR(t) = val;
				break;
			}
	}
	if( x== R_NilValue && val != R_NilValue ) {
		x=allocList(1);
		CAR(x) = val;
		TAG(x) = nlist;
	}
	UNPROTECT(2);
	FrameClassFix(x);
	NAMED(x) = 0;
	return x;
}
 
	/* Data Frame Subsetting Methods */

SEXP do_subassigndf(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP subs, x, y; 
	PROTECT(args = EvalSubassignArgs(args, rho));
	SubAssignArgs(args, &x, &subs, &y);
	switch(length(subs)) {
		case 1:
			FrameClassFix(x = listAssign1(x, subs, y));
			break;
		case 2:
			x = frameAssign(x, subs, y);
			break;
		default:
			errorcall(call, "invalid number of subscripts\n");
	}
	UNPROTECT(1);
	return x;
}

SEXP do_subassigndf2(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP subs, x, y; 
	PROTECT(args = EvalSubassignArgs(args, rho));
	SubAssignArgs(args, &x, &subs, &y);
	switch(length(subs)) {
		case 1:
			FrameClassFix(x = listAssign1(x, subs, y));
			break;
		case 2:
			x = frameAssign(x, subs, y);
			break;
		default:
			errorcall(call, "invalid number of subscripts\n");
	}
	UNPROTECT(1);
	return x;
}
