/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* This module contains support for S-style generic functions */
/* and "class" support.  Gag, barf ... */

#include "Defn.h"

/* processArgs - create a promise to evaluate each argument */  
static SEXP processArgs(SEXP el, SEXP rho)
{
        SEXP h, t;
        if (el == R_NilValue) {
                return R_NilValue;
        }       
        else if (CAR(el) == R_DotsSymbol) {
                h = findVar(CAR(el), rho);
                if (TYPEOF(h) != DOTSXP) {
                        if (h == R_MissingArg || h == R_NilValue)
                                return processArgs(CDR(el), rho);
                        error("... used in an incorrect context\n");
                }
                PROTECT(h = processArgs(h, rho));
                PROTECT(t = processArgs(CDR(el), rho));
                t = listAppend(h, t);
                UNPROTECT(2);
                return t;
        }
	else if(isSymbol(CAR(el))) {
                h = findVar(CAR(el), rho);
		if(TYPEOF(h) != PROMSXP)
			h = mkPROMISE(CAR(el), rho);
		PROTECT(h);
                PROTECT(t = processArgs(CDR(el), rho));
                t = CONS(h, t);
                TAG(t) = TAG(el);
                UNPROTECT(2);
                return t;
	}
        else {
                PROTECT(h = mkPROMISE(CAR(el), rho));
                PROTECT(t = processArgs(CDR(el), rho));
                t = CONS(h, t);
                TAG(t) = TAG(el);
                UNPROTECT(2);
                return t;
        }
}


static SEXP applyMethod(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP ans;
	if (TYPEOF(op) == SPECIALSXP) {
		int save = R_PPStackTop;
		R_Visible = 1 - PRIMPRINT(op);
		ans = PRIMFUN(op) (call, op, args, rho);
		if(save != R_PPStackTop) {
			Rprintf("stack imbalance in %s, %d then %d\n",
				PRIMNAME(op), save, R_PPStackTop);
		}
	} 
	else if (TYPEOF(op) == BUILTINSXP) {
		int save = R_PPStackTop;
		PROTECT(args = evalList(args, rho));
		R_Visible = 1 - PRIMPRINT(op);
		ans = PRIMFUN(op) (call, op, args, rho);
		UNPROTECT(1);
		if(save != R_PPStackTop) {
			Rprintf("stack imbalance in %s, %d then %d\n",
				PRIMNAME(op), save, R_PPStackTop);
		}
	}
	else if (TYPEOF(op) == CLOSXP) {
		PROTECT(args = processArgs(args, rho));
		ans = applyClosure(call, op, args, rho); 
		UNPROTECT(1);
	}
	return ans;
}

int usemethod(char *generic, SEXP call, SEXP args, SEXP rho, SEXP *ans)
{
	SEXP class, method, obj, sxp;
	char buf[128];
	int i, nclass;

	obj = eval(CAR(args), rho);
	if(isObject(obj)) {
		class = getAttrib(obj, R_ClassSymbol);
		nclass = LENGTH(class);
		for(i=0 ; i<nclass ; i++) {
			sprintf(buf, "%s.%s",
				generic,
				CHAR(STRING(class)[i]));
			method = install(buf);
			sxp = findVar(method, rho);
			if(isFunction(sxp)) {
				*ans = applyMethod(call, sxp, args, rho);
				return 1;
			}
		}
	}
	sprintf(buf, "%s.default", generic);
	method = install(buf);
	sxp = findVar(method, rho);
	if(isFunction(sxp)) {
		*ans = applyMethod(call, sxp, args, rho);
		return 1;
	}
	return 0;
}

SEXP do_usemethod(SEXP call, SEXP op, SEXP args, SEXP env)
{
	char buf[128];
	SEXP ans;

	int nargs = length(args);
	if(nargs < 2)
		errorcall(call, "too few arguments to UseMethod\n");

	if(TYPEOF(CAR(args)) != STRSXP || LENGTH(CAR(args)) < 1)
		errorcall(call, "first argument must be a method name\n");
	strcpy(buf, CHAR(STRING(CAR(args))[0]));
	if(usemethod(buf, call, CDR(args), env, &ans) == 1)
		return ans;
	else
		error("no applicable method for \"%s\"\n", buf);
}

SEXP do_unclass(SEXP call, SEXP op, SEXP args, SEXP env)
{
	checkArity(op, args);
	if(isObject(CAR(args))) {
		CAR(args) = duplicate(CAR(args));
		setAttrib(CAR(args), R_ClassSymbol, R_NilValue);
	}
	return CAR(args);
}
