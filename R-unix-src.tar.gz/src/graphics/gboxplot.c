/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"


int GBoxplot(double *y, int n, double where, double width, int horiz)
{
	double yy, yla, ylq, ym, yuq, yua;
	double zla, zlq, zm, zuq, zua;
	double x0, x1, xl, xu;
	double d, w;
	int k1, k2, l, lty;
	double ext = 1.5;
	
	rsort(y, n);

		/* compute median and quartiles */

	k1 = n*0.25-0.01; k2 = n*0.25+0.01;
	ylq = 0.5*(y[k1]+y[k2]);

	k1 = n*0.5-0.01; k2 = n*0.5+0.01;
	ym = 0.5*(y[k1]+y[k2]);

	k1 = n*0.75-0.01; k2 = n*0.75+0.01;
	yuq = 0.5*(y[k1]+y[k2]);
		
		/* search for adjacent values */

	d = ext*(yuq-ylq);
	for( l=n-1 ; (y[l]-yuq)>d ; l-- ) ;
	yua = y[l];
	if( yua<yuq ) yua=yuq;
	for( l=0 ; (ylq-y[l])>d ; l++ ) ;
	yla = y[l];
	if( yla>ylq ) yla=ylq;

		/* x related quantities */
		
	w = 0.5*width;

	GMode(1);
	lty = GP->lty;

	if(horiz) {
		xl = YMAP(where-w);
		xu = YMAP(where+w);
		x0 = YMAP(where-0.5*w);
		x1 = YMAP(where+0.5*w);
		where = YMAP(where);

		zla = XMAP(yla);
		zlq = XMAP(ylq);
		zm  = XMAP(ym);
		zuq = XMAP(yuq);
		zua = XMAP(yua);

		GP->lty = 1;		/* box */
		GStartPath();
		GMoveTo(zlq, xl);
		GLineTo(zuq, xl);
		GLineTo(zuq, xu);
		GLineTo(zlq, xu);
		GLineTo(zlq, xl);
		GEndPath();

		GStartPath();
		GMoveTo(zm, xl);
		GLineTo(zm, xu);
		GEndPath();

		GP->lty = 2;		/* whiskers */
		GStartPath();
		GMoveTo(zlq, where);
		GLineTo(zla, where);
		GEndPath();

		GStartPath();
		GMoveTo(zuq, where);
		GLineTo(zua, where);
		GEndPath();

		GP->lty = 1;
		GStartPath();
		GMoveTo(zla, x0);
		GLineTo(zla, x1);
		GEndPath();

		GStartPath();
		GMoveTo(zua, x0);
		GLineTo(zua, x1);
		GEndPath();

		l = 0;			/* outliers */
		while( (yy=y[l++])<yla ) {
			GMoveTo(XMAP(yy), where);
			GText("o", 0.33, 0.33);
		}
		l = n-1;
		while( (yy=y[l--])>yua ) {
			GMoveTo(XMAP(yy), where);
			GText("o", 0.33, 0.33);
		}
	}
	else {
		xl = XMAP(where-w);
		xu = XMAP(where+w);
		x0 = XMAP(where-0.5*w);
		x1 = XMAP(where+0.5*w);
		where = XMAP(where);

		zla = YMAP(yla);
		zlq = YMAP(ylq);
		zm  = YMAP(ym);
		zuq = YMAP(yuq);
		zua = YMAP(yua);

		GP->lty = 1;		/* box */
		GStartPath();
		GMoveTo(xl,zlq);
		GLineTo(xl,zuq);
		GLineTo(xu,zuq);
		GLineTo(xu,zlq);
		GLineTo(xl,zlq);
		GEndPath();

		GStartPath();
		GMoveTo(xl,zm);
		GLineTo(xu,zm);
		GEndPath();

		GP->lty = 2;		/* whiskers */
		GStartPath();
		GMoveTo(where,zlq);
		GLineTo(where,zla);
		GMoveTo(where,zuq);
		GLineTo(where,zua);
		GEndPath();

		GP->lty = 1;
		GStartPath();
		GMoveTo(x0,zla);
		GLineTo(x1,zla);
		GMoveTo(x0,zua);
		GLineTo(x1,zua);
		GEndPath();

		l = 0;			/* outliers */
		while( (yy=y[l++])<yla ) {
			GMoveTo(where, YMAP(yy));
#ifdef THINK_C
			GText("o", 0.5, 0.25);
#else
			GText("o", 0.5, 0.5);
#endif
		}
		l = n-1;
		while( (yy=y[l--])>yua ) {
			GMoveTo(where, YMAP(yy));
#ifdef THINK_C
			GText("o", 0.5, 0.25);
#else
			GText("o", 0.5, 0.5);
#endif
		}
	}
	GP->lty = lty;
	GMode(0);
}
