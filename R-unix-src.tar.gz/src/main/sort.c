/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

static int icmp(RINT x, RINT y)
{
	if (x == NA_INTEGER)
		return 1;
	if (y == NA_INTEGER)
		return -1;
	if (x < y)
		return -1;
	if (x > y)
		return 1;
	return 0;
}

static int rcmp(double x, double y)
{
	if (x == NA_REAL)
		return 1;
	if (y == NA_REAL)
		return -1;
	if (x < y)
		return -1;
	if (x > y)
		return 1;
	return 0;
}

static int scmp(SEXP x, SEXP y)
{
	return strcmp(CHAR(x), CHAR(y));
}

isort(RINT * x, RINT n)
{
	RINT i, j, h;
	RINT xtmp;

	h = 1;
	do {
		h = 3 * h + 1;
	}
	while (h <= n);

	do {
		h = h / 3;
		for (i = h; i < n; i++) {
			xtmp = x[i];
			j = i;
			while (icmp(x[j - h], xtmp) > 0) {
				x[j] = x[j - h];
				j = j - h;
				if (j < h)
					goto end;
			}
		      end:x[j] = xtmp;
		}
	} while (h != 1);
}

rsort(double *x, RINT n)
{
	RINT i, j, h;
	double xtmp;

	h = 1;
	do {
		h = 3 * h + 1;
	}
	while (h <= n);

	do {
		h = h / 3;
		for (i = h; i < n; i++) {
			xtmp = x[i];
			j = i;
			while (rcmp(x[j - h], xtmp) > 0) {
				x[j] = x[j - h];
				j = j - h;
				if (j < h)
					goto end;
			}
		      end:x[j] = xtmp;
		}
	} while (h != 1);
}

static ssort(SEXP * x, RINT n)
{
	RINT i, j, h;
	SEXP xtmp;

	h = 1;
	do {
		h = 3 * h + 1;
	}
	while (h <= n);

	do {
		h = h / 3;
		for (i = h; i < n; i++) {
			xtmp = x[i];
			j = i;
			while (scmp(x[j - h], xtmp) > 0) {
				x[j] = x[j - h];
				j = j - h;
				if (j < h)
					goto end;
			}
		      end:x[j] = xtmp;
		}
	} while (h != 1);
}

void sortVector(SEXP s)
{
	int n;

	if (!isVector(s))
		error("only vectors can be sorted\n");

	n = LENGTH(s);
	if (n >= 2)
		switch (TYPEOF(s)) {
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			isort(INTEGER(s), n);
			break;
		case REALSXP:
			rsort(REAL(s), n);
			break;
		case STRSXP:
			ssort(STRING(s), n);
			break;
		}
}

SEXP do_sort(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP ans;

	checkArity(op, args);

	if (!isVector(CAR(args)))
		error("only vectors can be sorted\n");

	ans = duplicate(CAR(args));
	sortVector(ans);
	return ans;
}

static void iFind(RINT * x, RINT n, RINT k)
{
	RINT L, R, i, j;
	RINT v, w;

	L = 0;
	R = n - 1;
	while (L < R) {
		v = x[k];
		i = L;
		j = R;
		do {
			while (icmp(x[i], v) < 0)
				i++;
			while (icmp(v, x[j]) < 0)
				j--;
			if (i <= j) {
				w = x[i];
				x[i] = x[j];
				x[j] = w;
				i++;
				j--;
			}
		} while (i <= j);
		if (j < k)
			L = i;
		if (k < i)
			R = j;
	}
}

void rFind(RFLOAT * x, RINT n, RINT k)
{
	int L, R, i, j;
	RFLOAT v, w;

	L = 0;
	R = n - 1;
	while (L < R) {
		v = x[k];
		i = L;
		j = R;
		do {
			while (rcmp(x[i], v) < 0)
				i++;
			while (rcmp(v, x[j]) < 0)
				j--;
			if (i <= j) {
				w = x[i];
				x[i] = x[j];
				x[j] = w;
				i++;
				j--;
			}
		} while (i <= j);
		if (j < k)
			L = i;
		if (k < i)
			R = j;
	}
}

void sFind(SEXP * x, RINT n, RINT k)
{
	int L, R, i, j;
	SEXP v, w;

	L = 0;
	R = n - 1;
	while (L < R) {
		v = x[k];
		i = L;
		j = R;
		do {
			while (scmp(x[i], v) < 0)
				i++;
			while (scmp(v, x[j]) < 0)
				j--;
			if (i <= j) {
				w = x[i];
				x[i] = x[j];
				x[j] = w;
				i++;
				j--;
			}
		} while (i <= j);
		if (j < k)
			L = i;
		if (k < i)
			R = j;
	}
}

void find(SEXP x, RINT k)
{
	switch (TYPEOF(x)) {
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
		iFind(INTEGER(x), LENGTH(x), k);
		break;
	case REALSXP:
		rFind(REAL(x), LENGTH(x), k);
		break;
	case STRSXP:
		sFind(STRING(x), LENGTH(x), k);
		break;
	}
}

/* FUNCTION psort(x, indices) */
SEXP do_psort(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP ans;
	RINT i, j, k, n;
	RINT *l;

	checkArity(op, args);

	if (!isVector(CAR(args)))
		error("only vectors can be sorted\n");
	CADR(args) = coerceVector(CADR(args), INTSXP);
	n = LENGTH(CAR(args));
	k = LENGTH(CADR(args));
	l = INTEGER(CADR(args));
	for (i = 0; i < k; i++) {
		if (l[i] == NA_INTEGER)
			error("NA index in find\n");
		if (l[i] < 1 || l[i] > n)
			error("index %d outside bounds in find\n", l[i]);
	}
	CAR(args) = duplicate(CAR(args));
	l = INTEGER(CADR(args));
	for (i = 0; i < k; i++)
		find(CAR(args), l[i] - 1);
	return CAR(args);
}

static int equal(RINT i, RINT j, SEXP x)
{
	RINT c;

	switch (TYPEOF(x)) {
	case LGLSXP:
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
		c = icmp(INTEGER(x)[i], INTEGER(x)[j]);
		break;
	case REALSXP:
		c = rcmp(REAL(x)[i], REAL(x)[j]);
		break;
	case STRSXP:
		c = scmp(STRING(x)[i], STRING(x)[j]);
		break;
	}
	if (c == 0)
		return 1;
	return 0;
}

static int greater(RINT i, RINT j, SEXP x)
{
	RINT c;

	switch (TYPEOF(x)) {
	case LGLSXP:
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
		c = icmp(INTEGER(x)[i], INTEGER(x)[j]);
		break;
	case REALSXP:
		c = rcmp(REAL(x)[i], REAL(x)[j]);
		break;
	case STRSXP:
		c = scmp(STRING(x)[i], STRING(x)[j]);
		break;
	}
	if (c > 0)
		return 1;
	return 0;
}

static int listgreater(RINT i, RINT j, SEXP key)
{
	SEXP x;
	RINT c;

	while (key != nilValue) {
		x = CAR(key);
		switch (TYPEOF(x)) {
		case LGLSXP:
		case INTSXP:
		case FACTSXP:
		case ORDSXP:
			c = icmp(INTEGER(x)[i], INTEGER(x)[j]);
			break;
		case REALSXP:
			c = rcmp(REAL(x)[i], REAL(x)[j]);
			break;
		case STRSXP:
			c = scmp(STRING(x)[i], STRING(x)[j]);
			break;
		}
		if (c > 0)
			return 1;
		if (c < 0)
			return 0;
		key = CDR(key);
	}
	if (c==0 && i<j)
		return 0;
	return 1;
}

void orderVector(RINT * index, RINT n, SEXP key, int greater())
{
	RINT i, j, h;
	RINT itmp;

	h = 1;
	do {
		h = 3 * h + 1;
	} while (h <= n);

	do {
		h = h / 3;
		for (i = h; i < n; i++) {
			itmp = index[i];
			j = i;
			while (greater(index[j - h], itmp, key)) {
				index[j] = index[j - h];
				j = j - h;
				if (j < h)
					goto next_h;
			}
		      next_h:index[j] = itmp;
		}
	}
	while (h != 1);
}

/* FUNCTION order(...) */
SEXP do_order(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP ap, ans;
	int i, n, narg = 0;

	if (args == nilValue)
		return nilValue;

	if (isVector(CAR(args)))
		n = LENGTH(CAR(args));
	for (ap = args; ap != nilValue; ap = CDR(ap)) {
		if (!isVector(CAR(ap)))
			errorcall(call, "Argument %d is not a vector\n", ++narg);
		if (LENGTH(CAR(ap)) != n)
			errorcall(call, "Argument lengths differ\n");
	}
	ans = allocVector(INTSXP, n);
	if (n != 0) {
		for (i = 0; i < n; i++)
			INTEGER(ans)[i] = i;
		orderVector(INTEGER(ans), n, args, listgreater);
		for (i = 0; i < n; i++)
			INTEGER(ans)[i] += 1;
	}
	return ans;
}

/* FUNCTION: rank(x) */
SEXP do_rank(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP rank, index, x;
	RINT *in;
	RFLOAT *rk;
	RINT i, j, k, n;

	checkArity(op, args);
	if (args == nilValue)
		return nilValue;
	x = CAR(args);
	if (!isVector(x))
		errorcall(call, "Argument is not a vector\n");
	n = LENGTH(x);
	PROTECT(index = allocVector(INTSXP, n));
	PROTECT(rank = allocVector(REALSXP, n));
	UNPROTECT(2);
	if (n > 0) {
		in = INTEGER(index);
		rk = REAL(rank);
		for (i = 0; i < n; i++)
			in[i] = i;
		orderVector(in, n, x, greater);
		i = 0;
		while (i < n) {
			j = i;
			while ((j < n - 1) && equal(in[j], in[j + 1], x))
				j++;
			if (i != j) {
				for (k = i; k <= j; k++)
					rk[in[k]] = (i + j + 2) / 2.0;
			}
			else
				rk[in[i]] = i + 1;
			i = j + 1;
		}
	}
	return rank;
}
