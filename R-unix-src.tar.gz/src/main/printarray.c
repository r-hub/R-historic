/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Print.h"

static void printLogicalMatrix(RINT * x, RINT r, RINT c, SEXP * rl, SEXP * cl, RINT * cseps)
{
	RINT i, j, jj, j1, j2, nc, nb;
	RINT width, rlabw, clabw;
	RINT w;
	char buf[32];

	if (cl) formatString(cl, c, &clabw, 0);
	else clabw = IndexWidth(c + 1) + 3;

	if (rl) formatString(rl, r, &rlabw, 0);
	else rlabw = IndexWidth(r + 1) + 3;

	width = clabw;
	w = 1;
	if (w > width)
		width = w;

	nc = (PRINT_WIDTH - rlabw) / (width + PRINT_GAP);
	nb = c / nc + 1;

	for (jj = 0; jj < nb; jj++) {
		j1 = jj * nc;
		if (j1 >= c)
			break;
		j2 = j1 + nc;
		if (j2 > c)
			j2 = c;
		Rprintf("%*s", rlabw, "");
		for (j = j1; j < j2; j++)
			MatrixColumnLabel(cl, j, width);
		for (i = 0; i < r; i++) {
			MatrixRowLabel(rl, i, rlabw);
			for (j = j1; j < j2; j++) {
				Rprintf("%*s%s", PRINT_GAP, "", 
					EncodeLogical(x[i+j*r], width));
			}
		}
		Rprintf("\n");
	}
}

static void printFactorMatrix(RINT * x, RINT r, RINT c, SEXP * rl, SEXP * cl, SEXP * levels, RINT nlev, RINT * cseps)
{
	RINT i, j, jj, j1, j2, k, nc, nb;
	RINT width, rlabw, clabw;
	RINT w;
	char buf[32];

	if (cl) formatString(cl, c, &clabw, 0);
	else clabw = IndexWidth(c + 1) + 3;

	if (rl) formatString(rl, r, &rlabw, 0);
	else rlabw = IndexWidth(r + 1) + 3;

	width = clabw;
	formatString(levels, nlev, &w, 0);
	for (i = 0; i < r * c; i++) {
		if (x[i] < 1 || x[i] > nlev) {
			if (w < 2) w = 2;
		}
	}
	if (w > width)
		width = w;

	nc = (PRINT_WIDTH - rlabw) / (width + PRINT_GAP);
	nb = c / nc + 1;

	for (jj = 0; jj < nb; jj++) {
		j1 = jj * nc;
		if (j1 >= c)
			break;
		j2 = j1 + nc;
		if (j2 > c)
			j2 = c;
		Rprintf("%*s",rlabw,"");
		for (j = j1; j < j2; j++)
			MatrixColumnLabel(cl, j, width);
		for (i = 0; i < r; i++) {
			MatrixRowLabel(rl, i, rlabw);
			for (j = j1; j < j2; j++) {
				Rprintf("%*s", PRINT_GAP, "");
				k = x[i+j*r];
				if (1 <= k && k <= nlev)
					Rprintf("%s", EncodeString(CHAR(levels[k - 1]), width, 0));
				else
					Rprintf("%s", EncodeString(CHAR(NA_STRING), w, 0));
			}
		}
		Rprintf("\n");
	}
}
static void printIntegerMatrix(RINT * x, RINT r, RINT c, SEXP * rl, SEXP * cl, RINT * cseps)
{
	RINT w;
	RINT width, rlabw, clabw;
	RINT i, j, jj, j1, j2, nc, nb;

	if (rl) formatString(rl, r, &rlabw, 0);
	else rlabw = IndexWidth(r + 1) + 3;

	for (i = 0; i < c; i++) {
		if (cl) {
			if (CHAR(cl[i]) == NULL)
				cseps[i] = 2;
			else
				cseps[i] = Rstrlen(CHAR(cl[i]));
		}
		else
			cseps[i] = IndexWidth(c + 1) + 3;
		formatInteger(x + i * r, r, &w);
		if (w > cseps[i])
			cseps[i] = w;
	}

	j2 = 0;
	while (j2 < c) {
		nc = PRINT_WIDTH - rlabw;
		Rprintf("%*s", rlabw, "");
		j1 = j2;
		do {
			if ((nc -= (cseps[j2] + PRINT_GAP)) < 0)
				break;
			MatrixColumnLabel(cl, j2, cseps[j2]);
			j2++;
		}
		while (j2 < c);
		if (j1 == j2)
			error("PRINT_WIDTH is too narrow\n");
		for (i = 0; i < r; i++) {
			MatrixRowLabel(rl, i, rlabw);
			for (j = j1; j < j2; j++) {
				Rprintf("%*s%s", PRINT_GAP, "",
					EncodeInteger(x[i+j*r], cseps[j]));
			}
		}
		Rprintf("\n");
	}
}

static void printRealMatrix(RFLOAT * x, RINT r, RINT c, SEXP * rl, SEXP * cl, RINT * cseps)
{
	SEXP sd, se;
	RINT *d, *e;
	RINT w, width, rlabw, clabw;
	RINT i, j, jj, j1, j2, nc, nb;

	if (cl) formatString(cl, c, &clabw, 0);
	else clabw = IndexWidth(c + 1) + 3;

	if (rl) formatString(rl, r, &rlabw, 0);
	else rlabw = IndexWidth(r + 1) + 3;

	PROTECT(sd = allocVector(INTSXP, c));
	se = allocVector(INTSXP, c);
	UNPROTECT(1);
	d = INTEGER(sd);
	e = INTEGER(se);

	width = clabw;
	for (j = 0; j < c; j++) {
		formatReal(&x[j * r], r, &w, &d[j], &e[j]);
		if (w > width)
			width = w;
	}

	nc = (PRINT_WIDTH - rlabw) / (width + PRINT_GAP);
	nb = c / nc + 1;

	for (jj = 0; jj < nb; jj++) {
		j1 = jj * nc;
		if (j1 >= c)
			break;
		j2 = j1 + nc;
		if (j2 > c)
			j2 = c;
		Rprintf("%*s", rlabw, " ");
		for (j = j1; j < j2; j++)
			MatrixColumnLabel(cl, j, width);
		for (i = 0; i < r; i++) {
			MatrixRowLabel(rl, i, rlabw);
			for (j = j1; j < j2; j++) {
				Rprintf("%*s%s", PRINT_GAP, "",
					EncodeReal(x[i+j*r], width, d[j], e[j]));
			}
		}
		Rprintf("\n");
	}
}

static void printStringMatrix(SEXP * x, RINT r, RINT c, int quote, SEXP * rl, SEXP * cl, RINT * cseps)
{
	RINT w;
	RINT width, rlabw, clabw;
	RINT i, j, jj, j1, j2, nc, nb;

	if (cl) formatString(cl, c, &clabw, 0);
	else clabw = IndexWidth(c + 1) + 3;

	if (rl) formatString(rl, r, &rlabw, 0);
	else rlabw = IndexWidth(r + 1) + 3;

	width = clabw;
	formatString(x, r * c, &w, quote);
	if (w > width)
		width = w;

	nc = (PRINT_WIDTH - rlabw) / (width + PRINT_GAP);
	nb = c / nc + 1;

	for (jj = 0; jj < nb; jj++) {
		j1 = jj * nc;
		if (j1 >= c)
			break;
		j2 = j1 + nc;
		if (j2 > c)
			j2 = c;
		Rprintf("%*s", rlabw, " ");
		for (j = j1; j < j2; j++)
			MatrixColumnLabel(cl, j, width);
		for (i = 0; i < r; i++) {
			MatrixRowLabel(rl, i, rlabw);
			for (j = j1; j < j2; j++) {
				Rprintf("%*s%s", PRINT_GAP, " ",
					EncodeString(CHAR(x[i+j*r]), width, quote));
			}
		}
		Rprintf("\n");
	}
}

void printMatrix(SEXP x, SEXP dim, SEXP * rl, SEXP * cl, int quote)
{
	SEXP l, dimnames;
	RINT *cseps;
	char *vmax;

	PROTECT(dimnames = getAttrib(x, DimNamesSymbol));
	if (dimnames != nilValue) {
		if (CAR(dimnames) != nilValue)
			rl = STRING(CAR(dimnames));
		else
			rl = NULL;
		if (CADR(dimnames) != nilValue)
			cl = STRING(CADR(dimnames));
		else
			cl = NULL;
	}
	/* need to alloc an integer array for printseps */
	vmax = vmaxget();
	cseps = (RINT *) R_alloc(INTEGER(dim)[1], sizeof(RINT));

	switch (TYPEOF(x)) {
	case LGLSXP:
		printLogicalMatrix(LOGICAL(x), INTEGER(dim)[0], INTEGER(dim)[1], rl, cl, cseps);
		break;
	case FACTSXP:
	case ORDSXP:
		if ((l = getAttrib(x, install("levels"))) != nilValue
		    && TYPEOF(l) == STRSXP
		    && LENGTH(l) == LEVELS(x)) {
			printFactorMatrix(FACTOR(x), INTEGER(dim)[0], INTEGER(dim)[1], rl, cl, STRING(l), LEVELS(x), cseps);
		}
		else
			printIntegerMatrix(INTEGER(x), INTEGER(dim)[0], INTEGER(dim)[1], rl, cl, cseps);
		break;
	case INTSXP:
		printIntegerMatrix(INTEGER(x), INTEGER(dim)[0], INTEGER(dim)[1], rl, cl, cseps);
		break;
	case REALSXP:
		printRealMatrix(REAL(x), INTEGER(dim)[0], INTEGER(dim)[1], rl, cl, cseps);
		break;
	case STRSXP:
		if (quote)
			printStringMatrix(STRING(x), INTEGER(dim)[0], INTEGER(dim)[1], '"', rl, cl, cseps);
		else
			printStringMatrix(STRING(x), INTEGER(dim)[0], INTEGER(dim)[1], 0, rl, cl, cseps);
		break;
	}
	UNPROTECT(1);
	vmaxset(vmax);
}

static void printArrayGeneral(SEXP x, SEXP dim, SEXP * rl, SEXP * cl, int quote)
{
	RINT i, b, nb, ndim, mode;
	RINT nr, nc, *cseps;

	PROTECT(dim);

	ndim = LENGTH(dim);
	if (ndim == 1)
		printVector(x, 1, quote);
	else if (ndim == 2)
		printMatrix(x, dim, rl, cl, quote);
	else {
		nr = INTEGER(dim)[0];
		nc = INTEGER(dim)[1];
		b = nr * nc;
		mode = TYPEOF(x);
		nb = 1;
		for (i = 2; i < ndim; i++)
			nb *= INTEGER(dim)[i];
		for (i = 0; i < nb; i++) {
			switch (mode) {
			case LGLSXP:
				printLogicalMatrix(&LOGICAL(x)[i * b], nr, nc, rl, cl, cseps);
				break;
			case FACTSXP:
			case ORDSXP:
			case INTSXP:
				printIntegerMatrix(&INTEGER(x)[i * b], nr, nc, rl, cl, cseps);
				break;
			case REALSXP:
				printRealMatrix(&REAL(x)[i * b], nr, nc, rl, cl, cseps);
				break;
			case STRSXP:
				if (quote)
					printStringMatrix(&STRING(x)[i * b], nr, nc, '"', rl, cl, cseps);
				else
					printStringMatrix(&STRING(x)[i * b], nr, nc, 0, rl, cl, cseps);
				break;
			}
			Rprintf("\n");
		}
	}
	UNPROTECT(1);
}

void printArray(SEXP x, int quote)
{
	printArrayGeneral(x, getAttrib(x, DimSymbol), NULL, NULL, quote);
}

void printDataFrame(SEXP x)
{
	SEXP s, t, rl, cl, sd, se, cs;
	RINT w, *d, *e, r, c, k, *cseps;
	RINT width, rlabw, clabw;
	RINT i, j, j1, j2, nc;

	PROTECT(rl = getAttrib(x, install("row.names")));
	PROTECT(cl = getAttrib(x, NamesSymbol));
	r = LENGTH(CAR(x));
	c = length(x);

	PROTECT(cs = allocVector(INTSXP, c));
	PROTECT(sd = allocVector(INTSXP, c));
	se = allocVector(INTSXP, c);
	UNPROTECT(4);
	d = INTEGER(sd);
	e = INTEGER(se);
	cseps = INTEGER(cs);
/**** no allocing from here to the end ********/

	if (rl != nilValue)
		formatString(STRING(rl), r, &rlabw, 0);
	else
		rlabw = IndexWidth(r + 1) + 3;

	for (i = 0, s = x; i < c; i++, s = CDR(s)) {
		if (cl != nilValue) {
			if (CHAR(STRING(cl)[i]) == NULL)
				cseps[i] = 2;
			else
				cseps[i] = Rstrlen(CHAR(STRING(cl)[i]));
		}
		else
			cseps[i] = IndexWidth(c + 1) + 3;
		switch (TYPEOF(CAR(s))) {
		case INTSXP:
			formatInteger(INTEGER(CAR(s)), r, &w);
			break;
		case REALSXP:
			formatReal(REAL(CAR(s)), r, &w, &d[i], &e[i]);
			break;
		case FACTSXP:
		case ORDSXP:
			for (t = ATTRIB(CAR(s)); t != nilValue; t = CDR(t))
				if (streql(CHAR(PRINTNAME(TAG(t))), "levels"))
					break;
			if (TYPEOF(CAR(t)) != STRSXP || length(CAR(t)) != LEVELS(CAR(s)))
				error("print data frame: wrong type\n");
			formatString(STRING(CAR(t)), LEVELS(CAR(s)), &w, 0);
			for (i = 0; i < r; i++)
				k = INTEGER(CAR(s))[i];
			if (k < 1 || k > LEVELS(CAR(s))) {
				if (w < 2)
					w = 2;
				break;
			}
			break;
		default:
			error("data.frame has an element of the wrong type\n");
		}
		if (w > cseps[i])
			cseps[i] = w;
	}

	j2 = 0;
	while (j2 < c) {
		nc = PRINT_WIDTH - rlabw;
		Rprintf("%*s", rlabw, " ");
		j1 = j2;
		do {
			if ((nc -= (cseps[j2] + PRINT_GAP)) < 0)
				break;
			MatrixColumnLabel(STRING(cl), j2, cseps[j2]);
			j2++;
		}
		while (j2 < c);
		if (j1 == j2)
			error("PRINT_WIDTH is too narrow\n");
		for (i = 0; i < r; i++) {
			MatrixRowLabel(STRING(rl), i, rlabw);
			s = nthcdr(x, j1);
			for (j = j1; j < j2; j++, s = CDR(s)) {
				Rprintf("%*s", PRINT_GAP, " ");
				switch (TYPEOF(CAR(s))) {
				case INTSXP:
					Rprintf("%s", EncodeInteger(INTEGER(CAR(s))[i], cseps[j]));
					break;
				case REALSXP:
					Rprintf("%s", EncodeReal(REAL(CAR(s))[i], cseps[j], d[j], e[j]));
					break;
				case FACTSXP:
				case ORDSXP:
					for (t = ATTRIB(CAR(s)); t != nilValue; t = CDR(t))
						if (streql(CHAR(PRINTNAME(TAG(t))), "levels"))
							break;
					if (TYPEOF(CAR(t)) != STRSXP || length(CAR(t)) != LEVELS(CAR(s)))
						error("printdataframe: wrong type for levels\n");
					k = INTEGER(CAR(s))[i];
					if (1 <= k && k <= LEVELS(CAR(s)))
						Rprintf("%s", EncodeString(CHAR(STRING(CAR(t))[k - 1]), cseps[j], 0));
					else
						Rprintf("%s", EncodeString(CHAR(NA_STRING), cseps[j], 0));
					break;
				default:
					error("printdataframe: wrong data type\n");
				}
			}
		}
		Rprintf("\n");
	}
}
