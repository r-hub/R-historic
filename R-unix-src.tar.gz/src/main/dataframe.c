/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

extern SEXP matrixSubset(SEXP, SEXP);

/* functions for data.frames and related tasks */

/* check to see if the SEXP should be expanded or not */
/* for now we'll always expand */
static int expand(SEXP s)
{
	if (isList(s) || isMatrix(s))
		return 1;
	else
		return 0;
}
static SEXP makeNames(RINT len)
{
	SEXP rval;
	int i;
	char buf[20];

	if (len > 0) {
		PROTECT(rval = allocVector(STRSXP, len));
		for (i = 0; i < len; i++) {
			sprintf(buf, "%ld", (RINT) (i + 1));
			STRING(rval)[i] = mkChar(buf);
		}
		UNPROTECT(1);
	}
	return rval;
}

static SEXP getNames(SEXP args)
{
	SEXP s, t, u, names;
	int len = -1, i;

	names = nilValue;

	for (s = args; s != nilValue; s = CDR(s)) {
		if (isVector(CAR(s))) {
			if (isMatrix(CAR(s))) {
				if (len < 0)
					len = nrows(CAR(s));
				if (nrows(CAR(s)) != len)
					error("data frame not all arguments are the same length\n");
				t = getAttrib(CAR(s), DimNamesSymbol);
				if (!isNull(t) && !isNull(CAR(t)))
					if (names == nilValue)
						PROTECT(names = CAR(t));
			}
			else {
				if (len < 0)
					len = length(CAR(s));
				if (length(CAR(s)) != len)
					error("data frame not all arguments are the same length\n");
				t = getAttrib(CAR(s), NamesSymbol);
				if (!isNull(t))
					if (names == nilValue)
						PROTECT(names = t);
			}
		}
		if (isList(CAR(s)))
			if (expand(CAR(s)))
				for (t = CAR(s); t != nilValue; t = CDR(t)) {
					if (len < 0)
						len = length(CAR(t));
					if (length(CAR(t)) != len)
						error("data frame not all arguments are the same length\n");
					u = getAttrib(CAR(t), NamesSymbol);
					if (!isNull(u))
						if (names == nilValue)
							PROTECT(names = u);
				}
			else {
				if (len < 0)
					len = length(CAR(s));
				if (length(CAR(s)) != len)
					error("data frame not all argumements are the same length\n");
				u = getAttrib(CAR(s), NamesSymbol);
				if (!isNull(u))
					if (names == nilValue)
						PROTECT(names = u);
			}
	}
	if (names == nilValue)
		PROTECT(names = makeNames(len));
	UNPROTECT(1);
	return names;
}

/* 
   expand the elements of the data frame into a list. call is used
   to put the "correct" name in the tag slot for each element of the
   list
 */
SEXP expandFrame(SEXP elist, SEXP call)
{
	SEXP s, t, w, t1, dims, rlist, dcall;
	RINT i, j, len, nr, nc;
	char buff[120], buf[140];

	for (s = call; s != nilValue; s = CDR(s))
		CAR(s) = deparse1(CAR(s), 0);
	len = 0;
	for (s = elist; s != nilValue; s = CDR(s)) {
		if (expand(CAR(s))) {
			if (isMatrix(CAR(s))) {
				len += ncols(CAR(s));
			}
			else
				len += length(CAR(s));
		}
		else
			len++;
	}
	PROTECT(t = allocList(len));
	TYPEOF(t) = FRAMESXP;
	w = t;
	dcall = call;
	for (s = elist; s != nilValue; s = CDR(s), dcall = CDR(dcall)) {
		if (strlen(CHAR(STRING(CAR(dcall))[0])) < 120)
			strcpy(buff, CHAR(STRING(CAR(dcall))[0]));
		else
			error("data.frame variable name is too long\n");
		if (expand(CAR(s))) {
			if (isMatrix(CAR(s))) {
				/* so we have to subset it */
				dims = getAttrib(CAR(s), DimSymbol);
				nr = INTEGER(dims)[0];
				nc = INTEGER(dims)[1];
				PROTECT(t1 = allocList(2));
				CADR(t1) = allocVector(INTSXP, 1);
				CAR(t1) = allocVector(INTSXP, nr);
				for (i = 1; i <= nr; i++)
					INTEGER(CAR(t1))[i - 1] = i;
				for (i = 1; i <= nc; i++) {
					INTEGER(CADR(t1))[0] = i;
					CAR(w) = matrixSubset(CAR(s), t1);
					setAttrib(CAR(w), DimSymbol, nilValue);
					sprintf(buf, "%s.%ld", buff, (RINT) (i));
					TAG(w) = install(buf);
					w = CDR(w);
				}
				UNPROTECT(1);
			}
			else {
				for (i = 1, t1 = CAR(s); t1 != nilValue; i++, t1 = CDR(t1)) {
					if (NAMED(CAR(s)))
						CAR(w) = duplicate(CAR(t1));
					else
						CAR(w) = CAR(t1);
					if (TAG(t1) != nilValue)
						TAG(w) = TAG(t1);
					else {
						sprintf(buf, "%s.%ld", buff, (RINT) (i));
						TAG(w) = install(buf);
					}
					w = CDR(w);
				}
			}
		}
		else {
			if (NAMED(CAR(s)))
				CAR(w) = duplicate(CAR(s));
			else
				CAR(w) = CAR(s);
			TAG(w) = install(buff);
			w = CDR(w);
		}
	}
	UNPROTECT(1);
	return t;
}

extern SEXP duplicated(SEXP);
extern SEXP substitute(SEXP, SEXP);

SEXP do_dataframe(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, x, names, rlist;
	RINT i, len, k, l;

	s = substitute(CADR(CADR(call)), env);
	PROTECT(rlist = expandFrame(CAR(args), s));
	names = CADR(args);
	if (names == nilValue)
		PROTECT(names = getNames(CAR(args)));
	else if (isString(names))	/*get the correct argument */
		PROTECT(names = CAR(rlist));
	else if (isVector(names)) {
		i = asInteger(names);
		if (0 >= i || i > length(rlist))
			error("data.frame row.names must specify one of the variables\n");
		if (i == 1) {
			PROTECT(names = CAR(rlist));
			rlist = CDR(rlist);
		}
		else {
			s = nthcdr(rlist, i - 2);
			PROTECT(names = CAR(CDR(s)));
			CDR(s) = CDR(CDR(s));
		}
	}
	else
		error("data.frame wrong type for row.names\n");

	/* check to see if any of the names are duplicated */

	if (!isString(names)) {
		UNPROTECT(1);
		names = coerceVector(names, STRSXP);
		PROTECT(names);
	}
	if (NAMED(names))
		names = duplicate(names);
	len = length(names);
	s = duplicated(names);
	k = 0;
	for (i = 0; i < len; i++)
		if (LOGICAL(s)[i] == 0)
			k++;
	if (k != len)
		error("data.frame some names are duplicated\n");

	for (s = rlist; s != nilValue; s = CDR(s))
		if (!isVector(CAR(s)) || length(CAR(s)) != len)
			error("wrong argument to data.frame\n");

	PROTECT(s = install("row.names"));
	setAttrib(rlist, s, names);
	PROTECT(t = allocVector(INTSXP, 2));
        INTEGER(t)[0] = len;
	INTEGER(t)[1] = length(rlist);
	setAttrib(rlist, DimSymbol, t);
	UNPROTECT(4);
	TYPEOF(rlist) = FRAMESXP;
	return (rlist);
}

/* to attach a list we make up an environment and stick the list in as
   the values of this env and intall the tags from the list as the names
 */

SEXP do_attach(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, x;
	RINT pos;

	checkArity(op, args);
	pos = asInteger(CADR(args));
	if (pos == NA_INTEGER)
		error("attach: pos must be an integer\n");
	if ( !isList(CAR(args)) && !isFrame(CAR(args)) )
		error("attach: only works for lists and frames\n");

	for (x = CAR(args); x != nilValue; x = CDR(x))
		if (TAG(x) == nilValue)
			error("attach: all elements of the list must have a name\n");
	PROTECT(s = allocSExp(ENVSXP));
	FRAME(s) = duplicate(CAR(args));
	for (t = globalEnv; ENCLOS(t) != nilValue && pos > 0; t = ENCLOS(t))
		pos--;
	if (ENCLOS(t) == nilValue) {
		ENCLOS(t) = s;
		ENCLOS(s) = nilValue;
	}
	else {
		x = ENCLOS(t);
		ENCLOS(t) = s;
		ENCLOS(s) = x;
	}
	visible = 0;
	UNPROTECT(1);
	return nilValue;
}

SEXP do_detach(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, x;
	RINT pos;

	checkArity(op, args);
	pos = asInteger(CAR(args));

	for (t = globalEnv; ENCLOS(t) != nilValue && pos > 2; t = ENCLOS(t))
		pos--;
	if (pos != 2)
		error("detach: wrong position given\n");
	else {
		s = ENCLOS(t);
		x = ENCLOS(s);
		ENCLOS(t) = x;
	}
	visible = 0;
	return nilValue;
}
