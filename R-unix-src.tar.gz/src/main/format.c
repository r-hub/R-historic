/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "Defn.h"

formatString(SEXP * x, RINT n, RINT * fieldwidth, int quote)
{
	RINT xmax = 0, naflag = 0;
	RINT i, l;

	for (i = 0; i < n; i++) {
		if (CHAR(x[i]) == NULL)
			naflag = 1;
		else {
			l = Rstrlen(CHAR(x[i]));
			if (l > xmax)
				xmax = l;
		}
	}
	*fieldwidth = xmax;
	if (quote)
		*fieldwidth += 2;
	if (naflag && *fieldwidth < 2)
		*fieldwidth = 2;
}

formatLogical(x, n, fieldwidth)
RINT *x;
RINT n, *fieldwidth;
{
	int i;

	*fieldwidth = 1;
	for (i = 0; i < n; i++) {
		if (x[i] == NA_LOGICAL)
			*fieldwidth = 2;
	}
}

formatInteger(x, n, fieldwidth)
RINT *x;
RINT n, *fieldwidth;
{
	RINT xmin = INT_MAX, xmax = INT_MIN, naflag = 0;
	RINT i, l;

	for (i = 0; i < n; i++) {
		if (x[i] == NA_INTEGER)
			naflag = 1;
		else {
			if (x[i] < xmin)
				xmin = x[i];
			if (x[i] > xmax)
				xmax = x[i];
		}
	}

	if (naflag)
		*fieldwidth = 2;
	else
		*fieldwidth = 1;
	if (xmin < 0) {
		l = IndexWidth(-xmin) + 1;	/* +1 for sign */
		if (l > *fieldwidth)
			*fieldwidth = l;
	}
	if (xmax > 0) {
		l = IndexWidth(xmax);
		if (l > *fieldwidth)
			*fieldwidth = l;
	}
}

#define EPS		1.e-07
#define BIAS		0.5
#define ROUND(x)	floor((x)+0.5)

static double tbl[] =
{
	0.e0, 1.e0, 1.e1, 1.e2, 1.e3, 1.e4, 1.e5, 1.e6, 1.e7, 1.e8, 1.e9
};

formatReal(RFLOAT * x, RINT l, RINT * m, RINT * n, RINT * e)
{
	double alpha, rr, r, rlog, tmp1;
	RINT left, right, sleft;
	RINT mnl, mxl, rt, mxs, mxe;
	RINT neg, sgn;
	RINT i, j, kpower, nsig;
	RINT naflag;

	neg = 0;
	mxl = INT_MIN;
	rt = INT_MAX;
	mxs = INT_MIN;
	mnl = INT_MAX;
	mxe = INT_MIN;
	naflag = 0;

	for (i = 0; i < l; i++) {
		rr = x[i];
		if (rr == NA_REAL) {
			naflag = 1;
		}
		else {
			if (rr == 0.0) {
				kpower = 0;
				nsig = 1;
				sgn = 0;
			}
			else {
				/* put in scientific form */

				r = fabs(rr);
				sgn = (rr < 0);

				kpower = floor(log10(r));
				if (abs(kpower) < 10) {
					if (kpower >= 0)
						alpha = r / tbl[kpower + 1];	/* division slow ? */
					else
						alpha = r * tbl[-kpower + 1];
				}
				else
					alpha = r / pow(10.0, (double) kpower);

				/* make sure that alpha is in [1,10) */

				if (alpha - 10.0 > -EPS) {
					alpha = alpha * 10.0;
					kpower = kpower - 1;
				}

				/* compute number of digits */
				nsig = options_digits;
				for (j = 1; j <= nsig; j++) {
					if (fabs(alpha - ROUND(alpha)) / alpha < EPS) {
						nsig = j;
						break;
					}
					alpha *= 10.0;
				}

				/* nsig digits altogether */
				/* kpower+1 digits to the left of . */
				/* kpower+1+sgn including sign */

			}

			left = kpower + 1;
			sleft = sgn + ((left <= 0) ? 1 : left);
			right = left - nsig;
			if (sgn)
				neg = 1;

			if (right < rt)
				rt = right;	/* digits to right of . */
			if (left > mxl)
				mxl = left;	/* max digits to left of . */
			if (left < mnl)
				mnl = left;	/* min digits to left of . */
			if (sleft > mxs)
				mxs = sleft;	/* max left including sign */
			if (nsig >= mxe)
				mxe = nsig;	/* max sig digits */

		}
	}

#define NUMDIG 7
#define MAXDIG 11

	/* F Format is used if all three following conditions hold: */
	/* 1) The maximum exponent is less than 7 */
	/* 2) There are no more than 5 leading zeros after . */
	/* 3) There are at most MAXDIG digits in all */

	/* E Format has the form */
	/* [S]X[.XXX]E+XX[X] */
	/* This is indicated by setting *e to non-zero (usually 1) */
	/* If the additional exponent digit is required *e is set to 2 */

/* printf("mxl = %d  mnl = %d\n",mxl,mnl); */

	if (mxl < 8 && mnl > -5 && mxl - rt <= MAXDIG) {
		*e = 0;
		if (mxl != mnl && mxl - rt > MAXDIG)
			rt = mxl - MAXDIG;
		if (mxl < 0)
			mxs = 1 + neg;
		if (rt > 0)
			rt = 0;
		if (rt < -MAXDIG)
			rt = -MAXDIG;
		*n = -rt;
		*m = mxs - rt + (rt != 0);
	}
	else {
		*e = 1;
		*n = mxe - 1;
		*m = neg + (*n > 0) + *n + 5;
		if (mxl > 100 || mnl < -99) {
			*m += 1;
			*e = 2;
		}
	}
	if (naflag && *m < 2)
		*m = 2;
}
