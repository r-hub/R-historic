/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Print.h"
#include <limits.h>

#define MAX_WIDTH 200
#define MIN_WIDTH 10
#define MAX_EXPRESSIONS 100000

static char EdFiLeName[100];

SEXP parse(FILE *, int);
SEXP printOptions();

SEXP do_pause(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	visible = 0;
	return nilValue;
}

SEXP do_onexit(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RCONTEXT *ctxt;
	SEXP code;

	switch (length(args)) {
	case 0:
		code = nilValue;
		break;
	case 1:
		code = CAR(args);
		break;
	default:
		errorcall(call, "invalid number of arguments\n");
	}
	ctxt = globalcontext;
	while (ctxt != toplevelcontext && ctxt->callflag != 2)
		ctxt = ctxt->nextcontext;
	if (ctxt->callflag == 2)
		ctxt->conexit = code;
	visible = 0;
	return nilValue;
}

SEXP do_envir(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	checkArity(op, args);

	if (TYPEOF(CAR(args)) == CLOSXP)
		return CLOENV(CAR(args));
	else if (CAR(args) == nilValue)
		return sysparent(1);
	return nilValue;
}

SEXP do_envirgets(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	checkArity(op, args);

	if (TYPEOF(CAR(args)) == CLOSXP && TYPEOF(CADR(args)) == ENVSXP)
		CLOENV(CAR(args)) = CADR(args);
	else
		errorcall(call, "wrong arguments\n");
	return CAR(args);
}

static void cat_newline(SEXP labels, RINT * width, RINT lablen, RINT ntot)
{
	Rprintf("\n");
	*width = 0;
	if (labels != nilValue) {
		Rprintf("%s ", EncodeString(CHAR(STRING(labels)[ntot % lablen]), 1, 0));
		*width += Rstrlen(CHAR(STRING(labels)[ntot % lablen])) + 1;
	}
}

static void cat_sepwidth(SEXP sep, RINT * width, RINT ntot)
{
	if (sep == nilValue || LENGTH(sep) == 0)
		*width = 0;
	else
		*width = Rstrlen(CHAR(STRING(sep)[ntot % LENGTH(sep)]));
}

static void cat_printsep(SEXP sep, RINT ntot)
{
	char *sepchar;
	RINT len;

	if (sep == nilValue || LENGTH(sep) == 0)
		return;

	sepchar = CHAR(STRING(sep)[ntot % LENGTH(sep)]);
	 Rprintf("%s",sepchar);
	return;
}


SEXP do_cat(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP a, sep, labels, s;
	char *tchar;
	FILE *savefp;
	RINT file;
	RINT w, d, e, i, n = 0, pwidth, width, sepw, lablen, ntot, nlsep;

	checkArity(op, args);

	/* check to see if a file needs to be opened */

	s = CADR(args);
	if (!isString(s))
		errorcall(call, "invalid sep= specification\n");
	tchar = CHAR(STRING(s)[0]);
	if (strlen(tchar) > 0) {
		s = CAR(nthcdr(args, 5));
		if (!isLogical(s))
			errorcall(call, "invalid append specification\n");
		savefp = Routputfile;
		if (LOGICAL(s)[0])
			Routputfile = fopen(tchar, "a");
		else
			Routputfile = fopen(tchar, "w");
		if (!Routputfile) {
			Routputfile = savefp;
			errorcall(call, "unable to open file\n");
		}
		file = 1 ;
	}
	else file = 0;

	/*
	 * find the separator, if any separator is a newline we need to have
	 * a newline at the end
	 */

	PROTECT(sep = CAR(CDDR(args)));
	if (!isString(sep))
		errorcall(call, "invalid sep= specification\n");
	nlsep = 0;
	if (isVector(sep))
		for (i = 0; i < LENGTH(sep); i++)
			if (streql(CHAR(STRING(sep)[i]), "\n"))
				nlsep = 1;


	/* find the printwidth */

	s = CAR(nthcdr(args, 3));
	if (!isVector(s) || (length(s) != 1))
		errorcall(call, "wrong fill argument\n");
	if (isLogical(s))
		if (LOGICAL(s)[0] == 1)
			pwidth = PRINT_WIDTH;
		else
			pwidth = INT_MAX;
	else if (isReal(s))
		pwidth = REAL(s)[0];
	else if (isInteger(s))
		pwidth = INTEGER(s)[0];
	else
		errorcall(call, "wrong fill argument\n");

	/* find the labels */
	PROTECT(labels = CAR(nthcdr(args, 4)));
	if (!isVector(labels) && labels != nilValue)
		errorcall(call, "wrong label argument\n");
	lablen = length(labels);

	args = CAR(args);
	for (a = args; a != nilValue; a = CDR(a)) {
		if (!isVector(CAR(a)))
			errorcall(call, "argument %d has invalid type\n", n + 1);
		n += 1;
	}
	width = 0;
	ntot = 0;
	for (a = args; a != nilValue; a = CDR(a)) {
		s = CAR(a);
		if (a != args)
			cat_printsep(sep, 0);
		n = LENGTH(s);
		if (n > 0) {
			if (labels != nilValue && a == args) {
				Rprintf("%s ", CHAR(STRING(labels)[0]));
				width += strlen(CHAR(STRING(labels)[ntot % lablen])) + 1;
				ntot++;
			}
			switch (TYPEOF(s)) {
			case LGLSXP:
				formatLogical(&(LOGICAL(s)[0]), 1, &w);
				cat_sepwidth(sep, &sepw, ntot);
				if (a != args && (width + w + sepw > pwidth))
					cat_newline(labels, &width, lablen, ntot);
				for (i = 0; i < n; i++, ntot++) {
					Rprintf("%s", EncodeLogical(LOGICAL(s)[i], w));
					width += w + sepw;
					if (i < (n - 1)) {
						cat_printsep(sep, ntot);
						formatLogical(&(LOGICAL(s)[i + 1]), 1, &w);
						cat_sepwidth(sep, &sepw, ntot);
						if ((width + w + sepw > pwidth) && pwidth)
							cat_newline(labels, &width, lablen, ntot);
					}
				}
				break;
			case INTSXP:
				formatInteger(&(INTEGER(s)[0]), 1, &w);
				cat_sepwidth(sep, &sepw, ntot);
				if (a != args && (width + w + sepw > pwidth))
					cat_newline(labels, &width, lablen, ntot);
				for (i = 0; i < n; i++, ntot++) {
					Rprintf("%s", EncodeInteger(INTEGER(s)[i], w));
					width += w + sepw;
					if (i < (n - 1)) {
						cat_printsep(sep, ntot);
						formatInteger(&(INTEGER(s)[i + 1]), 1, &w);
						cat_sepwidth(sep, &sepw, ntot);
						if ((width + w + sepw > pwidth) && pwidth)
							cat_newline(labels, &width, lablen, ntot);
					}
				}
				break;
			case REALSXP:
				formatReal(&(REAL(s)[0]), (RINT) 1, &w, &d, &e);
				cat_sepwidth(sep, &sepw, ntot);
				if (a != args && (width + w + sepw > pwidth))
					cat_newline(labels, &width, lablen, ntot);
				for (i = 0; i < n; i++, ntot++) {
					Rprintf("%s", EncodeReal(REAL(s)[i], w, d, e));
					width += w + sepw;
					if (i < (n - 1)) {
						cat_printsep(sep, ntot);
						formatReal(&(REAL(s)[i + 1]), (RINT) 1, &w, &d, &e);
						cat_sepwidth(sep, &sepw, ntot);
						if ((width + w + sepw) > pwidth && pwidth)
							cat_newline(labels, &width, lablen, ntot);
					}
				}
				break;
			case STRSXP:
				formatString(&(STRING(s)[0]), 1, &w, 0);
				cat_sepwidth(sep, &sepw, ntot);
				if (a != args && (width + w + sepw > pwidth))
					cat_newline(labels, &width, lablen, ntot);
				for (i = 0; i < n; i++, ntot++) {
					Rprintf("%s", CHAR(STRING(s)[i]));
					width += w + sepw;
					if (i < (n - 1)) {
						cat_printsep(sep, ntot);
						formatString(&(STRING(s)[i + 1]), 1, &w, 0);
						cat_sepwidth(sep, &sepw, ntot);
						if ((width + w + sepw > pwidth) && pwidth)
							cat_newline(labels, &width, lablen, ntot);
					}
				}
				break;
			}
		}
	}
	if ((pwidth != INT_MAX) || nlsep)
		Rprintf("\n");
	if (file) {
		fclose(Routputfile);
		Routputfile = savefp;
	}
	else
		fflush(stdout);
	UNPROTECT(2);
	visible = 0;
	return nilValue;
}


SEXP do_makelist(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP s = args;
	while (s != nilValue) {
		if (NAMED(CAR(s)))
			CAR(s) = duplicate(CAR(s));
		s = CDR(s);
	}
	return args;
}


SEXP do_makefactor(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP x, l, y;
	int i, j, nx, nl, ord;

	checkArity(op, args);
	x = CAR(args) = coerceVector(CAR(args), INTSXP);
	nl = asInteger(CADR(args));
	if (nl == NA_INTEGER || nl < 1)
		errorcall(call, "invalid number of factor levels\n");
	ord = asLogical(CADDR(args));
	if(ord == NA_LOGICAL) ord = 0;
	nx = LENGTH(x);
	y = allocVector(ord?ORDSXP:FACTSXP, nx);
	LEVELS(y) = nl;
	for (i = 0; i < nx; i++) {
		j = INTEGER(x)[i];
		if (1 <= j && j <= nl)
			FACTOR(y)[i] = j;
		else
			FACTOR(y)[i] = NA_INTEGER;
	}
	return y;
}

SEXP do_makevector(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT len, i;
	SEXP s;
	SEXPTYPE mode;

	checkArity(op, args);

	len = asInteger(CADR(args));
	s = coerceVector(CAR(args), STRSXP);
	mode = str2type(CHAR(STRING(s)[0]));
	if (mode == -1 && streql(CHAR(STRING(s)[0]), "double"))
		mode = REALSXP;
	if ((CHARSXP < mode) && (mode <= STRSXP))
		s = allocVector(mode, len);
	else if (mode == LISTSXP)
		s = allocList(len);
	else
		error("vector: cannot make a vector of the type specified\n");
	if (mode == INTSXP)
		for (i = 0; i < len; i++)
			INTEGER(s)[i] = 0;
	else if (mode == REALSXP)
		for (i = 0; i < len; i++)
			REAL(s)[i] = 0.0;
	return s;
}

/***************************************************************************
   do_unlist turns a list into a vector, sublists are handled recursively
   unlike the S function unlist does not propagate a names attribute if
   there is one (it can't really be done correctly, example:
		x<-list(1,2,3)
		y<-list(a=x,3.4)
		unlist(y)
  and S is confused)

 ***************************************************************************/

static RINT pos;

SEXP unlist(SEXP rval, SEXP s)
{
	char *strp;
	RINT i;
	SEXP t, cart, tmpchar;

	PROTECT(rval);
	for (t = s; t != nilValue; t = CDR(t)) {
		cart = CAR(t);
		switch (TYPEOF(cart)) {
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			for (i = 0; i < length(cart); i++)
				if (TYPEOF(rval) <= INTSXP)
					INTEGER(rval)[pos++] = INTEGER(cart)[i];
				else if (TYPEOF(rval) == REALSXP)
					REAL(rval)[pos++] = (INTEGER(cart)[i] == NA_INTEGER) ? NA_REAL : INTEGER(cart)[i];
				else {
					strp = EncodeElement(cart, i, 0);
					if (streql(strp, "NA"))
						STRING(rval)[pos++] = NA_STRING;
					else {
						tmpchar = allocString(strlen(strp));
						strcpy(CHAR(tmpchar), strp);
						STRING(rval)[pos++] = tmpchar;
					}
				}
			break;
		case REALSXP:
			for (i = 0; i < length(cart); i++)
				if (TYPEOF(rval) == REALSXP)
					REAL(rval)[pos++] = REAL(cart)[i];
				else {
					strp = EncodeElement(cart, i, 0);
					if (streql(strp, "NA"))
						STRING(rval)[pos++] = NA_STRING;
					else {
						tmpchar = allocString(strlen(strp));
						strcpy(CHAR(tmpchar), strp);
						STRING(rval)[pos++] = tmpchar;
					}
				}
			break;
		case STRSXP:
			for (i = 0; i < length(cart); i++)
				STRING(rval)[pos++] = STRING(cart)[i];
			break;
		case LISTSXP:
			unlist(rval, cart);
			break;
		default:
			abort();
		}
	}
	UNPROTECT(1);
	return rval;
}

static RINT maxmode(SEXP s)
{
	RINT mode = 0, mm;

	for (s; s != nilValue; s = CDR(s))
		if (isVector(CAR(s)))
			mode = (mode >= (RINT) TYPEOF(CAR(s))) ? mode : TYPEOF(CAR(s));
		else if (isList(CAR(s))) {
			mm = maxmode(CAR(s));
			mode = (mode >= mm) ? mode : mm;
		}
		else
			error("unlist: wrong type of argument\n");
	return mode;
}

SEXP do_unlist(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT i, len, mode;
	SEXP rval, s;

	checkArity(op, args);
	s = CAR(args);
	if (!isList(s))
		error("unlist: wrong argument\n");

	len = rlength(s);
	mode = maxmode(s);
	rval = allocVector(mode, len);
	pos = 0;
	return unlist(rval, s);
}

SEXP rec_unlist(SEXP s)
{
	RINT len, mode;
	SEXP rval;

	len = rlength(s);
	mode = maxmode(s);
	rval = allocVector(mode, len);
	pos = 0;
	return unlist(rval, s);
}

/**************************************************************************
	do_lengthassgn: assign a length to a vector or a list (if it is
	Vectorizable). We could probably be fairly clever with memory here
	if we wanted to.
***************************************************************************/

SEXP do_lengthgets(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT len, lenx, i;
	SEXP rval, x, names, xnames, t;

	checkArity(op, args);
	x = CAR(args);

	if (!isVector(x) && !isVectorizable(x))
		error("length<- wrong argument, 1\n");

	if (length(CADR(args)) != 1)
		error("length<- wrong argument, 2\n");

	len = asInteger(CADR(args));
	if (len == NA_INTEGER)
		error("length<- missing value for length\n");

	lenx = length(x);
	if (lenx == len)
		return (x);

	rval = allocVector(TYPEOF(x), len);

	PROTECT(xnames = getAttrib(x, NamesSymbol));
	if (xnames != nilValue)
		names = allocVector(STRSXP, len);

	switch (TYPEOF(x)) {
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
		for (i = 0; i < len; i++)
			if (i < lenx) {
				INTEGER(rval)[i] = INTEGER(x)[i];
				if (xnames != nilValue)
					STRING(names)[i] = STRING(xnames)[i];
			}
			else
				INTEGER(rval)[i] = NA_INTEGER;
		break;
	case REALSXP:
		for (i = 0; i < len; i++)
			if (i < lenx) {
				REAL(rval)[i] = REAL(x)[i];
				if (xnames != nilValue)
					STRING(names)[i] = STRING(xnames)[i];
			}
			else
				REAL(rval)[i] = NA_REAL;
		break;
	case STRSXP:
		for (i = 0; i < len; i++)
			if (i < lenx) {
				STRING(rval)[i] = STRING(x)[i];
				if (xnames != nilValue)
					STRING(names)[i] = STRING(xnames)[i];
			}
			else
				STRING(rval)[i] = NA_STRING;
		break;
	case LISTSXP:
		for (t = rval; t != nilValue; t = CDR(t), x = CDR(x)) {
			CAR(t) = CAR(x);
			TAG(t) = TAG(x);
		}
	}
	if (isVector(x) && xnames != nilValue)
		setAttrib(rval, NamesSymbol, names);
	UNPROTECT(1);
	return rval;
}

SEXP do_assign(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP name, val, aenv;
	RINT ginherits;

	checkArity(op, args);
	name = findVar(CAR(args), rho);

	PROTECT(args = evalList(args, rho));

	if (!isString(CAR(args)))
		error("assign: invalid argument\n");
	else
		name = install(CHAR(STRING(CAR(args))[0]));
	PROTECT(val = eval(CADR(args), rho));

	aenv = CAR(CDDR(args));
	if (TYPEOF(aenv) != ENVSXP && aenv != nilValue)
		error("invalid envir argument\n");

	if (isLogical(CAR(nthcdr(args, 3))))
		ginherits = LOGICAL(CAR(nthcdr(args, 3)))[0];
	else
		error("get: invalid inherits argument\n");
	if (ginherits)
		setVar(name, val, aenv);
	else
		defineVar(name, val, aenv);
	visible = 0;
	UNPROTECT(2);
	return nilValue;
}

/*
 * do_remove has 3 arguments, a list of names to remove, an optional
 * environment (if missing set it to globalEnv) and inherits, a logical
 * indicating whether to look in the parent env if a symbol is not found in
 * the supplied env. This is ignored if environment is not specified
 */

SEXP do_remove(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP name, aenv, tsym, tenv, tframe;
	RINT ginherits;
	int i, set;

	checkArity(op, args);

	name = CAR(args);
	if (!isList(name))
		error("invalid first argument to remove.\n");

	if (CADR(args) != nilValue) {
		if (TYPEOF(CADR(args)) != ENVSXP)
			error("invalid envir argument\n");
		else
			aenv = CADR(args);
	}
	else
		aenv = sysparent(1);

	if (isLogical(CAR(nthcdr(args, 2))))
		ginherits = LOGICAL(CAR(nthcdr(args, 2)))[0];
	else
		error("get: invalid inherits argument\n");

	for (name; name != nilValue; name = CDR(name)) {
		set = 0;
		if (isString(CAR(name)))
			tsym = install(CHAR(STRING(CAR(name))[0]));
		else if (isSymbol(CAR(name)))
			tsym = CAR(name);
		else
			error("remove: invalid first argument\n");
		tenv = aenv;
	      rmset:for (tframe = FRAME(tenv); tframe != nilValue; tframe = CDR(tframe))
			if (TAG(tframe) == tsym) {
				unbindVar(tsym, tenv);
				set = 1;
			}
		if (ginherits && !set && (tenv = ENCLOS(tenv)) != nilValue)
			goto rmset;
		if (!set)
			warning("remove: variable \"%s\" was not found\n", CHAR(PRINTNAME(tsym)));
	}
	visible = 0;
	return nilValue;
}

/*
 * do_get returns the SEXP associated with the character argument, do_get
 * needs the environment of the calling function as a default,
 * 
 */

SEXP do_get(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP rval, genv, t1;
	SEXPTYPE gmode;
	RINT ginherits;

	checkArity(op, args);

	/* set up the default environment */
	rval = findVar(CAR(args), rho);
	if (TYPEOF(rval) == PROMSXP)
		genv = PRENV(rval);

	args = evalList(args, rho);

	if (!isString(CAR(args)))
		error("get: invalid first argument\n");
	else
		t1 = install(CHAR(STRING(CAR(args))[0]));
	if (CADR(args) != nilValue) {
		if (TYPEOF(CADR(args)) != ENVSXP)
			error("get: invalid envir argument\n");
		else
			genv = CADR(args);
	}
	if (isString(CAR(CDDR(args))))
		gmode = str2type(CHAR(STRING(CAR(CDDR(args)))[0]));
	else
		error("get: invalid mode argument\n");
	if (isLogical(CAR(nthcdr(args, 3))))
		ginherits = LOGICAL(CAR(nthcdr(args, 3)))[0];
	else
		error("get: invalid inherits argument\n");

	rval = findVar1(t1, genv, gmode, ginherits);

	if (PRIMVAL(op)) {	/* we have a get */
		if (rval == unboundValue)
			error("get: variable \"%s\" was not found\n", CHAR(PRINTNAME(t1)));
		rval = eval(rval, genv);
		NAMED(rval) = 1;
		return rval;
	}
	else {
		if (rval == unboundValue)
			ginherits = 0;
		else
			ginherits = 1;
		rval = allocVector(LGLSXP, 1);
		LOGICAL(rval)[0] = ginherits;
		return (rval);
	}
}

SEXP findVar1(SEXP symbol, SEXP rho, SEXPTYPE mode, RINT inherits)
{
	SEXP vl;

	while (rho != nilValue) {
		vl = findVarInFrame(FRAME(rho), symbol);
		if (vl != unboundValue && (TYPEOF(vl) == mode || mode == ANYSXP))
			return (vl);
		if (inherits)
			rho = ENCLOS(rho);
		else
			return (unboundValue);
	}
	return (SYMVALUE(symbol));
}


/*
 * for switch, evaluate the first arg, if it is a character then try to match
 * the name with the remaining args, and evaluate the match, if there is no
 * match then evaluate the first unnamed arg.  If the value of the first arg 
 * is not a character string then coerce it to integer (k) and choose the kth 
 * argument from those that remain provided 0 < k < (nargs-1)
 * For character matching, if the value is missing then take the next 
 * non-missing arg as the value
 * then things like
 *  switch(as.character(answer), yes=, YES=1, no=, NO=2, 3)
 * work
 */

/* this guy needs to get checked out carefully at some point */
SEXP switchList(SEXP el, SEXP rho)
{
	SEXP rlist, s, w, h;

	if (CAR(el) == DotsSymbol) {
		h = findVar(CAR(el), rho);
		if (h == nilValue)
			return nilValue;
		if (TYPEOF(h) != DOTSXP) {
			if (h == missingArg)
				return missingArg;
			error("... used in an incorrect context\n");
		}
		PROTECT(rlist = allocList(length(h)));
		w = rlist;
		for (h; h != nilValue; h = CDR(h)) {
			s = CAR(h);
			TAG(w) = TAG(h);
			if (TYPEOF(s) == PROMSXP)
				if (PREXPR(s) == missingArg)
					CAR(w) = missingArg;
				else
					CAR(w) = eval(PREXPR(s), PRENV(s));
			w = CDR(w);
		}
	}
	UNPROTECT(1);
	return rlist;
}

SEXP do_switch(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT argval, len;
	SEXP x, y, w;

	x = eval(CAR(args), rho);
	if (!isVector(x) && length(x) != 1)
		error("switch: EXPR must return a length 1 vector\n");

	PROTECT(w = switchList(CDR(args), rho));
	if (isString(x)) {
		for (y = w; y != nilValue; y = CDR(y))
			if (streql(CHAR(STRING(x)[0]), CHAR(PRINTNAME(TAG(y))))) {
				while (CAR(y) == missingArg && y != nilValue)
					y = CDR(y);
				UNPROTECT(1);
				return (eval(CAR(y), rho));
			}
		for (y = w; y != nilValue; y = CDR(y))
			if (TAG(y) == nilValue) {
				UNPROTECT(1);
				return (eval(CAR(y), rho));
			}
		UNPROTECT(1);
		return nilValue;
	}
	argval = asInteger(x);
	if (argval <= 0 || argval > (length(w))) {
		UNPROTECT(1);
		return nilValue;
	}
	x = eval(CAR(nthcdr(w, argval - 1)), rho);
	UNPROTECT(1);
	return x;
}

void InitEd()
{
	tmpnam(EdFiLeName);
}

/*
 * ed, vi etc have 3 parameters. the data, a file and an editor
 * 
 * if file is specified then the given file is used (and not removed on exit) if
 * file is not specified then a temporary file is used; since only one
 * temporary file is used for an entire session previous editing is lost
 * 
 * if data is specified then it is passed out to be edited; if data is not
 * specified then either file (if specified) or the temporary file is used
 * (thus errors can be re-editied by calling edit a second time with no
 * arguments).
 * 
 * if the editor is specified then the specified editor is invoked if possible
 * and an error message reported otherwise
 */

SEXP do_edit(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int i, protected=0;
	SEXP x, fn, envir, ed;
	char tmpn[120], tmp2[140];
	FILE *fp;

	checkArity(op, args);

	x = CAR(args);
	if (TYPEOF(x) == CLOSXP) {
		PROTECT(envir = CLOENV(x));
		protected++;
	}

	fn = CADR(args);
	if (!isString(fn))
		error("invalid argument to edit()\n");
	if (LENGTH(STRING(fn)[0]) == 0)
		strcpy(tmpn, EdFiLeName);
	else
		strcpy(tmpn, CHAR(STRING(fn)[0]));

	if (x != nilValue) {
		fp = fopen(tmpn, "w");
		if (!fp)
			error("edit: unable to open file\n");
		x = deparse1(x, 0);
		for (i = 0; i < LENGTH(x); i++)
			fprintf(fp, "%s\n", CHAR(STRING(x)[i]));
		fclose(fp);
	}

	ed = CAR(CDDR(args));
	if (!isString(ed))
		error("editor type not valid\n");
	strcpy(tmp2, CHAR(STRING(ed)[0]));
	strcat(tmp2, " ");
	system(strcat(tmp2, tmpn));

	fp = fopen(tmpn, "r");
	if (!fp)
		error("edit: unable to open file to read\n");;
	x = parse(fp, 1);
	if (ParseError) {
		error("An error occurred on line %d\n use a command like\n x <- vi()\n to recover\n", ParseError);
	}
	x = eval(CAR(x), globalEnv);
	if (TYPEOF(x) == CLOSXP && envir != nilValue)
		CLOENV(x) = envir;
	UNPROTECT(protected);
	return (x);
}

SEXP do_options(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP s, t, w;
	char *what;
	RINT tmpi;

	if (args == nilValue)
		return (printOptions());

	for (t = args; t != nilValue; t = CDR(t)) {
		what = CHAR(PRINTNAME(TAG(t)));
		if (streql(what, "width")) {
			tmpi = asInteger(CAR(t));
			if (tmpi < MIN_WIDTH || tmpi > MAX_WIDTH)
				errorcall(call, "width parameter invalid\n");
			w = allocVector(INTSXP, 1);
			INTEGER(w)[0] = options_width;
			CAR(t) = w;
			options_width = tmpi;
		}
		else if (streql(what, "digits")) {
			tmpi = asInteger(CAR(t));
			if (tmpi < 1 || tmpi > 22)
				errorcall(call, "digits parameter invalid\n");
			w = allocVector(INTSXP, 1);
			INTEGER(w)[0] = options_digits;
			CAR(t) = w;
			options_digits = tmpi;
		}
		else if (streql(what, "expressions")) {
			tmpi = asInteger(CAR(t));
			if (tmpi < 25 || tmpi > MAX_EXPRESSIONS)
				errorcall(call, "expressions parameter invalid\n");
			w = allocVector(INTSXP, 1);
			INTEGER(w)[0] = options_expressions;
			CAR(t) = w;
			options_expressions = tmpi;
		}
		else if (streql(what, "editor")) {
			s = asChar(CAR(t));
			if (s == NA_STRING || length(s) == 0)
				errorcall(call, "editor parameter invalid\n");
			CAR(t) = mkString((char *) &options_editor);
			strcpy((char *) &options_editor, CHAR(s));
		}
		else if (streql(what, "continuation")) {
			s = asChar(CAR(t));
			if (s == NA_STRING || length(s) == 0)
				errorcall(call, "continuation parameter invalid\n");
			CAR(t) = mkString((char *) &options_continuation);
			strcpy((char *) &options_continuation, CHAR(s));
		}
		else if (streql(what, "prompt")) {
			s = asChar(CAR(t));
			if (s == NA_STRING || length(s) == 0)
				errorcall(call, "prompt parameter invalid\n");
			CAR(t) = mkString((char *) &options_prompt);
			strcpy((char *) &options_prompt, CHAR(s));
		}
		else
			errorcall(call, "this option is not supported\n");
	}
	visible = 0;
	return (args);
}

SEXP printOptions()
{
	SEXP s, t, w;

	PROTECT(s = allocList(6));
	t = s;
	TAG(t) = install("digits");
	w = allocVector(INTSXP, 1);
	INTEGER(w)[0] = options_digits;
	CAR(t) = w;
	t = CDR(t);
	TAG(t) = install("expressions");
	w = allocVector(INTSXP, 1);
	INTEGER(w)[0] = options_expressions;
	CAR(t) = w;
	t = CDR(t);
	TAG(t) = install("width");
	w = allocVector(INTSXP, 1);
	INTEGER(w)[0] = options_width;
	CAR(t) = w;
	t = CDR(t);
	TAG(t) = install("prompt");
	CAR(t) = mkString((char *) &options_prompt);
	t = CDR(t);
	TAG(t) = install("continuation");
	CAR(t) = mkString((char *) &options_continuation);
	t = CDR(t);
	TAG(t) = install("editor");
	CAR(t) = mkString((char *) &options_editor);
	visible = 1;
	UNPROTECT(1);
	return (s);
}
