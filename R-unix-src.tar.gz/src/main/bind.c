/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
static SEXP cbind(SEXP, SEXPTYPE);
static SEXP rbind(SEXP, SEXPTYPE);

/* unlike S, we don't propagate attributes on arrays in bind, since
   this only makes sense if they are identical and who wants to check  */

SEXP do_bind(SEXP call, SEXP op, SEXP args, SEXP env)
{
	RINT i, k, n;
	int mode, flags;
	SEXP t, u, result, rec, top, tmp;

	n = 0;
	flags = 0;
	if (PRIMVAL(op) == 0) {
		t = CAR(args);
		rec = CADR(args);
	}
	else {
		t = args;
		rec = nilValue;
	}

	for (t; t != nilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			if (!isVector(CAR(t)) && !isList(CAR(t)))
				error("non vector in c(...)\n");
			if (isList(CAR(t)) && rec != nilValue && LOGICAL(rec)[0] == 1)
				CAR(t) = do_unlist(call, op, t, env);
			switch (TYPEOF(CAR(t))) {
			case LGLSXP:
				flags |= 1;
				break;
			case FACTSXP:
				flags |= 2;
				break;
			case ORDSXP:
				flags |= 4;
				break;
			case INTSXP:
				flags |= 8;
				break;
			case REALSXP:
				flags |= 16;
				break;
			case STRSXP:
				flags |= 32;
				break;
			case LISTSXP:
				flags |= 64;
				break;
			}
			n += length(CAR(t));
		}
	}

	if (n == 0)
		return nilValue;

	if (flags >= 64) {
		if (flags & 64)
			mode = LISTSXP;
	}
	else if (flags >= 32) {
		if (flags & 32)
			mode = STRSXP;
	}
	else {
		if (flags & 1)
			mode = LGLSXP;
		if (flags & 2)
			mode = FACTSXP;
		if (flags & 4)
			mode = ORDSXP;
		if (flags & 8)
			mode = INTSXP;
		if (flags & 16)
			mode = REALSXP;
	}

	switch (PRIMVAL(op)) {
	case 0:
		PROTECT(rec);
		PROTECT(result = allocVector(mode, n));
		break;
	case 1:
		return cbind(args, mode);
	case 2:
		return rbind(args, mode);
	default:
		abort();
	}

	n = 0;
	top = result;
	if (mode == STRSXP) {
		for (t = CAR(args); t != nilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				CAR(t) = coerceVector(CAR(t), STRSXP);
				u = CAR(t);
				k = LENGTH(u);
				for (i = 0; i < k; i++) {
					STRING(result)[n++] = STRING(u)[i];
				}
			}
		}
	}
	else if (mode == LISTSXP) {
		for (t = CAR(args); t != nilValue; t = CDR(t)) {
			switch (TYPEOF(CAR(t))) {
			case NILSXP:
				break;
			case LISTSXP:
				for (u = CAR(t); u != nilValue; u = CDR(u), result = CDR(result)) {
					CAR(result) = duplicate(CAR(u));
					TAG(result) = TAG(u);
				}
				break;
			default:
				for (i = 0; i < LENGTH(CAR(t)); i++) {
					tmp = allocVector(TYPEOF(CAR(t)), 1);
					switch (TYPEOF(CAR(t))) {
					case INTSXP:
					case FACTSXP:
					case ORDSXP:
					case LGLSXP:
						INTEGER(tmp)[0] = INTEGER(CAR(t))[i];
						break;
					case REALSXP:
						REAL(tmp)[0] = REAL(CAR(t))[i];
						break;
					case STRSXP:
						STRING(tmp)[0] = STRING(CAR(t))[i];
						break;
					}
					CAR(result) = tmp;
					result = CDR(result);
				}
			}
		}
	}
	else {
		for (t = CAR(args); t != nilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				u = CAR(t);
				k = LENGTH(u);
				if (TYPEOF(u) <= INTSXP) {
					if (mode <= INTSXP) {
						for (i = 0; i < k; i++)
							INTEGER(result)[n++] = INTEGER(u)[i];
					}
					else {
						for (i = 0; i < k; i++)
							REAL(result)[n++] = (INTEGER(u)[i]) == NA_INTEGER ? NA_REAL : INTEGER(u)[i];
					}
				}
				else {
					for (i = 0; i < k; i++)
						REAL(result)[n++] = REAL(u)[i];
				}
			}
		}
	}
	UNPROTECT(2);
	return top;
}

static nonconform()
{
	error("non-conforming arguments in cbind\n");
}

SEXP cbind(SEXP args, SEXPTYPE mode)
{
	RINT k, i, rows = 0, cols = 0, mrows = 0, idx, n;
	SEXP t, u, result, dims;

	for (t = args; t != nilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			dims = getAttrib(CAR(t), DimSymbol);
			if (dims != nilValue) {
				cols += INTEGER(dims)[1];
				if (mrows == 0)
					mrows = INTEGER(dims)[0];
				else if (mrows != INTEGER(dims)[0])
					nonconform();
			}
			else {
				cols++;
				rows = (rows > length(CAR(t))) ? rows : length(CAR(t));
			}
		}
	}
	if (mrows != 0) {
		if (rows != 0 && rows != 1 && rows != mrows)
			nonconform();
		else
			rows = mrows;
	}
	PROTECT(result = allocMatrix(mode, rows, cols));
	n = 0;

	if (mode == STRSXP) {
		for (t = args; t != nilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				u = CAR(t) = coerceVector(CAR(t), STRSXP);
				k = LENGTH(u);
				idx = (!isArray(CAR(t))) ? rows : k;
				for (i = 0; i < idx; i++)
					STRING(result)[n++] = STRING(u)[i % k];
			}
		}
	}
	else {
		for (t = args; t != nilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				u = CAR(t);
				k = LENGTH(u);
				idx = (!isArray(CAR(t))) ? rows : k;
				if (TYPEOF(u) <= INTSXP) {
					if (mode <= INTSXP) {
						for (i = 0; i < idx; i++)
							INTEGER(result)[n++] = INTEGER(u)[i % k];
					}
					else {
						for (i = 0; i < idx; i++)
							REAL(result)[n++] = (INTEGER(u)[i % k]) == NA_INTEGER ? NA_REAL : INTEGER(u)[i % k];
					}
				}
				else {
					for (i = 0; i < idx; i++)
						REAL(result)[n++] = REAL(u)[i % k];
				}
			}
		}
	}
	UNPROTECT(1);
	return result;
}

SEXP rbind(SEXP args, SEXPTYPE mode)
{
	RINT i, j, k, rows = 0, cols = 0, mcols = 0, n, rowctr = 0, mrows = 0;
	SEXP t, u, result, dims;

	for (t = args; t != nilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			dims = getAttrib(CAR(t), DimSymbol);
			if (dims != nilValue) {
				rows += INTEGER(dims)[0];
				if (mcols == 0)
					mcols = INTEGER(dims)[1];
				if (mcols != INTEGER(dims)[1])
					error("rbind: number of cols must be equal for all matrices\n");
			}
			else {
				rows++;
				cols = (cols > length(CAR(t))) ? cols : length(CAR(t));
			}
		}
	}
	if (mcols != 0)
		cols = mcols;
	PROTECT(result = allocMatrix(mode, rows, cols));
	n = 0;
	rowctr = 0;
	if (mode == STRSXP) {
		for (t = args; t != nilValue; t = CDR(t)) {
			if (!isNull(CAR(t))) {
				CAR(t) = coerceVector(CAR(t), STRSXP);
				u = CAR(t);
				k = LENGTH(u);
				mrows = (isArray(u)) ? nrows(u) : 1;
				for (i = 0; i < mrows; i++)
					for (j = 0; j < cols; j++)
						STRING(result)[i + rowctr + (j * rows)] = STRING(u)[(i + j * mrows) % k];
				rowctr += mrows;
			}
		}
		UNPROTECT(1);
		return result;
	}
	for (t = args; t != nilValue; t = CDR(t)) {
		if (!isNull(CAR(t))) {
			u = CAR(t);
			k = LENGTH(u);
			mrows = (isArray(u)) ? nrows(u) : 1;
			if (TYPEOF(u) <= INTSXP) {
				if (mode <= INTSXP) {
					for (i = 0; i < mrows; i++)
						for (j = 0; j < cols; j++)
							INTEGER(result)[i + rowctr + (j * rows)] = INTEGER(u)[(i + j * mrows) % k];
					rowctr += mrows;
				}
				else {
					for (i = 0; i < mrows; i++)
						for (j = 0; j < cols; j++)
							REAL(result)[i + rowctr + (j * rows)] = (INTEGER(u)[(i + j * mrows) % k]) == NA_INTEGER ? NA_REAL : INTEGER(u)[(i + j * mrows) % k];
					rowctr += mrows;
				}
			}
			else {
				for (i = 0; i < mrows; i++)
					for (j = 0; j < cols; j++)
						REAL(result)[i + rowctr + (j * rows)] = REAL(u)[(i + j * mrows) % k];
				rowctr += mrows;
			}
		}
	}
	UNPROTECT(1);
	return result;
}
