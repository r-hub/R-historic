/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

extern FILE *yyin;
extern int errno;
extern SEXP currentExp;
extern SEXP growlist(SEXP, SEXP);
extern SEXP newlist(void);

SEXP parse(FILE *, int);

/* 
   do_parse, the user interface input/output to files. See parse,
   below, for the internal function
   args are file, number, text, prompt
   if there is text then that is read and the other arguments are ignored
 */

SEXP do_parse(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, u;
	FILE *fp;
	int num;
	char tmpn[100];

	checkArity(op, args);

	s = CAR(nthcdr(args, 2));
	if (s != nilValue) {
		if (!isString(s))
			errorcall(call, "wrong text specification\n");
		ParseText = s;
		ParseCnt = 0;
	}
	else {
		ParseText = nilValue;
		s = CAR(args);
		if (!isString(CAR(args)))
			errorcall(call, "unable to open specified file for parsing\n");
		if (strlen(CHAR(STRING(s)[0])) == 0) {
			t = CAR(nthcdr(args, 3));
			currentExp = nilValue;
			if (isString(t))
				yyprompt(CHAR(STRING(t)[0]));
			else
				yyprompt("> ");
			yyparse();
			return list1(currentExp);
		}
		else {
			fp = fopen(CHAR(STRING(CAR(args))[0]), "r");
			if (!fp)
				errorcall(call, "unable to open specified file for parsing\n");
		}
	}
	if (isNumeric(CADR(args))) {
		t = coerceVector(CADR(args), REALSXP);
		num = REAL(t)[0];
	}
	else
		num = -1;
	s = parse(fp, num);
	if (ParseError) {
		if (fp)
			error("an error occurred on line %d of file %s\n",
			      ParseError, CHAR(STRING(CAR(args))[0]));
	}
	return s;
}

/* 
   parse a function that reads a specified number of items from a
   file. If the specified number is negative then parse reads until
   an EOF is encountered. Functions like do_edit rely on parse.
   parse returns a list each element of which is a parsed but
   unevaluated expression, evaluation if required should be
   handled by the calling function
   If an error in parsing occurs rval is set to nilvalue and we halt
   parsing. The global variable ParseError is set to 1 (we could set
   it to j and then we could say what line of the file was not correct).
 */

SEXP parse(FILE * fp, int number)
{
	int j, pflag;
	SEXP rval = nilValue, top;


	if (ParseText == nilValue) {
		if (R_Console == 0)
			fclose(yyin);
		yyin = fp;
		R_Console = 0;
	}
	currentExp = nilValue;
	pflag = 3;
	if (number > 0) {
		/* read in number objects from file fp */
		PROTECT(rval = top = allocList(number));
		for (j = 0; j < number; j++, top = CDR(top)) {
		again:	pflag = yyparse();
			if (pflag == 1) {	/*an error on parsing */
				ParseError = j + 1;
				rval = nilValue;
				break;
			}
			if (pflag == 2)
				goto again;
			if (pflag == 0)
				error("parse: EOF encountered unexpectedly\n");
			if (currentExp)
				CAR(top) = currentExp;
		}
	}
	else {
		PROTECT(rval = newlist());
		for (j = 0;; j++) {
		      again2:pflag = yyparse();
			if (pflag == 1) {
				ParseError = j + 1;
				rval = nilValue;
				break;
			}
			if (pflag == 0) {
				rval = CDR(rval);
				break;
			}
			if (currentExp)
				rval = growlist(rval, currentExp);
		}
	}
	UNPROTECT(1);
	/* reset ParseText when we are done parsing */
	ParseText = nilValue;
	return rval;
}
