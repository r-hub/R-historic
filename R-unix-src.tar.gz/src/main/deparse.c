/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Print.h"
#include "names.h"

/*
 *	Global Variables:
 *
 *	linenumber: counts the number of lines that have been written,
 *	this is used to setup storage for deparseing.
 * 
 *	len: counts the length of the current line, it will be used to
 *	determine when to break lines.
 *
 *	incurly: keeps track of whether we are inside a curly or not,
 *	this affects the printing of if-then-else.
 *
 *	startline: indicator 0=start of a line (so we can tab out to
 *	the correct place).
 *
 *	indent: how many tabs should be written at the start of a line.
 *
 *	buff: contains the current string, we attempt to break lines at
 *	70, but can handle up to 512 characters.
 *
 *	lbreak: often used to indicate whether a line has been broken,
 *	this makes sure that that indenting behaves itself.
 */

static char buff[512];
/* static char buff2[MAXELTSIZE];	/* should be used to get elements from arrays */
static RINT linenumber;
static RINT len;
static RINT incurly = 0;
static RINT startline = 0;
static RINT indent = 0;
static SEXP strvec;

static void stuff(void);

static void args2buff(SEXP, RINT);
static void deparse2buff(SEXP);
static void formals2buff(SEXP);
static void print2buff(char *);
static void printtab2buff(int);
static void scalar2buff(SEXP);
static void writeline(void);
static void vector2buff(SEXP);
void deparse2(SEXP, SEXP);

/* 
   deparse, has 3 layers, for the following reasons,
   the user interface, do_deparse, should not be called from an
   internal function, the actual deparsing needs to be done
   twice, once to count things up and a second time to put them
   into the string vector for return. Printing this to a file
   is handled by the calling routine.
 */

SEXP do_deparse(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	return deparse1(CAR(args), 0);
}

/* 
   deparse1 gets a second argument, Short. If short is 1 then the returned
   value is a STRSXP of length 1 with at most 10 characters, then ...
   why?????????
 */

SEXP deparse1(SEXP call, RINT Short)
{
	RINT i;
	SEXP svec;

	svec = nilValue;
	deparse2(call, svec);
	PROTECT(svec = allocVector(STRSXP, linenumber));
	deparse2(call, svec);
	UNPROTECT(1);
	if (Short == 1) {
		strncpy(buff, CHAR(STRING(svec)[0]), 10);
		if (strlen(buff) > 10)
			strcat(buff, "...");
		PROTECT(svec = allocVector(STRSXP, 1));
		STRING(svec)[0] = mkChar(buff);
		UNPROTECT(1);
	}
	return svec;
}

SEXP do_dput(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	FILE *fp;
	SEXP tval;
	SEXP saveenv;
	int i;

	checkArity(op, args);
	tval = CAR(args);
	if (TYPEOF(tval) == CLOSXP) {
		PROTECT(saveenv = CLOENV(tval));
		CLOENV(tval) = globalEnv;
	}
	tval = deparse1(tval, 0);
	if (TYPEOF(CAR(args)) == CLOSXP) {
		CLOENV(CAR(args)) = saveenv;
		UNPROTECT(1);
	}
	fp = NULL;
	if (strlen(CHAR(STRING(CADR(args))[0])) > 0) {
		fp = fopen(CHAR(STRING(CADR(args))[0]), "w");
		if (!fp)
			errorcall(call, "unable to open file\n");
	}
	for (i = 0; i < LENGTH(tval); i++)
		if (fp == NULL)
			Rprintf("%s\n", CHAR(STRING(tval)[i]));
		else
			fprintf(fp, "%s\n", CHAR(STRING(tval)[i]));
	if (fp != NULL)
		fclose(fp);
	visible = 0;
	return (CAR(args));
}

void deparse2(SEXP what, SEXP svec)
{
	strvec = svec;
	linenumber = 0;
	indent = 0;
	deparse2buff(what);
	writeline();
}

/* curly ahead looks at s to see if it is a list with the first op being
   a curly. You need this kind of lookahead info to print if statements
   correctly.
 */
static RINT curlyahead(SEXP s)
{
	if (isList(s) || isLanguage(s))
		if (TYPEOF(CAR(s)) == SYMSXP)
			if (TYPEOF(SYMVALUE(CAR(s))) == SPECIALSXP)
				if (PRIMVAL(SYMVALUE(CAR(s))) == BEGINOP)
					return 1;
	return 0;
}



/* this is the recursive part   */
void deparse2buff(SEXP s)
{
	RINT i, n, fop, lookahead, lbreak = 0;
	SEXP op, cmnt;
	char tpb[120];

	switch (TYPEOF(s)) {
	case NILSXP:
		print2buff("NULL");
		break;
	case SYMSXP:
		print2buff(CHAR(PRINTNAME(s)));
		break;
	case SPECIALSXP:
	case BUILTINSXP:
		sprintf(tpb, "<primitive: %s>", PRIMNAME(s));
		print2buff(tpb);
		break;
	case PROMSXP:
		deparse2buff(PREXPR(s));
		break;
	case CLOSXP:
		print2buff("function (");
		formals2buff(FORMALS(s));
		print2buff(") ");
		writeline();
		deparse2buff(BODY(s));
		break;
	case ENVSXP:
		print2buff("<environment>");
		break;
	case LISTSXP:
		print2buff("<list>");
		break;
	case LANGSXP:
		cmnt = TAG(s);
		if (cmnt != nilValue && CAR(s) != install("{"))
			for (op = TAG(s); op != nilValue; op = CDR(op)) {
				print2buff(CHAR(STRING(CAR(op))[0]));
				writeline();
			}
		if (TYPEOF(CAR(s)) == SYMSXP) {
			if ((TYPEOF(SYMVALUE(CAR(s))) == BUILTINSXP) ||
			    (TYPEOF(SYMVALUE(CAR(s))) == SPECIALSXP)) {
				op = CAR(s);
				fop = PPINFO(SYMVALUE(op));
				s = CDR(s);
				if (fop == PP_BINARY && length(s) == 1)
					fop = PP_UNARY;
				switch (fop) {
				case PP_IF:
					print2buff("if (");
					/* print the predicate */
					deparse2buff(CAR(s));
					print2buff(") ");
					if (incurly) {
						lookahead = curlyahead(CAR(CDR(s)));
						if (!lookahead) {
							writeline();
							indent++;
						}
					}
					/* need to find out if there is an else */
					if (length(s) > 2) {
						deparse2buff(CAR(CDR(s)));
						if (incurly > 0) {
							writeline();
							if (!lookahead)
								indent--;
						}
						else
							print2buff(" ");
						print2buff("else ");
						deparse2buff(CAR(CDDR(s)));
					}
					else {
						deparse2buff(CAR(CDR(s)));
						if (incurly > 0 && !lookahead)
							indent--;
					}
					break;
				case PP_WHILE:
					print2buff("while (");
					deparse2buff(CAR(s));
					print2buff(") ");
					deparse2buff(CADR(s));
					break;
				case PP_FOR:
					print2buff("for (");
					deparse2buff(CAR(s));
					print2buff(" in ");
					deparse2buff(CADR(s));
					print2buff(") ");
					deparse2buff(CDR(CDR(s)));
					break;
				case PP_REPEAT:
					print2buff("repeat ");
					deparse2buff(CAR(s));
					break;
				case PP_CURLY:
					print2buff("{");
					incurly += 1;
					indent++;
					writeline();
					while (s != nilValue) {
						deparse2buff(CAR(s));
						writeline();
						if ((cmnt = TAG(s)) != nilValue)
							while (cmnt != nilValue) {
								print2buff(CHAR(STRING(CAR(cmnt))[0]));
								writeline();
								cmnt = CDR(cmnt);
							}
						s = CDR(s);
					}
					indent--;
					print2buff("}");
					incurly -= 1;
					break;
				case PP_PAREN:
					print2buff("(");
					deparse2buff(CAR(s));
					print2buff(")");
					break;
				case PP_SUBSET:
					deparse2buff(CAR(s));
					if (PRIMVAL(SYMVALUE(op)) == 1)
						print2buff("[");
					else
						print2buff("[[");
					args2buff(CADR(s), 0);
					if (PRIMVAL(SYMVALUE(op)) == 1)
						print2buff("]");
					else
						print2buff("]]");
					break;
				case PP_FUNCALL:
				case PP_RETURN:
					print2buff(CHAR(PRINTNAME(op)));
					print2buff("(");
					args2buff(s, 0);
					print2buff(")");
					break;
				case PP_FOREIGN:
					print2buff(CHAR(PRINTNAME(op)));
					print2buff("(");
					args2buff(s, 1);
					print2buff(")");
					break;
				case PP_FUNCTION:
					print2buff(CHAR(PRINTNAME(op)));
					print2buff("(");
					formals2buff(CAR(s));
					print2buff(") ");
					deparse2buff(CADR(s));
					break;
				case PP_ASSIGN:
				case PP_ASSIGN2:
					deparse2buff(CAR(s));
					print2buff(" ");
					print2buff(CHAR(PRINTNAME(op)));
					print2buff(" ");
					deparse2buff(CADR(s));
					break;
				case PP_DOLLAR:
					deparse2buff(CAR(s));
					print2buff("$");
					deparse2buff(CAR(CADR(s)));
					break;
				case PP_BINARY:
					deparse2buff(CAR(s));
					print2buff(" ");
					print2buff(CHAR(PRINTNAME(op)));
					print2buff(" ");
					if ((len > 70)) {
						if (!lbreak) {
							lbreak = 1;
							indent++;
						}
						writeline();
					}
					deparse2buff(CADR(s));
					if (lbreak) {
						indent--;
						lbreak = 0;
					}
					break;
				case PP_BINARY2:	/* no space between op and args */
					deparse2buff(CAR(s));
					print2buff(CHAR(PRINTNAME(op)));
					deparse2buff(CADR(s));
					break;
				case PP_UNARY:
					print2buff(CHAR(PRINTNAME(op)));
					deparse2buff(CAR(s));
					break;
				case PP_BREAK:
					print2buff("break");
					break;
				case PP_NEXT:
					print2buff("next");
					break;
				case PP_SUBASS:

					break;
				default:
					abort();
				}
			}
			else {
				if(isSymbol(CAR(s)) && isUserBinop(CAR(s))) {
					op = CAR(s);
					s = CDR(s);
					deparse2buff(CAR(s));
					print2buff(" ");
					print2buff(CHAR(PRINTNAME(op)));
					print2buff(" ");
					if ((len > 70)) {
						if (!lbreak) {
							lbreak = 1;
							indent++;
						}
						writeline();
					}
					deparse2buff(CADR(s));
					if (lbreak) {
						indent--;
						lbreak = 0;
					}
					break;
				}
				else {
					deparse2buff(CAR(s));
					print2buff("(");
					args2buff(CDR(s), 0);
					print2buff(")");
				}
			}
		}
		else if (TYPEOF(CAR(s)) == CLOSXP || TYPEOF(CAR(s)) == SPECIALSXP
			 || TYPEOF(CAR(s)) == BUILTINSXP) {
			deparse2buff(CAR(s));
			print2buff("(");
			args2buff(CDR(s), 0);
			print2buff(")");
		}
		else
			deparse2buff(CAR(s));

		break;
	case STRSXP:
	case LGLSXP:
	case INTSXP:
	case REALSXP:
	case FACTSXP:
	case ORDSXP:
		vector2buff(s);
		break;
	default:
		abort();
	}
}

/* 
   if there is a string array active point to that, and
   otherwise we are counting lines so don't do anything
 */

void writeline()
{
	if (strvec != nilValue)
		STRING(strvec)[linenumber] = mkChar(buff);
	linenumber++;
	/* reset */
	len = 0;
	buff[0] = '\0';
	startline = 0;
}

void print2buff(char *strng)
{
	int tlen, bufflen;

	if (startline == 0) {
		startline = 1;
		printtab2buff(indent);	/*if at the start of a line tab over */
	}
	tlen = strlen(strng);
	bufflen = strlen(buff);
	if (bufflen + tlen > 512) {
		buff[0] = '\0';
		error("string too long in deparse\n");
	}
	strcat(buff, strng);
	len += tlen;
}

void scalar2buff(SEXP inscalar)
{
	char *strp;
	strp = EncodeElement(inscalar, 0, '"');
	print2buff(strp);
}

void vector2buff(SEXP vector)
{
	RINT tlen, i;
	char *strp;

	tlen = length(vector);
	if (tlen == 1)
		scalar2buff(vector);
	else {
		print2buff("c(");
		for (i = 0; i < tlen; i++) {
			strp = EncodeElement(vector, i, 0);
			print2buff(strp);
			if (i < (tlen - 1))
				print2buff(", ");
			if (len > 70)
				writeline();
		}
		print2buff(")");
	}
}


static void formals2buff(SEXP arglist)
{
	int lbreak = 0;

	while (arglist != nilValue) {
		deparse2buff(CAR(arglist));
		if (TAG(arglist) != missingArg) {
			print2buff(" = ");
			if (len > 70) {
				if (!lbreak) {
					lbreak = 1;
					indent++;
				}
				writeline();
			}
			deparse2buff(TAG(arglist));
		}
		arglist = CDR(arglist);
		if (arglist != nilValue)
			print2buff(", ");
		if (len > 70) {
			if (!lbreak) {
				lbreak = 1;
				indent++;
			}
			writeline();
		}
	}
	if (lbreak)
		indent--;
}

static void args2buff(SEXP arglist, RINT lineb)
{
	int lbreak = 0;

	while (arglist != nilValue) {
		if (TAG(arglist) != nilValue) {
			deparse2buff(TAG(arglist));
			print2buff(" = ");
		}
		if (len > 70) {
			if (!lbreak) {
				lbreak = 1;
				indent++;
			}
			writeline();
		}
		deparse2buff(CAR(arglist));
		arglist = CDR(arglist);
		if (arglist != nilValue)
			print2buff(", ");
		if (len > 70 || lineb) {
			if (!lbreak) {
				lbreak = 1;
				indent++;
			}
			writeline();
		}
	}
	if (lbreak)
		indent--;
}

/*
   following the S style, print 4 tabs and then start printing spaces only
 */

static void printtab2buff(int ntab)
{
	RINT i;

	for (i = 1; i <= ntab; i++)
		if (i <= 4)
			print2buff("\t");
		else
			print2buff(" ");
}
