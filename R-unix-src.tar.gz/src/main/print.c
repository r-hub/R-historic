/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Print.h"

#define TAGBUFLEN 256
static char tagbuf[TAGBUFLEN + 5];

SEXP do_sink(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	FILE *fp;

	visible = 0;
	switch (length(args)) {
	case 0:
		if(Rsinkfile) fclose(Rsinkfile);
		Rsinkfile = NULL;
		Routputfile = Rconsolefile;
		return nilValue;
		break;
	case 1:
		if(TYPEOF(CAR(args)) != STRSXP || LENGTH(CAR(args)) != 1)
			errorcall(call, "invalid file name\n");
		if( !(fp=fopen(CHAR(STRING(CAR(args))[0]), "w")))
			errorcall(call, "unable to open file\n");
		Rsinkfile = fp;
		Routputfile = fp;
		return nilValue;
		break;
	default:
		checkArity(op, args);
	}
}

SEXP do_invisible(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	visible = 0;
	switch (length(args)) {
	case 0:
		return nilValue;
		break;
	case 1:
		return CAR(args);
		break;
	default:
		checkArity(op, args);
	}
}

SEXP do_print(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	int quote, tmp;

	checkArity(op, args);
	tmp = options_digits;
	quote = asInteger(CADR(args));
	if (quote == NA_INTEGER || quote < 1 || quote > 22)
		errorcall(call, "invalid digits parameter\n");
	options_digits = quote;
	if (isString(CAR(args)))
		quote = asLogical(CAR(CDDR(args)));
	prValue(CAR(args), quote);
	options_digits = tmp;
	visible = 0;
	return CAR(args);
}

static void printAttributes(SEXP);

/* prValueRec - recursively print an SEXP */
void prValueRec(SEXP s, int quote)
{
	int i, n, j, taglen;
	SEXP t;
	char *ptag, *ntag;

	switch (TYPEOF(s)) {
	case NILSXP:
		Rprintf("NULL\n");
		break;
	case SYMSXP:
		Rprintf("%s\n", CHAR(PRINTNAME(s)));
		break;
	case SPECIALSXP:
	case BUILTINSXP:
		Rprintf("<primitive: %s>\n", PRIMNAME(s));
		break;
	case CHARSXP:
		Rprintf("\"%s\"\n", EncodeString(CHAR(s),0,'"'));
		break;
	case CLOSXP:
	case LANGSXP:
		if (TYPEOF(s) == CLOSXP) t = CLOENV(s);
		else t = globalEnv;
		s = deparse1(s, 0);
		for (i = 0; i < LENGTH(s); i++)
			Rprintf("%s\n", CHAR(STRING(s)[i]));
		if (t != globalEnv)
			Rprintf("<environment: %p>\n", s);
		break;
	case ENVSXP:
		if (s == globalEnv) Rprintf("<environment: globalEnv>\n");
		else Rprintf("<environment: %p>\n", s);
		if (s != globalEnv)
			prValueRec(FRAME(s), quote);
		break;
	case PROMSXP:
		Rprintf("<promise: %p>\n", s);
		break;
	case LISTSXP:
		i = 1;
		taglen = strlen(tagbuf);
		ptag = tagbuf + taglen;
		while (TYPEOF(s) == LISTSXP || TYPEOF(s) == FRAMESXP) {
			if (i > 1) Rprintf("\n");
			if (TAG(s) != nilValue && isSymbol(TAG(s))) {
				if (taglen + strlen(CHAR(PRINTNAME(TAG(s)))) > TAGBUFLEN)
					sprintf(ptag, "$...");
				else
					sprintf(ptag, "$%s", CHAR(PRINTNAME(TAG(s))));
			}
			else {
				if (taglen + IndexWidth(i) > TAGBUFLEN)
					sprintf(ptag, "$...");
				else
					sprintf(ptag, "[[%d]]", i);
			}
			Rprintf("%s\n", ptag);
			prValueRec(CAR(s), quote);
			*ptag = '\0';
			s = CDR(s);
			i += 1;
		}
		if (s != nilValue) {
			Rprintf("\n. \n\n");
			prValueRec(s, quote);
		}
		Rprintf("\n");
		break;
	case FRAMESXP:
		printDataFrame(s);
		Rprintf("\n");
		break;
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
	case REALSXP:
	case STRSXP:
		PROTECT(t = getAttrib(s, DimSymbol));
		if (TYPEOF(t) == INTSXP) {
			if (LENGTH(t) == 1) {
				PROTECT(t = getAttrib(s, DimNamesSymbol));
				if (t != nilValue)
					printNamedVector(s, CAR(t), quote);
				else
					printVector(s, (RINT) 1, quote);
			}
			else if (LENGTH(t) == 2)
				printMatrix(s, t, NULL, NULL, quote);
			else
				printArray(s, quote);
		}
		else {
			UNPROTECT(1);
			PROTECT(t = getAttrib(s, NamesSymbol));
			if (t != nilValue)
				printNamedVector(s, t, quote);
			else
				printVector(s, (RINT) 1, quote);
		}
		UNPROTECT(1);
		printAttributes(s);
		break;
	default:
		abort();
	}
}

static void printAttributes(SEXP s)
{
	SEXP a;
	SEXP LevelsSymbol;
	char *ptag;
	int i;

	a = ATTRIB(s);
	if (a != nilValue) {
		LevelsSymbol = install("levels");
		ptag = tagbuf + strlen(tagbuf);
		i = 1;
		while (a != nilValue) {
			if (TAG(a) != NamesSymbol &&
			    TAG(a) != DimNamesSymbol &&
			    TAG(a) != DimSymbol &&
			    TAG(a) != LevelsSymbol) {
				if (i > 1)
					Rprintf("\n");
				/*
				sprintf(ptag, "$%s", EncodeString(CHAR(PRINTNAME(TAG(a))),0,0));
				Rprintf("%s:\n", tagbuf);
				*/
				Rprintf("attr(%s,\"%s\")\n", tagbuf, EncodeString(CHAR(PRINTNAME(TAG(a))),0,0));
				prValueRec(CAR(a), (RINT) 0);
			}
			*ptag = '\0';
			a = CDR(a);
		}
	}
}


/* prValue - print S-expression s */
void prValue(SEXP s, int quote)
{
	tagbuf[0] = '\0';
	prValueRec(s, quote);
}
