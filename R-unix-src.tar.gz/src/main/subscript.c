/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

static SEXP nullSubscript(RINT);
static SEXP logicalSubscript(SEXP, RINT, RINT);
static SEXP integerSubscript(SEXP, RINT, RINT);
static SEXP negativeSubscript(SEXP, RINT, RINT);
static SEXP positiveSubscript(SEXP, RINT, RINT);
static SEXP stringSubscript(SEXP, RINT, SEXP);

/* the first thing we do is check to see if there are any user supplied */
/* NULL's, these result in returning a vector of length 0. */

SEXP makeSubscript(SEXP x, SEXP s)
{
	RINT nx, ns;
	SEXP names, tmp;

	if (isVector(x) || isList(x) || isLanguage(x)) {
		nx = length(x);
		ns = length(s);
		switch (TYPEOF(s)) {
		case NILSXP:
			return allocVector(INTSXP, 0);
		case LGLSXP:
			return logicalSubscript(s, ns, nx);
		case INTSXP:
			return integerSubscript(s, ns, nx);
		case REALSXP:
			PROTECT(tmp = coerceVector(s, INTSXP));
			tmp = integerSubscript(tmp, ns, nx);
			UNPROTECT(1);
			return tmp;
		case STRSXP:
			names = getAttrib(x, NamesSymbol);
			return stringSubscript(s, ns, names);
		case SYMSXP:
			if (s == missingArg)
				return nullSubscript(nx);
		default:
			error("invalid subscript type\n");
		}
	}
	else
		error("subscripting on non-vector\n");
}

/* 
   dim is the dimension (0 to k-1), s is the subscript list, x is the array
   to be subscripted
 */

SEXP arraySubscript(RINT dim, SEXP s, SEXP x)
{
	RINT ns, nd, i;
	SEXP dims, dnames;


	ns = length(s);
/*      if(ns == 0) s = nilValue; */
	dims = getAttrib(x, DimSymbol);
	nd = INTEGER(dims)[dim];

	switch (TYPEOF(s)) {
	case NILSXP:
		return allocVector(INTSXP, 0);
	case LGLSXP:
		return logicalSubscript(s, ns, nd);
	case INTSXP:
		return integerSubscript(s, ns, nd);
	case REALSXP:
		return integerSubscript(coerceVector(s, INTSXP), ns, nd);
	case STRSXP:
		dnames = getAttrib(x, DimNamesSymbol);
		if (dnames == nilValue)
			error("no dimnames attribute for array\n");
		for (i = 0; i < dim; i++)
			dnames = CDR(dnames);
		dnames = CAR(dnames);
		return stringSubscript(s, ns, dnames);
	case SYMSXP:
		if (s == missingArg)
			return nullSubscript(nd);
	default:
		error("invalid subscript type\n");
	}
}

static SEXP nullSubscript(RINT n)
{
	RINT i;
	SEXP index;

	index = allocVector(INTSXP, n);
	for (i = 0; i < n; i++)
		INTEGER(index)[i] = i + 1;
	return index;
}

static SEXP logicalSubscript(SEXP s, RINT ns, RINT nx)
{
	RINT count, i;
	SEXP index;

	if (ns != nx)
		error("invalid subscript type\n");
	count = 0;
	for (i = 0; i < nx; i++)
		if (LOGICAL(s)[i])
			count++;
	index = allocVector(INTSXP, count);
	count = 0;
	for (i = 0; i < nx; i++)
		if (LOGICAL(s)[i]) {
			if (LOGICAL(s)[i] == NA_LOGICAL)
				INTEGER(index)[count++] = NA_INTEGER;
			else
				INTEGER(index)[count++] = i + 1;
		}
	return index;
}

static SEXP integerSubscript(SEXP s, RINT ns, RINT nx)
{
	RINT i, ii, min, max;

	min = 0;
	max = 0;
	for (i = 0; i < ns; i++) {
		ii = INTEGER(s)[i];
		if (ii != NA_INTEGER) {
			if (ii < min)
				min = ii;
			if (ii > max)
				max = ii;
		}
	}

	if (min < -nx || max > nx)
		error("subscript out of bounds\n");

	if (min < 0)
		if (max == 0)
			return negativeSubscript(s, ns, nx);
		else
			error("only 0's may mix with negative subscripts\n");
	else
		return positiveSubscript(s, ns, nx);
}

static SEXP negativeSubscript(SEXP s, RINT ns, RINT nx)
{
	SEXP index;
	RINT i;

	PROTECT(index = allocVector(INTSXP, nx));
	for (i = 0; i < nx; i++)
		INTEGER(index)[i] = 1;
	for (i = 0; i < ns; i++)
		if (INTEGER(s)[i] != 0)
			INTEGER(index)[-INTEGER(s)[i] - 1] = 0;
	s = logicalSubscript(index, nx, nx);
	UNPROTECT(1);
	return s;
}

static SEXP positiveSubscript(SEXP s, RINT ns, RINT nx)
{
	SEXP index;
	RINT i, zct = 0;

	for (i = 0; i < ns; i++)
		if (INTEGER(s)[i] == 0)
			zct++;

	if (zct) {
		index = allocVector(INTSXP, (ns - zct));
		for (i = 0, zct = 0; i < ns; i++)
			if (INTEGER(s)[i] != 0)
				INTEGER(index)[zct++] = INTEGER(s)[i];
		return index;
	}
	else
		return s;
}

SEXP stringSubscript(SEXP s, RINT ns, SEXP names)
{
	SEXP index;
	RINT i, j, nnames;

	PROTECT(names);
	PROTECT(s);

	index = allocVector(INTSXP, ns);
	nnames = length(names);
	for (i = 0; i < ns; i++) {
		INTEGER(index)[i] = nnames + 1;
		for (j = 0; j < nnames; j++)
			if (streql(CHAR(STRING(s)[i]), CHAR(STRING(names)[j]))) {
				INTEGER(index)[i] = j + 1;
				break;
			}
		if (INTEGER(index)[i] == nnames + 1)
			error("subscript out of bounds\n");
	}
	UNPROTECT(2);
	return index;
}
