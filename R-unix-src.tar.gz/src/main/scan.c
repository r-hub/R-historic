/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include <stdlib.h>
#include <fcntl.h>

static FILE *fp;
static int ttyflag;

static SEXP scanVector(SEXPTYPE, RINT, RINT);
static SEXP scanFrame(SEXP, RINT, RINT);
static void scanItem(SEXP, RINT);
static RINT scanLogical(void);
static RINT scanInteger(void);
static RFLOAT scanReal(void);
static SEXP scanString(void);

static int save = 0;

static RINT scanchar(void)
{
	if(save) {
		int c = save;
		save = 0;
		return c;
	}
	return (ttyflag) ? cget() : fgetc(fp);
}

static void unscanchar(int c)
{
	save = c;
	/* ttyflag ? uncget(c) : ungetc(c, fp); */
}

SEXP do_scan(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP file, what, snmax, ans;
	SEXP a, w;
	char *filename;
	SEXPTYPE type;
	RINT i, c, nlines, nmax, nskip;

	checkArity(op, args);
	file = CAR(args);
	what = CADR(args);
	snmax = CADDR(args);
	nskip = asInteger(CADR(CDDR(args)));
	nlines = asInteger(CAR(CDDR(CDDR(args))));
	save = 0;
	if (nskip < 0 || nskip == NA_INTEGER)
		nskip = 0;
	if (nlines < 0 || nlines == NA_INTEGER)
		nlines = 0;

	if (isNull(file))
		filename = NULL;
	else if (isString(file)) {
		filename = CHAR(*STRING(file));
		if (strlen(filename) == 0)
			filename = NULL;
	}
	else
		error("\"scan\" file name required\n");

	if (isNumeric(snmax)) {
		nmax = asInteger(snmax);
		if (nmax < 1)
			error("\"scan\" invalid number of data items %d\n", nmax);
	}
	else
		error("\"scan\" integer number of items required");

	if (filename) {
		ttyflag = 0;
		if ((fp = fopen(filename, "r")) == 0)
			error("\"scan\" can't open file\n");
		for (i = 0; i < nskip; i++)
			while ((c = scanchar()) != '\n' && c != EOF);
	}
	else
		ttyflag = 1;

	switch (TYPEOF(what)) {
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
	case REALSXP:
	case STRSXP:
		ans = scanVector(TYPEOF(what), nmax, nlines);
		break;
	case LISTSXP:
		ans = scanFrame(what, nmax, nlines);
		break;
	default:
		if (!ttyflag)
			fclose(fp);
		error("\"scan\" invalid \"what=\" specified\n");
	}
	if (!ttyflag)
		fclose(fp);
	return ans;
}

static SEXP scanVector(SEXPTYPE type, RINT nmax, RINT nlines)
{
	SEXP ans, bns;
	RINT i, n, nread, nprev;
	int c;

	PROTECT(ans = allocVector(type, nmax));

	nprev = -1;
	n = 0;

	nread = 0;
	if (ttyflag)
		REprintf("1: ");
	while (1) {
		while ((c = scanchar()) == ' ' || c == '\t')
			;
		if (c == EOF) {
			if(ttyflag) ClearerrConsole();
			break;
		}
		else if (c == '\n') {
			nread++;
			if (n == nprev || nread == nlines)
				break;
			if (ttyflag) {
				REprintf("%d: ", n + 1);
				nprev = n;
			}
		}
		else {
			unscanchar(c);
			if (n == nmax) {
				/* enlarge the vector*/
				bns = ans;
				ans = allocVector(type, 2*nmax);
				UNPROTECT(1);
				PROTECT(ans);
				copyVector(ans, bns);
				nmax = 2 * nmax;
			}
			scanItem(ans, n);
			n++;
		}
	}
	REprintf("Read %d items\n", n);

	if (n == 0) {
		UNPROTECT(1);
		return nilValue;
	}
	if (n == nmax) {
		UNPROTECT(1);
		return ans;
	}

	bns = allocVector(type, n);
	switch (type) {
	case LGLSXP:
	case INTSXP:
		for (i = 0; i < n; i++)
			INTEGER(bns)[i] = INTEGER(ans)[i];
		break;
	case REALSXP:
		for (i = 0; i < n; i++)
			REAL(bns)[i] = REAL(ans)[i];
		break;
	case STRSXP:
		for (i = 0; i < n; i++)
			STRING(bns)[i] = STRING(ans)[i];
		break;
	}
	UNPROTECT(1);
	return bns;
}

static SEXP scanFrame(SEXP what, RINT nmax, RINT nlines)
{
	SEXP ans, a, b, w, vnew, vold;
	RINT i, j, n, nc, nread;
	int c;

	nc = length(what);
	PROTECT(ans = allocList(nc));
	a = ans;
	w = what;
	for (i = 0; i < nc; i++) {
		if (!isVector(CAR(w))) {
			if (!ttyflag)
				fclose(fp);
			error("\"scan\" invalid \"what=\" specified\n");
		}
		CAR(a) = allocVector(TYPEOF(CAR(w)), nmax);
		TAG(a) = TAG(w);
		a = CDR(a);
		w = CDR(w);
	}

	n = 0;

	nread = 0;
	if (ttyflag)
		REprintf("1: ");
	while (1) {
		a = ans;
		while ((c = scanchar()) == ' ' || c == '\t')
                        ;
		if (c == EOF) {
                        if(ttyflag) ClearerrConsole();
                        goto done;
                }
		else if (c == '\n') {
			goto done;
		}
		unscanchar(c);

		if (n == nmax) {
			b = ans;
			for (i = 0; i < nc; i++) {
				/* enlarge the vectors */
				vold = CAR(b);
				vnew = allocVector(TYPEOF(vold), 2*nmax);
				copyVector(vnew, vold);
				CAR(b) = vnew;
				b = CDR(b);
			}
			nmax = 2 * nmax;
		}

		for (i = 0; i < nc; i++) {
			while (isspace(c = scanchar()))
				if (c == '\n' || c == EOF) {
					if (!ttyflag)
						fclose(fp);
					error("\"scan\" ragged structure\n");
				}
			unscanchar(c);
			scanItem(CAR(a), n);
			a = CDR(a);
		}
		n++;
		while ((c = scanchar()) != '\n' && c != EOF);
		nread++;
		if (c == EOF || nread == nlines)
			goto done;
		if (c == '\n' && ttyflag)
			REprintf("%d: ", n + 1);
	}
      done:
	if (!ttyflag)
		fclose(fp);
	REprintf("Read %d lines\n", n);

	if (n == nmax) {
		UNPROTECT(1);
		return ans;
	}

	a = ans;
	for (i = 0; i < nc; i++) {
		vold = CAR(a);
		vnew = allocVector(TYPEOF(vold), n);
		switch (TYPEOF(vold)) {
		case LGLSXP:
		case INTSXP:
			for (j = 0; j < n; j++)
				INTEGER(vnew)[j] = INTEGER(vold)[j];
			break;
		case REALSXP:
			for (j = 0; j < n; j++)
				REAL(vnew)[j] = REAL(vold)[j];
			break;
		case STRSXP:
			for (j = 0; j < n; j++)
				STRING(vnew)[j] = STRING(vold)[j];
			break;
		}
		CAR(a) = vnew;
		a = CDR(a);
	}
	UNPROTECT(1);
	return ans;
}

void scanItem(SEXP a, RINT i)
{
	switch (TYPEOF(a)) {
	case LGLSXP:
		LOGICAL(a)[i] = scanLogical();
		break;
	case FACTSXP:
	case ORDSXP:
		error("scanning factors is unimplemented\n");
	case INTSXP:
		INTEGER(a)[i] = scanInteger();
		break;
	case REALSXP:
		REAL(a)[i] = scanReal();
		break;
	case STRSXP:
		STRING(a)[i] = scanString();
		break;
	}
}

RINT scanLogical(void)
{
	char *bufp, buffer[MAXELTSIZE];
	int c, n;

	bufp = buffer;
	while (!isspace(c = scanchar()) && c != EOF)
		*bufp++ = c;
	*bufp = '\0';
	unscanchar(c);

	return StringTrue(buffer);
}

static int NAstring(char *buf)
{
	if (!strcmp("NA", buf) || !strcmp(".", buf))
		return 1;
	else
		return 0;
}

RINT scanInteger(void)
{
	char *bufp, buffer[MAXELTSIZE], *endp;
	int c, n;

	bufp = buffer;
	while (!isspace(c = scanchar()) && c != EOF)
		*bufp++ = c;
	*bufp = '\0';
	unscanchar(c);

	if (NAstring(buffer))
		n = NA_INTEGER;
	else {
		n = strtol(buffer, &endp, 10);
		if (*endp != '\0')
			error("\"scan\" expected an integer got \"%s\"\n", buffer);
	}
	return n;
}

RFLOAT scanReal(void)
{
	char *bufp, buffer[MAXELTSIZE], *endp;
	int c;
	RFLOAT x;

	bufp = buffer;
	while (!isspace(c = scanchar()) && c != EOF)
		*bufp++ = c;
	*bufp = '\0';
	unscanchar(c);

	if (NAstring(buffer))
		x = NA_REAL;
	else {
		x = strtod(buffer, &endp);
		if (*endp != '\0')
			error("\"scan\" expected a real got \"%s\"\n", buffer);
	}
	return x;
}

SEXP scanString()
{
	char *bufp, buffer[MAXELTSIZE];
	int c, k, quote;

	bufp = buffer;
	k = 0;
	if ((c = scanchar()) == '\"' || c == '\'') {
		quote = c;
		k = 0;
		while ((c = scanchar()) != EOF && c != quote) {
			k++;
			if (k >= MAXELTSIZE - 1) {
				if (!ttyflag)
					fclose(fp);
				error("\"scan\" string too long\n");
			}
			if (c == '\\') {
				c = scanchar();
				if (c == 'n')
					c = '\n';
				else if (c == 'r')
					c = '\r';
			}
			*bufp++ = c;
		}
		*bufp = '\0';
	}
	else {
		do {
			k++;
			if (k >= MAXELTSIZE - 1) {
				if (!ttyflag)
					fclose(fp);
				error("\"scan\" string too long\n");
			}
			*bufp++ = c;
		} while (!isspace(c = scanchar()) && c != EOF);
		*bufp = '\0';
		unscanchar(c);
	}

	return mkChar(buffer);
}
