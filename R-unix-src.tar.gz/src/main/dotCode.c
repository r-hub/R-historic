/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#define NIL -1

typedef int (*FUNC) ();

typedef struct {
	char *name;
	FUNC func;
} CFunTabEntry;

#include "dotCode1.h"

static CFunTabEntry CFunTab[] =
{
#include "dotCode2.h"
	NULL, NULL
};

static RINT *HashTable;
static RINT K, M, S;

static int HashCode(char *symbol)
{
	UNSIGNED code = 0;
	char *p = symbol;

	while (*p++)
		code = 8 * code + *p;
	return 3141592653U * code >> S;
}

static int ComputeHashParameters(RINT n)
{
	RINT n2 = 4 * n;
	M = 1;
	K = 0;
	while (M < n2) {
		M *= 2;
		K += 1;
	}
	S = 32 - K;
}

static void HashInstall(RINT offset)
{
	RINT key;

	key = HashCode(CFunTab[offset].name);
	while (HashTable[key] != NIL)
		key = (key + 1) % M;
	HashTable[key] = offset;
}

static FUNC HashLookup(char *symbol)
{
	RINT key = HashCode(symbol);
	while (HashTable[key] != NIL) {
		if (strcmp(symbol, CFunTab[HashTable[key]].name) == 0)
			return CFunTab[HashTable[key]].func;
		else
			key = (key + 1) % M;
	}
	return NULL;
}

/* Initialization */
void InitFunctionHashing()
{
	RINT i, n = sizeof(CFunTab) / sizeof(CFunTabEntry);
	ComputeHashParameters(n);
	HashTable = (RINT *) malloc(M * sizeof(RINT));
	for (i = 0; i < M; i++)
		HashTable[i] = NIL;
	for (i = 0; CFunTab[i].name; i++)
		HashInstall(i);
}


/* Call a C/Fortran function from R */
SEXP do_dotCode(SEXP call, SEXP op, SEXP args, SEXP env)
{
	RFLOAT *cargs[20];
	RINT which;
	RINT nargs = 0;
	FUNC fun;
	SEXP topofargs;
	char buf[128], *p, *q, *vmax;

	vmax = vmaxget();
	which = PRIMVAL(op);
	PROTECT(op = CAR(args));
	PROTECT(args = CDR(args));
	topofargs = args;

	/* duplicate the arg list */
	/* could use reference counting here */

	for (nargs = 0; args != nilValue; nargs++) {
		if (!isVector(CAR(args)))
			errorcall(call, "only vectors allowed as C/Fortran args\n");
		CAR(args) = duplicate(CAR(args));
		args = CDR(args);
	}

	/* set up the calling args to point to the right */
	/* part of the vector heap, NO allocing or duplication */
	/* after this point */

	args = topofargs;
	for (nargs = 0; args != nilValue; nargs++, args = CDR(args)) {
		cargs[nargs] = REAL(CAR(args));
	}


	if (!isString(op))
		errorcall(call, "function name must be a string\n");

	/* make up load symbol & look it up */

	p = CHAR(STRING(op)[0]);
	q = buf;
	while (*q = *p) {
		p++;
		q++;
	}
	if (which)
		*q++ = '_';
	*q = '\0';
	if (!(fun = HashLookup(buf)))
		errorcall(call, "C/Fortran function not in load table\n");

	switch (nargs) {
	case 0:
		/* Silicon graphics C barfs if there is */
		/* no argument to fun */
		fun(0);
		break;
	case 1:
		fun(cargs[0]);
		break;
	case 2:
		fun(cargs[0], cargs[1]);
		break;
	case 3:
		fun(cargs[0], cargs[1], cargs[2]);
		break;
	case 4:
		fun(cargs[0], cargs[1], cargs[2], cargs[3]);
		break;
	case 5:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4]);
		break;
	case 6:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5]);
		break;
	case 7:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6]);
		break;
	case 8:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7]);
		break;
	case 9:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8]);
		break;
	case 10:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9]);
		break;
	case 11:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10]);
		break;
	case 12:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11]);
		break;
	case 13:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12]);
		break;
	case 14:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13]);
		break;
	case 15:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13], cargs[14]);
		break;
	case 16:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13], cargs[14], cargs[15]);
		break;
	case 17:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13], cargs[14], cargs[15], cargs[16]);
		break;
	case 18:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13], cargs[14], cargs[15], cargs[16], cargs[17]);
		break;
	case 19:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13], cargs[14], cargs[15], cargs[16], cargs[17], cargs[18]);
		break;
	case 20:
		fun(cargs[0], cargs[1], cargs[2], cargs[3], cargs[4], cargs[5], cargs[6], cargs[7], cargs[8], cargs[9], cargs[10], cargs[11], cargs[12], cargs[13], cargs[14], cargs[15], cargs[16], cargs[17], cargs[18], cargs[19]);
		break;
	default:
		errorcall(call, "too many arguments, sorry\n");
	}
	UNPROTECT(2);
	vmaxset(vmax);
	return (topofargs);
}
