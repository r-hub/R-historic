/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <signal.h>
#include <stdarg.h>
#include <limits.h>
#include <float.h>
#include "Defn.h"
#include "Graphics.h"

/*
 * Heap and Pointer Protection Stack Size
 *
 * STACKSIZE = Size of the pointer protection stack (way too big)
 * NSIZE     = Number of cons cells
 * VSTACK    = Vector heap size in bytes
 *
 * These comiled in values are minima and it should be possible
 * to override them in a platform dependent way.
 */

#define STACKSIZE	10000L
#define NSIZE		72000L
#define VSIZE		500000L

int R_nsize = NSIZE;
int R_vsize = VSIZE;
int R_ssize = STACKSIZE;

/*
 * Global Variables
 *
 * Each of these sould be prefixed by R_.
 * One day ...
 */

SEXP globalEnv;
SEXP *argStack;
RINT stacksize = STACKSIZE;
RINT stacktop = 0;
RINT nsize;
RINT vsize;
RINT visible;
SEXPREC *nheap;
VECREC *vheap;
SEXP freeSEXP;
SEXP currentExp;
SEXP returnedValue;
SEXP *SYMBOL_TABLE;
jmp_buf stack_state;
RCONTEXT toplevel;
RCONTEXT *toplevelcontext;
RCONTEXT *globalcontext;
FILE *Rinputfile = NULL;
FILE *Rconsolefile = NULL;
FILE *Routputfile = NULL;
FILE *Rsinkfile = NULL;

FILE *yyin;
int browselevel;
VECREC *R_vtop;
long R_nvcell;
long R_collected;
RINT R_Console;

SEXP nilValue;
SEXP trueValue;
SEXP falseValue;
SEXP unboundValue;
SEXP missingArg;
SEXP commentSxp;
SEXP ParseText;

RINT ParseCnt;
RINT ParseError = 0;
SEXP ClassSymbol;
SEXP DimSymbol;
SEXP DotsSymbol;
SEXP NamesSymbol;
SEXP DimNamesSymbol;
SEXP LevelsSymbol;
SEXP TspSymbol;
SEXP ModeSymbol;
SEXP SeedsSymbol;
SEXP DropSymbol;
SEXP NarmSymbol;
SEXP DollarSymbol;
SEXP BracketSymbol;
SEXP Bracket2Symbol;

RINT max_int;
RFLOAT max_float;
RINT na_logical;
RINT na_integer;
RINT na_factor;
RFLOAT na_real;
SEXP na_string;

char R_ImageName[256];
int R_Unnamed;
int R_DirtyImage;
int R_Init = 0;

	/* Options */

char options_prompt[30];
char options_editor[30];
char options_continuation[30];
RINT options_expressions = 100;
RINT options_width = 80;
RINT options_digits = 7;

void InitGlobalEnv()
{
	globalEnv = emptyEnv();
}

void InitOptions()
{
	strcpy((char *) &options_prompt, "> ");
	strcpy((char *) &options_editor, "vi ");
	strcpy((char *) &options_continuation, "+ ");
}

int evaldepth = 0;
int evalcnt = 0;

/*
 * Main Loop:
 *
 * It is assumed that at this point that operating system specific
 * tasks (dialog window creation etc) have been performed.  We can
 * now print a greeting, run the .First function and then enter the
 * read-eval-print loop.
 */

mainloop()
{
	char *item;
	SEXP cmd;
	int pflag;

	/* We always start interactive */
	R_Console = 1;

	Rprintf("\nR Alpha-Test Version, Copyright (C) 1995 Robert Gentleman and Ross Ihaka\n\n");
	Rprintf("R is free software and comes with ABSOLUTELY NO WARRANTY.\n");
	Rprintf("You are welcome to redistribute it under certain conditions.\n");
	Rprintf("Type `license()' for details.\n\n");


	InitOptions();
	InitMemory(R_nsize, R_vsize);
	InitNames();
	InitGlobalEnv();
	InitFunctionHashing();
	InitEd();
	InitArithmetic();
	R_Unnamed = 1;
	R_DirtyImage = 0;

	/* initialize global context for error handling */
	toplevel.nextcontext = NULL;
	toplevel.cstacktop = 0;
	toplevel.callflag = 0;

	/* The following section of code is where loading */
	/* of the initial Image happens.  Any errors which */
	/* If this the call to restore_image will die in */
	/* halfway graceful manner */

	R_Init = 0;
	setjmp(toplevel.cjmpbuf);
	if(R_Init == 0) {
		globalcontext = toplevelcontext = &toplevel;
		/* Initialized at declaration
		   or over-ridden in system dependent code.
		Rinputfile = NULL;
		Routputfile = NULL;
		*/
		R_Init = 1;
		R_StartUp();
	}

	/* On initial entry to R, this code runs the .First */
	/* function.  It would be relatively easy to run */
	/* .First after each restore by moving the setjmp */
	/* call below to here and tweeking the value of R_Init */
	/* in the restoration code */

	R_Init = 0;
	setjmp(toplevel.cjmpbuf);
	globalcontext = toplevelcontext = &toplevel;
	if(R_Init == 0) {
		R_Init = 1;
		if (R_Unnamed) {
			strcpy(R_ImageName, "R-Image");
		}
		PROTECT(cmd = install(".First"));
		currentExp = findVar(cmd, globalEnv);
		if (currentExp != unboundValue && TYPEOF(currentExp) == CLOSXP) {
			PROTECT(currentExp = lang1(cmd));
			currentExp = eval(currentExp, globalEnv);
			UNPROTECT(1);
		}
		UNPROTECT(1);
	}

	/* This is the business end of the read-eval-print */
	/* loop.  On image restoration the section above is */
	/* excuted, but usually it is just from here down. */

	setjmp(toplevel.cjmpbuf);
	globalcontext = toplevelcontext = &toplevel;
	signal(SIGINT, onintr);
	ResetConsole();
	pflag = 1;
	browselevel = 0;
	commentSxp = CONS(nilValue, nilValue);
	CAR(commentSxp) = commentSxp;

	for (;;) {
	      again:stacktop = 0;
		if ((pflag == 1 || pflag == 2 || pflag == 3) && R_Console == 1)
			yyprompt((char*) &options_prompt);
		currentExp = NULL;
		pflag = yyparse();
		if ((pflag == 1) || (pflag == 2))
			goto again;
		if (pflag == 0) {
			if (R_Console == 1)
				goto finished;
			fclose(yyin);
			ResetConsole();
#ifdef BISON
			yyrestart(yyin);
#endif
			pflag = 1;
			goto again;
		}
		if (currentExp) {
			evaldepth = 0;
			PROTECT(currentExp);
			R_Busy(1);
			currentExp = eval(currentExp, globalEnv);
			UNPROTECT(1);
			if (visible)
				prValue(currentExp, '"');
		}
	}
finished:
	PROTECT(cmd = install(".Last"));
	currentExp = findVar(cmd, globalEnv);
	if (currentExp != unboundValue && TYPEOF(currentExp) == CLOSXP) {
		PROTECT(currentExp = lang1(cmd));
		currentExp = eval(currentExp, globalEnv);
		UNPROTECT(1);
	}
	UNPROTECT(1);
	CleanUp();
}

SEXP do_browser(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RCONTEXT *savetoplevelcontext;
	RCONTEXT *saveglobalcontext;
	RCONTEXT thiscontext;
	int savestack;
	int savebrowselevel;
	int saveevaldepth;
	int pflag = 1;
	SEXP topExp;

	savebrowselevel = browselevel + 1;

	/* save evaluator state information */
	savestack = stacktop;
	PROTECT(topExp = currentExp);
	savetoplevelcontext = toplevelcontext;
	saveglobalcontext = globalcontext;
	saveevaldepth = evaldepth;

	/* new context */
	thiscontext.nextcontext = NULL;
	thiscontext.cstacktop = 0;
	thiscontext.callflag = 0;
	thiscontext.cend = NULL;
	setjmp(thiscontext.cjmpbuf);
	globalcontext = toplevelcontext = &thiscontext;
	browselevel = savebrowselevel;

	for (;;) {
	      again:stacktop = savestack;
		if ((pflag == 1 || pflag == 2 || pflag == 3) && R_Console == 1)
			yyprompt("Browse[%d]> ", browselevel);
		currentExp = NULL;
		pflag = yyparse();
		if ((pflag == 1) || (pflag == 2))
			goto again;
		if (pflag == 0) {
			if (R_Console == 1) {
				ClearerrConsole();
				Rprintf("\n");
				goto finished;
			}
			fclose(yyin);
			ResetConsole();
#ifdef BISON
			yyrestart(yyin);
#endif
			pflag = 1;
			goto again;
		}
		if (currentExp) {
			evaldepth = saveevaldepth;
			PROTECT(currentExp);
			R_Busy(1);
			currentExp = eval(currentExp, rho);
			UNPROTECT(1);
			if (visible)
				prValue(currentExp, '"');
		}
	}
finished:
	UNPROTECT(1);
	stacktop = savestack;
	currentExp = topExp;
	toplevelcontext = savetoplevelcontext;
	globalcontext = saveglobalcontext;
	evaldepth = saveevaldepth;
	browselevel--;
	visible = 0;
	return nilValue;
}

SEXP do_quit(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	if(browselevel) {
		warning("can't quit from browser\n");
		visible = 0;
		return nilValue;
	}
	CleanUp();
	exit(0);
}

yywrap()
{
	return feof(yyin);
}

void yyprompt(char *format,...)
{
	va_list(ap);
	if (DevInit)
		DevHold();
	va_start(ap, format);
	REvprintf(format, ap);
	va_end(ap);
	fflush(stdout);
	R_Busy(0);
}
