/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

static void vectorAssign(SEXP, SEXP, SEXP);
static void matrixAssign(SEXP, SEXP, SEXP);
static void arrayAssign(SEXP, SEXP, SEXP);
static void typefix(SEXP);

/* x is the vector that is going to be assigned into, y is the vector */
/* that is going to provide the new values and s is the vector of */
/* subscripts that are going to be replaced. */

/* on entry x (CAR(args)) has been evaluated, the remainder of args has */
/* not. */

SEXP do_subassign(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP x, s, y;
	RINT mode;

	CADR(args) = parseSubargs("[<-", CDR(args), rho);
	PROTECT(args);
	typefix(args);

	/* We can't modify a named object */
	if (NAMED(CAR(args)) == 2)
		CAR(args) = duplicate(CAR(args));
	x = CAR(args);
	s = CADR(args);
	y = CADDR(args);

	if ((!isVector(x) && !isList(x)) && (!isVector(y) && !isList(y)))
		error("type error in subset assignment\n");
	if (isList(x) && length(s) > 1)
		error("wrong number of subscripts to list assign\n");

	switch (length(s)) {
	case 0:
		break;
	case 1:
		vectorAssign(x, CAR(s), y);
		break;
	case 2:
		matrixAssign(x, s, y);
		break;
	default:
		arrayAssign(x, s, y);
		break;
	}
	UNPROTECT(1);
	visible = 0;
	NAMED(x) = 0;
	return x;
}

/* subassign2 is for [[<- assignment, it should be fast */
/* args[1] = object being subscripted */
/* args[2] = list of subscripts */
/* args[3] = replacement values */
SEXP do_subassign2(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP x, s, y, dims, names;
	RINT len, k, i, tmp, index[MAXDIM];

	CADR(args) = parseSubargs("[[<-", CDR(args), rho);
	PROTECT(args);
	typefix(args);
	PROTECT(args);

	if (NAMED(CAR(args)) == 2)
		CAR(args) = duplicate(CAR(args));

	x = CAR(args);
	s = CADR(args);
	y = CADDR(args);

	/*
	   if( !isList(CAR(args)) && LENGTH(CADR(args)) > 1 )
	   error("[[]]<- attempt to replace more than 1 item\n");
	 */

	if ((!isVector(x) && !isList(x)) && (!isVector(y) && !isList(y)))
		error("type error in subset assignment\n");
	if (isList(x) && length(s) > 1)
		error("wrong number of subscripts to list assign\n");


	if (isList(x)) {
		k = get1index(CAR(s), getAttrib(x, NamesSymbol));
		if (k < 0 || k >= length(x))
			error("[[]] subscript out of bounds\n");
		CAR(nthcdr(x, k)) = y;
		UNPROTECT(2);
		visible = 0;
		NAMED(x) = 0;
		return x;
	}

	if (length(y) > 1)
		error("number of elements supplied larger than number of elements to replace\n");

	PROTECT(dims = getAttrib(x, DimSymbol));
	k = length(dims);

	if (!isArray(x)) {
		tmp = get1index(CAR(s), getAttrib(x, NamesSymbol));
		if (tmp < 0 || tmp >= LENGTH(x))
			error("[[]] subscript out of bounds\n");
	}
	else {
		if (k != length(s))
			error("[[]] improper number of subscripts\n");
		names = getAttrib(x, DimNamesSymbol);
		for (i = 0; i < k; i++) {
			index[i] = get1index(CAR(s), isList(names) ? CAR(names) : nilValue);
			if (isList(names))
				names = CDR(names);
			s = CDR(s);
			if (index[i] < 0 || index[i] >= INTEGER(dims)[i])
				error("[[]] subscript out of bounds\n");
		}
		tmp = 0;
		for (i = (k - 1); i > 0; i--)
			tmp = (tmp + index[i]) * INTEGER(dims)[i - 1];
		tmp += index[0];
	}
	switch (TYPEOF(x)) {
	case INTSXP:
		INTEGER(x)[tmp] = INTEGER(y)[0];
		break;
	case REALSXP:
		REAL(x)[tmp] = REAL(y)[0];
		break;
	case STRSXP:
		STRING(x)[tmp] = STRING(y)[0];
		break;
	case FACTSXP:
	case ORDSXP:
		FACTOR(x)[tmp] = FACTOR(y)[0];
		break;
	case LGLSXP:
		LOGICAL(x)[tmp] = LOGICAL(y)[0];
		break;
	default:
		abort();
	}
	UNPROTECT(3);
	visible = 0;
	NAMED(x) = 0;
	return x;
}

SEXP do_subassign3(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, nlist, val, t;

	/* checkArity(op, args); */

	x = CAR(args);

/* NEED TO CHECK - ALWAYS EVALUATE ?? */
	if (isSymbol(x))
		x = eval(x, env);

/* NEED TO CHECK HOW NECESSARY THIS NEXT LINE IS */

	if (!isList(x))
		error("$ used on non-list\n");

	val = CADDR(args);
	PROTECT(val);

	nlist = CAR(CADR(args));
	if (isString(nlist))
		nlist = install(CHAR(STRING(nlist)[0]));

	for (t = x; t != nilValue; t = CDR(t))
		if (TAG(t) == nlist) {
			CAR(t) = val;
			break;
		}
		else if (CDR(t) == nilValue) {
			SETCDR(t, allocSExp(LISTSXP));
			TAG(CDR(t)) = nlist;
			CADR(t) = val;
			break;
		}
	UNPROTECT(1);
	NAMED(x) = 0;
	return x;
}

static void vectorAssign(SEXP x, SEXP s, SEXP y)
{
	RINT i, ii, n, nx, ny;
	SEXP index;

	nx = length(x);
	ny = length(y);
	index = makeSubscript(x, s);
	n = length(index);

	if (n > 0 && ny == 0)
		error("nothing to replace with\n");

	if (n > 0 && n % ny)
		error("no of items to replace is not a multiple of replacement length\n");

	for (i = 0; i < n; i++) {
		ii = INTEGER(index)[i];
		if(ii == NA_INTEGER) continue;
		ii = ii - 1;
		switch (TYPEOF(x)) {
		case LGLSXP:
		case FACTSXP:	/* check factor bounds */
		case ORDSXP:
		case INTSXP:
			INTEGER(x)[ii] = INTEGER(y)[i % ny];
			break;
		case REALSXP:
			REAL(x)[ii] = REAL(y)[i % ny];
			break;
		case STRSXP:
			STRING(x)[ii] = STRING(y)[i % ny];
			break;
		case LISTSXP:
			switch (TYPEOF(y)) {
			case INTSXP:
			case LGLSXP:
			case FACTSXP:
			case ORDSXP:
				CAR(nthcdr(x, ii)) = allocVector(INTSXP, 1);
				INTEGER(CAR(nthcdr(x, ii)))[0] = INTEGER(y)[i % ny];
				break;
			case REALSXP:
				CAR(nthcdr(x, ii)) = allocVector(REALSXP, 1);
				REAL(CAR(nthcdr(x, ii)))[0] = REAL(y)[i % ny];
				break;
			case STRSXP:
				CAR(nthcdr(x, ii)) = allocVector(STRSXP, 1);
				STRING(CAR(nthcdr(x, ii)))[0] = STRING(y)[i % ny];
				break;
			case LISTSXP:
				CAR(nthcdr(x, ii)) = CAR(nthcdr(y, (RINT) (i % ny)));
				break;
			}
		}
	}
}

static void matrixAssign(SEXP x, SEXP s, SEXP y)
{
	RINT i, j, ii, jj, ij, k;
	RINT nr, nc, ny;
	RINT nrs, ncs;
	SEXP sr, sc;

	if (!isMatrix(x))
		error("incorrect number of subscripts on array\n");

	nr = nrows(x);
	nc = ncols(x);
	ny = LENGTH(y);

	/* s is protected */
	/* no GC problems here */

	sr = CAR(s) = arraySubscript(0L, CAR(s), x);
	sc = CADR(s) = arraySubscript(1L, CADR(s), x);
	nrs = LENGTH(sr);
	ncs = LENGTH(sc);

	if ((length(sr) * length(sc)) % length(y))
		error("no of items to replace is not a multiple of replacement length\n");

	k = 0;
	for (j = 0; j < ncs; j++) {
		jj = INTEGER(sc)[j];
		if(jj == NA_INTEGER) continue;
		jj = jj - 1;
		for (i = 0; i < nrs; i++) {
			ii = INTEGER(sr)[i];
			if(ii == NA_INTEGER) continue;
			ii = ii - 1;
			ij = ii + jj * nr;
			switch (TYPEOF(x)) {
			case LGLSXP:
			case INTSXP:
			case FACTSXP:
			case ORDSXP:
				INTEGER(x)[ij] = INTEGER(y)[k];
				break;
			case REALSXP:
				REAL(x)[ij] = REAL(y)[k];
				break;
			case STRSXP:
				STRING(x)[ij] = STRING(y)[k];
				break;
			}
			k = (k + 1) % ny;
		}
	}
}

static void arrayAssign(SEXP x, SEXP s, SEXP y)
{
	RINT i, j, ii, jj, k, mode, n, ny;
	RINT *subs[MAXDIM];
	RINT index[MAXDIM], bound[MAXDIM], offset[MAXDIM];
	SEXP dims, tmp;

	mode = TYPEOF(x);
	PROTECT(dims = getAttrib(x, DimSymbol));
	if (dims == nilValue || (k = LENGTH(dims)) != length(s))
		error("incorrect number of subscripts\n");
	if (k > MAXDIM)
		error("too many subscripts on array\n");

	ny = LENGTH(y);

	/* s is protected */
	/* no GC problems here */

	tmp = s;
	for (i = 0; i < k; i++) {
		CAR(tmp) = arraySubscript(i, CAR(tmp), x);
		tmp = CDR(tmp);
	}

	n = 1;
	tmp = s;
	for (i = 0; i < k; i++) {
		index[i] = 0;
		subs[i] = INTEGER(CAR(tmp));
		bound[i] = LENGTH(CAR(tmp));
		n *= bound[i];
		tmp = CDR(tmp);
	}

	if (n % length(y))
		error("no of elements to replace is not a multiple of replacement length\n");

	offset[0] = 1;
	for (i = 1; i < k; i++)
		offset[i] = offset[i - 1] * INTEGER(dims)[i - 1];

	for (i = 0; i < n; i++) {
		ii = 0;
		for (j = 0; j < k; j++) {
			jj = subs[j][index[j]];
			if(jj == NA_INTEGER) goto next_i;
			ii += (jj - 1) * offset[j];
		}

	      assignLoop:
		switch (mode) {
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			INTEGER(x)[ii] = INTEGER(y)[i % ny];
			break;
		case REALSXP:
			REAL(x)[ii] = REAL(y)[i % ny];
			break;
		case STRSXP:
			STRING(x)[ii] = STRING(x)[i % ny];
			break;
		}
		if (n > 1) {
			j = 0;
			while (++index[j] >= bound[j]) {
				index[j] = 0;
				j = ++j % k;
			}
		}
	next_i:
		;
	}
	UNPROTECT(1);
}

static void typefix(SEXP args)
{
	RINT mode;

	if (isVector(CAR(args))) {
		if (isList(CADDR(args)))
			if (mode = isVectorizable(CADDR(args)))
				CADDR(args) = coerceList(CADDR(args), mode);
			else
				error("wrong type for subset\n");
		if (TYPEOF(CAR(args)) < TYPEOF(CADDR(args)))
			CAR(args) = coerceVector(CAR(args), TYPEOF(CADDR(args)));
		else
			CADDR(args) = coerceVector(CADDR(args), TYPEOF(CAR(args)));
	}
}
