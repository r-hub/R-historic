/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* Model formula manipulation */
/* Can you say ``recurse your brains out''; I knew you could. */
/* -- Mr Ro(ss)gers */

#include "Defn.h"

#define WORDSIZE (8*sizeof(RINT))

static SEXP tildeSymbol = NULL;
static SEXP plusSymbol = NULL;
static SEXP minusSymbol = NULL;
static SEXP timesSymbol = NULL;
static SEXP slashSymbol = NULL;
static SEXP colonSymbol = NULL;
static SEXP identSymbol = NULL;
static SEXP parenSymbol = NULL;
static SEXP inSymbol = NULL;


static int intercept;		/* intercept term in the model */
static int response;		/* response term in the model */
static int nvar;		/* Number of variables in the formula */
static int nwords;		/* # or words (RINTs) to code a term */
static int nterm;		/* # of model terms */
static SEXP varlist;		/* variables in the model */



/* matchVar - Determine whether two ``variables'' are identical. */
/* Expressions are identical if they have the same list structure */
/* and their atoms are identical.  This is just EQUAL from lisp. */

static int matchVar(SEXP var1, SEXP var2)
{
	/* Non-atomic objects - compare CAR & CDR */
	if ((isList(var1) || isLanguage(var1))
	    || (isList(var2) || isList(var1)))
		return matchVar(CAR(var1), CAR(var2));

	/* Symbols */
	if (isSymbol(var1) && isSymbol(var2))
		return (var1 == var2);

	/* Literal Numerics */
	if (isNumeric(var1) && isNumeric(var2))
		return (asReal(var1) == asReal(var2));

	/* Nothing else matches */
	return 0;
}


/* installVar - Locate a ``variable'' in the model variable list. */
/* Add it to the list if not found. */

static int installVar(SEXP var)
{
	SEXP v;
	int index;

	/* Check that variable is legitimate */
	if (!isSymbol(var) && !isLanguage(var))
		error("invalid term in model formula\n");
	if (isNull(var))
		error("invalid null term in model formula\n");

	/* install it */
	index = 0;
	for (v = varlist; CDR(v) != nilValue; v = CDR(v)) {
		index++;
		if (matchVar(var, CADR(v)))
			return index;
	}
	CDR(v) = CONS(var, nilValue);
	return index + 1;
}


/* extractVars - Recursively extract the variables in a model formula. */
/* calls installVar to do the installation. */

static void extractVars(SEXP formula, int checkonly)
{
	if (isNull(formula))
		return;
	if (isSymbol(formula)) {
		if (!checkonly)
			installVar(formula);
		return;
	}
	if (isLanguage(formula)) {
		if (CAR(formula) == tildeSymbol) {
			if (response)
				error("invalid model formula\n");
			response = 1;
			installVar(CADR(formula));
			extractVars(CADDR(formula), 0);
			return;
		}
		if (CAR(formula) == plusSymbol) {
			extractVars(CADR(formula), 0);
			extractVars(CADDR(formula), 0);
			return;
		}
		if (CAR(formula) == colonSymbol) {
			extractVars(CADR(formula), 0);
			extractVars(CADDR(formula), 0);
			return;
		}
		if (CAR(formula) == timesSymbol) {
			extractVars(CADR(formula), 0);
			extractVars(CADDR(formula), 0);
			return;
		}
		if (CAR(formula) == inSymbol) {
			extractVars(CADR(formula), 0);
			extractVars(CADDR(formula), 0);
			return;
		}
		if (CAR(formula) == slashSymbol) {
			extractVars(CADR(formula), 0);
			extractVars(CADDR(formula), 0);
			return;
		}
		if (CAR(formula) == minusSymbol) {
			extractVars(CADR(formula), 0);
			extractVars(CADDR(formula), 1);
			return;
		}
		if (CAR(formula) == parenSymbol) {
			extractVars(CADR(formula), 0);
			return;
		}
		installVar(formula);
		return;
	}
	error("invalid model formula\n");
}


/* allocTerm - allocate an integer array for bit string */
/* representation of a modl term */

static SEXP allocTerm()
{
	int i;
	SEXP term = allocVector(INTSXP, nwords);
	for (i = 0; i < nwords; i++)
		INTEGER(term)[i] = 0;
	return term;
}


/* setBit - set bit ``whichBit'' to value ``value'' in the */
/* bit string representation of a term */

static void setBit(SEXP term, int whichBit, int value)
{
	int word, offset;
	word = (whichBit - 1) / WORDSIZE;
	offset = (whichBit - 1) % WORDSIZE;
	if (value)
		((unsigned *) INTEGER(term))[word] |= ((unsigned) 1 << offset);
	else
		((unsigned *) INTEGER(term))[word] &= ~((unsigned) 1 << offset);
}


/* getBit - set bit ``whichBit'' from in the bit string */
/* representation of a term */

static int getBit(SEXP term, int whichBit)
{
	int word, offset;
	word = (whichBit - 1) / WORDSIZE;
	offset = (whichBit - 1) % WORDSIZE;
	return ((((unsigned *) INTEGER(term))[word]) >> offset) & 1;
}


/* orBits - compute a new (bit string) term which contains */
/* the logcial Or of the bits in ``term1'' and ``term2''. */

static SEXP orBits(SEXP term1, SEXP term2)
{
	SEXP term;
	int i;

	term = allocTerm();
	for (i = 0; i < nwords; i++)
		INTEGER(term)[i] = INTEGER(term1)[i] | INTEGER(term2)[i];
	return term;
}

static int bitCount(SEXP term)
{
	int i, offset, sum, word;

	sum = 0;
	for (i = 2; i <= nvar; i++)
		sum += getBit(term, i);
	return sum;
}


/* termEqual - test two (bit string) terms for equality. */

static int termEqual(SEXP term1, SEXP term2)
{
	int i, val;
	val = 1;
	for (i = 0; i < nwords; i++)
		val = val && (INTEGER(term1)[i] == INTEGER(term2)[i]);
	return val;
}


/* strip term - strip the specified term from the given list. */
/* This mutates the list */

static SEXP stripTerm(SEXP term, SEXP list)
{
	SEXP tail;

	if (list == nilValue)
		return list;
	tail = stripTerm(term, CDR(list));
	if (termEqual(term, CAR(list)))
		return tail;
	CDR(list) = tail;
	return list;
}


/* trimRepeats - removes duplicates of (bit string) terms in */
/* a model formula by repeated use of ``stripTerm''. */

static SEXP trimRepeats(SEXP list)
{
	if (list == nilValue)
		return nilValue;
	CDR(list) = trimRepeats(stripTerm(CAR(list), CDR(list)));
	return list;
}


/* Model Formula Manipulation */
/* These functions take a numerically code a formula and fully expand it */

static SEXP encodeVars(SEXP);


/* plusTerms - expands ``left'' and ``right'' and concatenates */
/* their terms (removing duplicates). */

static SEXP plusTerms(SEXP left, SEXP right)
{
	PROTECT(left = encodeVars(left));
	right = encodeVars(right);
	UNPROTECT(1);
	return trimRepeats(listAppend(left, right));
}


/* interactTerms - expands ``left'' and ``right'' and forms */
/* a new list of terms containing the bitwise Or of each term */
/* in ``left'' with each term in ``right''. */

static SEXP interactTerms(SEXP left, SEXP right)
{
	SEXP term, l, r, t;
	PROTECT(left = encodeVars(left));
	PROTECT(right = encodeVars(right));
	PROTECT(term = allocList(length(left) * length(right)));
	t = term;
	for (l = left; l != nilValue; l = CDR(l))
		for (r = right; r != nilValue; r = CDR(r)) {
			CAR(t) = orBits(CAR(l), CAR(r));
			t = CDR(t);
		}
	UNPROTECT(3);
	return trimRepeats(term);
}


/* crossTerms - expands ``left'' and ``right'' and forms the */
/* ``cross'' of the list of terms.  Duplicates are removed. */

static SEXP crossTerms(SEXP left, SEXP right)
{
	SEXP term, l, r, t;
	PROTECT(left = encodeVars(left));
	PROTECT(right = encodeVars(right));
	PROTECT(term = allocList(length(left) * length(right)));
	t = term;
	for (l = left; l != nilValue; l = CDR(l))
		for (r = right; r != nilValue; r = CDR(r)) {
			CAR(t) = orBits(CAR(l), CAR(r));
			t = CDR(t);
		}
	UNPROTECT(3);
	listAppend(right, term);
	listAppend(left, right);
	return trimRepeats(left);
}

/* inTerms - expands ``left'' and ``right'' and forms the */
/* ``nest'' of the the left in the interaction of the right */

static SEXP inTerms(SEXP left, SEXP right)
{
	SEXP term, t;
	int i;
	PROTECT(left = encodeVars(left));
	PROTECT(right = encodeVars(right));
	PROTECT(term = allocTerm());
	/* Bitwise or of all terms on right */
	for (t = right; t != nilValue; t = CDR(t)) {
		for (i = 0; i < nwords; i++)
			INTEGER(term)[i] = INTEGER(term)[i] | INTEGER(CAR(t))[i];
	}
	/* Now bitwise or with each term on the left */
	for (t = left; t != nilValue; t = CDR(t))
		for (i = 0; i < nwords; i++)
			INTEGER(CAR(t))[i] = INTEGER(term)[i] | INTEGER(CAR(t))[i];
	UNPROTECT(3);
	return trimRepeats(left);
}

/* nestTerms - expands ``left'' and ``right'' and forms the */
/* ``nest'' of the list of terms.  Duplicates are removed. */

static SEXP nestTerms(SEXP left, SEXP right)
{
	SEXP term, t;
	int i;
	PROTECT(left = encodeVars(left));
	PROTECT(right = encodeVars(right));
	PROTECT(term = allocTerm());
	/* Bitwise or of all terms on left */
	for (t = left; t != nilValue; t = CDR(t)) {
		for (i = 0; i < nwords; i++)
			INTEGER(term)[i] = INTEGER(term)[i] | INTEGER(CAR(t))[i];
	}
	/* Now bitwise or with each term on the right */
	for (t = right; t != nilValue; t = CDR(t))
		for (i = 0; i < nwords; i++)
			INTEGER(CAR(t))[i] = INTEGER(term)[i] | INTEGER(CAR(t))[i];
	UNPROTECT(3);
	listAppend(left, right);
	return trimRepeats(left);
}


/* deleteTerms - expands ``left'' and ``right'' and then removes */
/* any terms which appear in ``right'' from ``left''. */

static SEXP deleteTerms(SEXP left, SEXP right)
{
	SEXP t;
	PROTECT(left = encodeVars(left));
	PROTECT(right = encodeVars(right));
	for (t = right; t != nilValue; t = CDR(t))
		left = stripTerm(CAR(t), left);
	return left;
}


/* encodeVars - model expansion and bit string encoding. */
/* This is the real workhorse of model expansion. */

static SEXP encodeVars(SEXP formula)
{
	SEXP term, left, right, t, l, r;
	int code;

	if (isNull(formula))
		return nilValue;

	if (isSymbol(formula)) {
		term = allocTerm();
		setBit(term, installVar(formula), 1);
		return CONS(term, nilValue);
	}
	if (isLanguage(formula)) {
		if (CAR(formula) == tildeSymbol) {
			encodeVars(CADDR(formula));
			return;
		}
		if (CAR(formula) == plusSymbol) {
			return plusTerms(CADR(formula), CADDR(formula));
		}
		if (CAR(formula) == colonSymbol) {
			return interactTerms(CADR(formula), CADDR(formula));
		}
		if (CAR(formula) == timesSymbol) {
			return crossTerms(CADR(formula), CADDR(formula));
		}
		if (CAR(formula) == inSymbol) {
			return inTerms(CADR(formula), CADDR(formula));
		}
		if (CAR(formula) == slashSymbol) {
			return nestTerms(CADR(formula), CADDR(formula));
		}
		if (CAR(formula) == minusSymbol) {
			return deleteTerms(CADR(formula), CADDR(formula));
		}
		if (CAR(formula) == parenSymbol) {
			encodeVars(CADR(formula));
			return;
		}
		term = allocTerm();
		setBit(term, installVar(formula), 1);
		return CONS(term, nilValue);
	}
}


/* termCode - decide on the encoding of a model term. */
/* Returns 1 if variable ``whichBit'' in ``thisTerm'' is to be */
/* encoded by contrasts and 2 if it is to be encoded by dummy variables. */
/* This is decided using the heuristric of Chambers and Heiberger */
/* described in Statistical Models in S, Page 38. */

static int termCode(SEXP termlist, SEXP thisterm, int whichbit, SEXP term)
{
	SEXP t, s;
	int allzero, i;

	for (i = 0; i < nwords; i++)
		INTEGER(term)[i] = INTEGER(CAR(thisterm))[i];

	/* Eliminate factor ``whichbit'' */
	setBit(term, whichbit, 0);

	/* Search preceding terms for a match */
	/* Zero is a possibility - it is a special case */

	allzero = 1;
	for (i = 0; i < nwords; i++) {
		if (INTEGER(term)[i]) {
			allzero = 0;
			break;
		}
	}
	if (allzero)
		return 1;

	for (t = termlist; t != thisterm; t = CDR(t)) {
		allzero = 1;
		for (i = 0; i < nwords; i++) {
			if ((~(INTEGER(CAR(t))[i])) & INTEGER(term)[i])
				allzero = 0;
		}
		if (allzero)
			return 1;
	}
	return 2;
}

static void sortTerms(SEXP * x, RINT n)
{
	RINT i, j, h;
	SEXP xtmp;

	h = 1;
	do {
		h = 3 * h + 1;
	}
	while (h <= n);

	do {
		h = h / 3;
		for (i = h; i < n; i++) {
			xtmp = x[i];
			j = i;
			while (LEVELS(x[j - h]) > LEVELS(xtmp)) {
				x[j] = x[j - h];
				j = j - h;
				if (j < h)
					goto end;
			}
		      end:x[j] = xtmp;
		}
	} while (h != 1);
}


/* Internal code for the ``terms'' function */
/* We do not have the S object system (to battle against) */
/* so the results are returned as a list */

SEXP do_terms(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP a, ans, v, pattern, formula, varnames, term, termlabs;
	int i, l, n;

	checkArity(op, args);

	/* Always fetch these values rather than trying */
	/* to remember them between calls.  The overhead */
	/* is minimal and we don't have to worry about */
	/* intervening dump/restore problems */

	tildeSymbol = install("~");
	plusSymbol  = install("+");
	minusSymbol = install("-");
	timesSymbol = install("*");
	slashSymbol = install("/");
	colonSymbol = install(":");
	identSymbol = install("I");
	parenSymbol = install("(");
	inSymbol = install("%in%");

	if (!isLanguage(CAR(args)) && !isSymbol(CAR(args)))
		error("argument is not a valid model\n");

	PROTECT(a = ans = allocList(6));
	CAR(a) = CAR(args);
	TAG(a) = install("formula");
	a = CDR(a);


	/* Step 1: Determine the ``variables'' in the model */
	/* Here we create an expression of the form list(...). */
	/* You can evaluate it to get the model variables. */

	intercept = 1;
	response = 0;
	PROTECT(varlist = lcons(install("list"), nilValue));
	extractVars(CAR(args), 1);
	UNPROTECT(1);
	CAR(a) = varlist;
	TAG(a) = install("variables");
	a = CDR(a);

	nvar = length(varlist) - 1;
	nwords = (nvar - 1) / WORDSIZE + 1;

	/*
	   R_printf("intercept = %d\n",intercept);
	   R_printf("response = %d\n",response);
	   R_printf("nvar = %d\n",nvar);
	   R_printf("nwords = %d\n",nwords);
	 */

	/* Step 2: Recode the model terms in binary form */
	/* and at the same time, expand the model formula. */

	PROTECT(formula = encodeVars(CAR(args)));
	nterm = length(formula);

	/* Step 3: Reorder the model terms. */
	/* Horrible kludge -- write the addresses */
	/* into a vector, simultaneously computing the */
	/* the bitcount for each term.  Use a regular */
	/* (stable) sort of the vector based on bitcounts. */

	PROTECT(pattern = allocVector(STRSXP, nterm));
	n = 0;
	for (call = formula; call != nilValue; call = CDR(call)) {
		LEVELS(CAR(call)) = bitCount(CAR(call));
		STRING(pattern)[n++] = CAR(call);
	}
	sortTerms(STRING(pattern), nterm);
	n = 0;
	for (call = formula; call != nilValue; call = CDR(call)) {
		CAR(call) = STRING(pattern)[n++];
	}
	UNPROTECT(1);

	/* Step 4: Compute the factor pattern for the model. */
	/* 0 - the variable does not apprear in this term. */
	/* 1 - code the variable by contrasts in this term. */
	/* 2 - code the variable by indicators in this term. */

	CAR(a) = pattern = allocMatrix(INTSXP, nvar, nterm);
	TAG(a) = install("factors");
	a = CDR(a);
	for (i = 0; i < nterm * nvar; i++)
		INTEGER(pattern)[i] = 0;
	PROTECT(term = allocTerm());
	n = 0;
	for (call = formula; call != nilValue; call = CDR(call)) {
		for (i = 1; i <= nvar; i++) {
			if (getBit(CAR(call), i))
				INTEGER(pattern)[i - 1 + n * nvar] = termCode(formula, call, i, term);
		}
		n++;
	}
	UNPROTECT(1);

	/* Step 5: Compute variable and term labels */
	/* These are glued immediately to the pattern matrix */

	PROTECT(varnames = allocVector(STRSXP, nvar));
	for (v = CDR(varlist), i = 0; v != nilValue; v = CDR(v)) {
		if (isSymbol(CAR(v)))
			STRING(varnames)[i++] = PRINTNAME(CAR(v));
		else
			STRING(varnames)[i++] = STRING(deparse1(CAR(v), 1))[0];
	}
	PROTECT(termlabs = allocVector(STRSXP, nterm));
	n = 0;
	for (call = formula; call != nilValue; call = CDR(call)) {
		l = 0;
		for (i = 1; i <= nvar; i++) {
			if (getBit(CAR(call), i)) {
				if (l > 0)
					l += 1;
				l += strlen(CHAR(STRING(varnames)[i - 1]));
			}
		}
		STRING(termlabs)[n] = allocString(l);
		CHAR(STRING(termlabs)[n])[0] = '\0';
		l = 0;
		for (i = 1; i <= nvar; i++) {
			if (getBit(CAR(call), i)) {
				if (l > 0)
					strcat(CHAR(STRING(termlabs)[n]), ":");
				strcat(CHAR(STRING(termlabs)[n]), CHAR(STRING(varnames)[i - 1]));
				l++;
			}
		}
		n++;
	}
	PROTECT(v = allocList(2));
	CAR(v) = varnames;
	CADR(v) = termlabs;
	setAttrib(pattern, DimNamesSymbol, v);
	UNPROTECT(3);

	CAR(a) = allocVector(INTSXP, nterm);
	n = 0;
	for (call = formula; call != nilValue; call = CDR(call))
		INTEGER(CAR(a))[n++] = LEVELS(CAR(call));
	TAG(a) = install("order");
	a = CDR(a);

	CAR(a) = (intercept ? mkTrue() : mkFalse());
	TAG(a) = install("intercept");
	a = CDR(a);

	CAR(a) = (response ? mkTrue() : mkFalse());
	TAG(a) = install("response");

	UNPROTECT(2);
	return ans;
}


/* Internal code for the ~ operator */
/* Just returns the unevaluated call */

SEXP do_tilde(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	return call;
}

SEXP do_modelmatrix(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP terms, variables;
	checkArity(op,args);
	terms = CAR(args);
	if(TYPEOF(terms) != LISTSXP) goto badterms;
	variables = getAttrib(terms, install("variables"));

badterms:
	errorcall(call, "invalid terms object\n");
}
