/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define PRINT_GAP	1
#define PRINT_WIDTH	options_width

/* Formating of values */
char *EncodeLogical(RINT, RINT);
char *EncodeFactor(RINT, RINT, char*);
char *EncodeInteger(RINT, RINT);
char *EncodeReal(RFLOAT, RINT, RINT, RINT);
char *EncodeString(char*, RINT, int);
char *EncodeElement(SEXP, RINT, int);

/* OLD */


void catString(char *x, RINT w, int quote);
int labelWidth(RINT n);
void printArray(SEXP x, int quote);
void printFactor(RINT x, RINT w, SEXP levels, RINT nlevels);
void printInteger(RINT x, RINT w);
void printLogical(RINT x, RINT w);
void printMatrix(SEXP x, SEXP dim, SEXP *rl, SEXP *cl, int quote);
void printMatrixColLabel(SEXP *cl, RINT j, RINT w);
void printMatrixRowLabel(SEXP *rl, RINT i, RINT rlabw);
void printNamedVector(SEXP x, SEXP names, int quote);
void printNewLine(RINT n);
void printReal(RFLOAT x, RINT w, RINT d, RINT e);
void printRjustString(char *x, RINT w, int quote);
void printScalar(SEXP x);
void printSpace(RINT n);
void printString(char *x, RINT w, int quote);
void printVector(SEXP x, RINT index, int quote);
void printVectorLabel(RINT i, RINT w);
void scatString(char *buf, char *x, RINT w, int quote);
void sprintElt(char * buf, SEXP x, RINT index, int quote);
void sprintFactor(char *buf, RINT x, RINT w, SEXP levels, RINT nlevels);
void sprintInteger(char *buf, RINT x, RINT w);
void sprintLogical(char *buf, RINT x, RINT w);
void sprintNewLine(char *buf, RINT n);
void sprintReal(char *buf, RFLOAT x, RINT w, RINT d, RINT e);
void sprintRjustString(char *buf, char *x, RINT w, int quote);
void sprintScalar(char *buf, SEXP x);
void sprintSpace(char *buf, RINT n);
void sprintString(char *buf, char *x, RINT w, int quote);
void sprintVectorLabel(char *buf, RINT i, RINT w);
