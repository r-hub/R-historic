/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* NODUP - avoid duplicating objects unconnected to the symbol table */
/* They can be freely mutated */

#define NODUP

#include "Defn.h"

/*
   subscript preamble

   there are three kinds of subscripting [, [[, and $. We have
   three different functions to do these. The special [ subscripting
   where dim(x)==ncol(subscript matrix) is handled down inside
   vectorSubset. The subscript matrix is turned into a subscript
   vector of the appropriate size and then vectorSubset continues.
   This provides coherence especially regarding attributes etc. (it
   would be quicker to pull this case out and do it alone but then
   we have 2 things to update re attributes).

 */

static RINT drop;

static SEXP vectorSubset(SEXP, SEXP);
SEXP matrixSubset(SEXP, SEXP);
static SEXP arraySubset(SEXP, SEXP);
static SEXP do_subscript(SEXP, SEXP, SEXP);
SEXP DropDims(SEXP, SEXP);
RINT get1index(SEXP, SEXP);

SEXP fixLevels(SEXP result, SEXP arg)
{
	SEXP attrib, nattrib;

	if (isFactor(result)) {
		PROTECT(result);
		PROTECT(arg);
		if ((attrib = getAttrib(arg, nattrib = install("levels"))) != nilValue) {
			PROTECT(attrib);
			setAttrib(result, nattrib, attrib);
			UNPROTECT(1);
		}
		UNPROTECT(2);
	}
	return result;
}

/* This is the [ subset operator */
SEXP do_subset(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	RINT lent;
	SEXP v, t, tmp;

	PROTECT(v = eval(CAR(args), rho));
	PROTECT(t = parseSubargs("[", CDR(args), rho));

	if (v == nilValue) {	/* for compatability */
		UNPROTECT(2);
		return v;
	}

	lent = length(t);
	if (isVector(v) || isList(v) || isLanguage(v)) {
		/* first check to ensure the dims are right */
		if (lent > 1 && lent != length(getAttrib(v, DimSymbol)))
			error("incorrect number of dims in \"subset\"\n");
	}
	else
		error("\"subset\" type error\n");
	switch (lent) {
	case 1:
		t = vectorSubset(v, CAR(t));
		break;
	case 2:
		t = matrixSubset(v, t);
		break;
	default:
		t = arraySubset(v, t);
		break;
	}
	UNPROTECT(2);
	return fixLevels(t, v);
}

/* this is the [[ subset and it needs to be fast */
/* the arguments to this call are evaluated */
SEXP do_subset2(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP x, s, dims, rval, names;
	RINT len, k, i, subs, tmp, index[MAXDIM];


	PROTECT(x = eval(CAR(args), rho));

	if (x == nilValue) {	/* for compatability */
		UNPROTECT(1);
		return x;
	}

	PROTECT(s = parseSubargs("[[", CDR(args), rho));

	if (isList(x) || isLanguage(x)) {
		k = get1index(CAR(s), getAttrib(x, NamesSymbol));
		if (k < 0 || k >= length(x))
			error("[[]] subscript out of bounds\n");
		UNPROTECT(2);
#ifdef NODUP
		rval = CAR(nthcdr(x, k));
		NAMED(rval) = NAMED(x);
		return (rval);
#else
		return (CAR(nthcdr(x, k)));
#endif
	}

	if (!isVector(x))
		error("[[]] applied to non-vector\n");

	PROTECT(dims = getAttrib(x, DimSymbol));
	k = length(dims);

	if (!isArray(x)) {
		tmp = get1index(CAR(s), getAttrib(x, NamesSymbol));
		if (tmp < 0 || tmp >= LENGTH(x))
			error("[[]] subscript out of bounds\n");
	}
	else {
		if (k != length(s))
			error("[[]] improper number of subscripts\n");
		names = getAttrib(x, DimNamesSymbol);
		for (i = 0; i < k; i++) {
			index[i] = get1index(CAR(s), isList(names) ? CAR(names) : nilValue);
			if (isList(names))
				names = CDR(names);
			s = CDR(s);
			if (index[i] < 0 || index[i] >= INTEGER(dims)[i])
				error("[[]] subscript out of bounds\n");
		}
		tmp = 0;
		for (i = (k - 1); i > 0; i--)
			tmp = (tmp + index[i]) * INTEGER(dims)[i - 1];
		tmp += index[0];
	}
	rval = allocVector(TYPEOF(x), 1);
	switch (TYPEOF(x)) {
	case INTSXP:
		INTEGER(rval)[0] = INTEGER(x)[tmp];
		break;
	case REALSXP:
		REAL(rval)[0] = REAL(x)[tmp];
		break;
	case STRSXP:
		STRING(rval)[0] = STRING(x)[tmp];
		break;
	case FACTSXP:
	case ORDSXP:
		FACTOR(rval)[0] = FACTOR(x)[tmp];
		break;
	case LGLSXP:
		LOGICAL(rval)[0] = LOGICAL(x)[tmp];
		break;
	default:
		abort();
	}
	UNPROTECT(3);
	return fixLevels(rval, x);
}

/* the $ subset, we need to be sure to only evaluate the first arg */
/* as the second will be a symbol that needs to be matched, not evaluated */
SEXP do_subset3(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x, y, nlist;

	checkArity(op, args);

	x = eval(CAR(args), env);
	PROTECT(x);

	if (!isList(x)) {
		UNPROTECT(1);
		return nilValue;
	}

	nlist = CAR(CADR(args));
	if (isString(nlist))
		nlist = install(CHAR(STRING(nlist)[0]));

	UNPROTECT(1);
	for (y = x; y != nilValue; y = CDR(y))
		if (TAG(y) == nlist) {
			NAMED(CAR(y)) = NAMED(x);
			return CAR(y);
		}
	return nilValue;
}

/* get a single index for the [[]] subset, and check to be sure */
/* that only one index is being selected */
RINT get1index(SEXP s, SEXP names)
{
	RINT k, i;

	if (length(s) > 1)
		error("[[]] attempt to select more than one element\n");
	if (TYPEOF(s) == INTSXP || TYPEOF(s) == LGLSXP)
		k = INTEGER(s)[0] - 1;
	else if (TYPEOF(s) == REALSXP)
		k = REAL(s)[0] - 1;
	else if (TYPEOF(s) == STRSXP) {
		k = -1;
		for (i = 0; i < length(names); i++)
			if (streql(CHAR(STRING(names)[i]), CHAR(STRING(s)[0]))) {
				k = i;
				break;
			}
	}
	else if (isSymbol(s)) {
		k = -1;
		for (i = 0; i < length(names); i++)
			if (streql(CHAR(STRING(names)[i]), CHAR(PRINTNAME(s)))) {
				k = i;
				break;
			}
	}
	else
		error("[[]] wrong subscript type\n");
	return k;
}

static SEXP mat2indsub(SEXP dims, SEXP s)
{
	RINT tdim, indx, j, i, nrs = nrows(s);
	SEXP rvec;

	PROTECT(rvec = allocVector(INTSXP, nrs));
	s = coerceVector(s, INTSXP);
	setIVector(INTEGER(rvec), nrs, 0);


	for (i = 0; i < nrs; i++) {
		tdim = 1;
		for (j = 0; j < LENGTH(dims); j++) {
			if (INTEGER(s)[i + j * nrs] > INTEGER(dims)[j])
				error("subscript out of bounds\n");
			INTEGER(rvec)[i] += (INTEGER(s)[i + j * nrs] - 1) * tdim;
			tdim *= INTEGER(dims)[j];
		}
		/* now put it into 1 based subscripting */
		INTEGER(rvec)[i]++;
	}
	UNPROTECT(1);
	return (rvec);
}


static SEXP vectorSubset(SEXP x, SEXP s)
{
	RINT n, mode;
	SEXP index, result, attrib, nattrib;

	if (s == missingArg)
		return x;

	PROTECT(s);
	attrib = getAttrib(x, DimSymbol);

	/* check to see if we have special subscripting */

	if (isMatrix(s) && isArray(x) && (isInteger(s) || isReal(s)) &&
	    ncols(s) == length(attrib)) {
		s = mat2indsub(attrib, s);
		UNPROTECT(1);
		PROTECT(s);
	}

	PROTECT(index = makeSubscript(x, s));
	n = LENGTH(index);
	mode = TYPEOF(x);
	result = allocVector((mode == LANGSXP) ? LISTSXP : mode, n);
#ifdef NODUP
	/* If x is named, the subset will be too */
	NAMED(result) = NAMED(x);
#endif
	if (isFactor(x)) {
		LEVELS(result) = LEVELS(x);
	}

	PROTECT(result = do_subscript(x, result, index));
	if ((attrib = getAttrib(x, NamesSymbol)) != nilValue) {
		nattrib = allocVector(TYPEOF(attrib), n);
		PROTECT(nattrib);
		nattrib = do_subscript(attrib, nattrib, index);
		setAttrib(result, NamesSymbol, nattrib);
		UNPROTECT(1);
	}
	UNPROTECT(3);
	return result;
}

static SEXP do_subscript(SEXP x, SEXP result, SEXP index)
{
	RINT i, ii, n, nx, mode;
	SEXP tmp, tmp2;

	mode = TYPEOF(x);
	n = LENGTH(index);
	nx = length(x);
	tmp = result;

	if (x == nilValue)
		return (x);

	for (i = 0; i < n; i++) {
		ii = INTEGER(index)[i];
		if (ii != NA_INTEGER)
			ii--;
		switch (mode) {
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			if (0 <= ii && ii < nx && ii != NA_INTEGER)
				INTEGER(result)[i] = INTEGER(x)[ii];
			else
				INTEGER(result)[i] = NA_INTEGER;
			break;
		case REALSXP:
			if (0 <= ii && ii < nx && ii != NA_INTEGER)
				REAL(result)[i] = REAL(x)[ii];
			else
				REAL(result)[i] = NA_REAL;
			break;
		case STRSXP:
			if (0 <= ii && ii < nx && ii != NA_INTEGER)
				STRING(result)[i] = STRING(x)[ii];
			else
				STRING(result)[i] = NA_STRING;
			break;
		case LISTSXP:
		case LANGSXP:
			if (0 <= ii && ii < nx && ii != NA_INTEGER) {
				tmp2 = nthcdr(x, ii);
				CAR(tmp) = CAR(tmp2);
				TAG(tmp) = TAG(tmp2);
			}
			else
				CAR(tmp) = nilValue;
			tmp = CDR(tmp);
			break;
		default:
			abort();
		}
	}
	return (result);
}

SEXP matrixSubset(SEXP x, SEXP s)
{
	SEXP t, sr, sc, a, dms, dnms, attrib, nattrib;
	RINT nr, nc, nrs, ncs;
	RINT i, j, ii, jj, ij, iijj;

	nr = nrows(x);
	nc = ncols(x);

	/* s is protected */
	/* the following ensures that */
	/* pointers remain protected */

	sr = CAR(s) = arraySubscript(0, CAR(s), x);
	sc = CADR(s) = arraySubscript(1, CADR(s), x);
	nrs = LENGTH(sr);
	ncs = LENGTH(sc);
	PROTECT(sr);
	PROTECT(sc);
	a = allocMatrix(TYPEOF(x), nrs, ncs);
	PROTECT(a);
	for (i = 0; i < nrs; i++) {
		ii = INTEGER(sr)[i];
		if (ii != NA_INTEGER) {
			if (ii < 1 || ii > nr)
				error("subscript out of bounds\n");
			ii--;
		}
		for (j = 0; j < ncs; j++) {
			jj = INTEGER(sc)[j];
			if (jj != NA_INTEGER) {
				if (jj < 1 || jj > nc)
					error("subscript out of bounds\n");
				jj--;
			}
			ij = i + j * nrs;
			if (ii == NA_INTEGER || jj == NA_INTEGER) {
				switch (TYPEOF(x)) {
				case LGLSXP:
				case INTSXP:
				case FACTSXP:
				case ORDSXP:
					INTEGER(a)[ij] = NA_INTEGER;
					break;
				case REALSXP:
					REAL(a)[ij] = NA_REAL;
					break;
				case STRSXP:
					STRING(a)[i] = NA_STRING;
					break;
				}
			}
			else {
				iijj = ii + jj * nr;
				switch (TYPEOF(x)) {
				case LGLSXP:
				case INTSXP:
				case FACTSXP:
				case ORDSXP:
					INTEGER(a)[ij] = INTEGER(x)[iijj];
					break;
				case REALSXP:
					REAL(a)[ij] = REAL(x)[iijj];
					break;
				case STRSXP:
					STRING(a)[ij] = STRING(x)[iijj];
					break;
				}
			}
		}
	}
	PROTECT(dnms = getAttrib(x, DimNamesSymbol));
	if (dnms == nilValue) {
		if (drop)
			ATTRIB(a) = DropDims(getAttrib(a, DimSymbol), dnms);
		UNPROTECT(4);
		return a;
	}
	dms = list2(allocVector(TYPEOF(CAR(dnms)), nrs), allocVector(TYPEOF(CADR(dnms)), ncs));
	PROTECT(dms);
	CAR(dms) = do_subscript(CAR(dnms), CAR(dms), sr);
	CADR(dms) = do_subscript(CADR(dnms), CADR(dms), sc);
	if (drop)
		ATTRIB(a) = DropDims(getAttrib(a, DimSymbol), dms);
	else
		setAttrib(a, DimNamesSymbol, dms);
	UNPROTECT(5);
	return a;
}

static SEXP arraySubset(SEXP x, SEXP s)
{
	RINT i, j, k, ii, jj, mode, n, ns;
	RINT *subs[MAXDIM];
	RINT index[MAXDIM], offset[MAXDIM];
	SEXP bound, dims;
	SEXP tmp, t;
	SEXP result;
	SEXP names, nnames, tname, tmp2;

	mode = TYPEOF(x);
	PROTECT(dims = getAttrib(x, DimSymbol));
	k = length(dims);

	PROTECT(bound = allocVector(INTSXP, k));
	tmp = s;
	for (i = 0; i < k; i++) {
		CAR(tmp) = arraySubscript(i, CAR(tmp), x);
		INTEGER(bound)[i] = LENGTH(CAR(tmp));
		tmp = CDR(tmp);
	}
	PROTECT(result = allocArray(mode, bound));

	n = 1;
	tmp = s;
	PROTECT(names = getAttrib(x, DimNamesSymbol));
	nnames = tmp2 = duplicate(names);
	PROTECT(nnames);
	if (names != nilValue)
		for (i = 0; i < k; i++) {
			tname = allocVector(STRSXP, LENGTH(CAR(tmp)));
			PROTECT(tname);
			CAR(tmp2) = do_subscript(CAR(names), tname, CAR(tmp));
			UNPROTECT(1);
			tmp = CDR(tmp);
			names = CDR(names);
			tmp2 = CDR(tmp2);
		}
	tmp = s;
	for (i = 0; i < k; i++) {
		index[i] = 0;
		subs[i] = INTEGER(CAR(tmp));
		n *= INTEGER(bound)[i];
		tmp = CDR(tmp);
	}
	offset[0] = 1;
	for (i = 1; i < k; i++)
		offset[i] = offset[i - 1] * INTEGER(dims)[i - 1];


	for (i = 0; i < n; i++) {
		ii = 0;
		for (j = 0; j < k; j++) {
			jj = subs[j][index[j]];
			if (jj == NA_INTEGER) {
				ii = NA_INTEGER;
				goto assignLoop;
			}
			if (jj < 1 || jj > INTEGER(dims)[j])
				error("subscript out of bounds\n");
			ii += (jj - 1) * offset[j];
		}

	      assignLoop:
		switch (mode) {
		case LGLSXP:
			if (ii != NA_LOGICAL)
				LOGICAL(result)[i] = LOGICAL(x)[ii];
			else
				LOGICAL(result)[i] = NA_LOGICAL;
			break;
		case FACTSXP:
		case ORDSXP:
			if (ii != NA_INTEGER)
				FACTOR(result)[i] = FACTOR(x)[ii];
			else
				FACTOR(result)[i] = NA_FACTOR;
			break;
		case INTSXP:
			if (ii != NA_INTEGER)
				INTEGER(result)[i] = INTEGER(x)[ii];
			else
				INTEGER(result)[i] = NA_INTEGER;
			break;
		case REALSXP:
			if (ii != NA_INTEGER)
				REAL(result)[i] = REAL(x)[ii];
			else
				REAL(result)[i] = NA_REAL;
			break;
		case STRSXP:
			if (ii != NA_INTEGER)
				STRING(result)[i] = STRING(x)[ii];
			else
				STRING(result)[i] = NA_STRING;
			break;
		}
		if (n > 1) {
			j = 0;
			while (++index[j] >= INTEGER(bound)[j]) {
				index[j] = 0;
				j = ++j % ns;
			}
		}
	}
	PROTECT(result);
	if (drop)
		ATTRIB(result) = DropDims(bound, nnames);
	else
		setAttrib(result, DimNamesSymbol, nnames);
	UNPROTECT(6);
	return result;
}

SEXP evalSublist(SEXP el, SEXP rho)
{
	SEXP h, t;

	if (el == nilValue)
		return nilValue;
	else {
		if (CAR(el) == missingArg)
			PROTECT(h = missingArg);
		else
			PROTECT(h = eval(CAR(el), rho));
		PROTECT(t = evalSublist(CDR(el), rho));
		t = CONS(h, t);
		TAG(t) = TAG(el);
		UNPROTECT(2);
		return t;
	}
}

SEXP parseSubargs(char *name, SEXP args, SEXP rho)
{
	SEXP t, m;

	if (TYPEOF(CAR(args)) == LISTSXP) {
		PROTECT(t = evalSublist(CAR(args), rho));
	}
	else if (isLanguage(CAR(args)) || isSymbol(CAR(args))) {
		PROTECT(t = eval(CAR(args), rho));
	}
	if (TYPEOF(t) != LISTSXP)
		error("%s, invalid subscripting\n", name);
	PROTECT(m = matchArg(DropSymbol, &t));
	drop = asLogical(m);
	if (drop == NA_LOGICAL)
		drop = 1;
	UNPROTECT(2);
	return t;
}
