/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define COUNTING

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <setjmp.h>

#define HSIZE		211	/* The size of the hash table for symbols */
#define MAXDIM		25	/* up to 25-way arrays only */
#define MAXELTSIZE	512	/* the largest number of characters in a vector element */

#define streql(s, t)	(!strcmp((s), (t)))
#define ISVALUEOP(x)	((PLUSOP<=(x)) && ((x)<=PRINTOP))
#define ISCONTROLOP(x)	((IFOP<=(x)) && ((x)<=BEGINOP))

typedef long		RINT;
typedef unsigned long	UNSIGNED;
typedef double		RFLOAT;

typedef enum {
		/* special forms */
	IFOP, 
	WHILEOP, 
	FOROP, 
	REPEATOP,
	DEFINEOP, 
	SETOP, 
	GSETOP, 
	QUOTEOP, 
	PARENOP, 
	QUITOP, 
	LAMBDAOP, 
	BEGINOP, 
	BREAKOP, 
	NEXTOP, 
	RETURNOP, 
	STOPOP, 
	WARNINGOP, 
		/* arithmetic operators */
	PLUSOP, 
	MINUSOP, 
	TIMESOP, 
	DIVOP, 
	POWOP, 
	MODOP, 
		/* relational operators */
	EQOP, 
	NEOP, 
	LTOP, 
	LEOP, 
	GEOP, 
	GTOP, 
		/* subset operators */
	SBSETOP, 
	SBSETASSGN, 
		/* predicates */
	SYMBOLPOP, 
	LISTPOP, 
	NULLPOP, 
		/* misc */
	DEPARSEOP, 
	PRINTOP, 
	LPRINTOP, 
	GCOP, 
	SEQOP, 
	LENOP, 
	REPOP, 
	TRUEVAL
} BUILTINOP;

typedef int SEXPTYPE;
 
/*	Fundamental Data Types 
 *
 *	These are largely lisp influenced structures, with the
 *	exception of LGLSXP, FACTSXP, ORDSXP, INTSXP, REALSXP and STRSXP
 *	which are the element types for S-like data objects.
 */

#define NILSXP		0	/* nil */
#define SYMSXP		1	/* symbols */
#define LISTSXP		2	/* lists & dotted pairs */
#define CLOSXP		3	/* closures */
#define ENVSXP		4	/* environments */
#define PROMSXP		5	/* evaluated/unevaluated closure arguments */
#define LANGSXP		6	/* language constructs (special lists) */
#define SPECIALSXP	7	/* special forms */
#define BUILTINSXP	8	/* builtin non-special forms */
#define CHARSXP		9	/* "scalar" string type */
#define LGLSXP		10	/* logical vectors */
#define FACTSXP		11	/* unordered factors */
#define ORDSXP		12	/* ordered factors */
#define INTSXP		13	/* integer vectors */
#define REALSXP		14	/* real variables */
#define STRSXP		15	/* string vectors */
#define DOTSXP		16	/* dot-dot-dot object */
#define FRAMESXP	17	/* data frames */
#define ANYSXP		18	/* make "any" args work */

typedef struct SEXPREC {
	struct {
		unsigned int type  :  5;
		unsigned int obj   :  1;
		unsigned int named :  2;
		unsigned int gp    : 16;
		unsigned int mark  :  1;
		unsigned int       :  7;
	} sxpinfo;
	struct SEXPREC *attrib; 	/* Attributes */
	union {
		struct {
			RINT	length;
			union {
				char		*c;
				RINT		*i;
				RFLOAT		*f;
				struct SEXPREC	**s;
			} type;
		} vecsxp;
		struct {
			RINT		offset;
		} primsxp;
		struct {
			struct SEXPREC *pname;
			struct SEXPREC *value;
			struct SEXPREC *internal;
		} symsxp;
		struct {
			struct SEXPREC *carval;
			struct SEXPREC *cdrval;
			struct SEXPREC *tagval;
		} listsxp;
		struct {
			struct SEXPREC *frame;
			struct SEXPREC *enclos;
		} envsxp;
		struct {
			struct SEXPREC *formals;
			struct SEXPREC *body;
			struct SEXPREC *env;
		} closxp;
		struct {
			struct SEXPREC *value;
			struct SEXPREC *expr;
			struct SEXPREC *env;
		} promsxp;
	} u;
} SEXPREC, *SEXP;


typedef SEXP (*CCODE)();

typedef struct {
	char		*name;		/* print name */
	CCODE		cfun;		/* c-code address */
	BUILTINOP	code;		/* offset within c-code */
	RINT		eval;		/* evaluate args? */
	RINT		arity;		/* function arity */
	RINT		gram;		/* pretty-print info */
	RINT		mark;		/* mark info for restore */
} FUNTAB_ENTRY;

	/* General Cons Cell Attributes */
#define ATTRIB(x)	((x)->attrib)
#define OBJECT(x)	((x)->sxpinfo.obj)
#define MARK(x)		((x)->sxpinfo.mark)
#define TYPEOF(x)	((x)->sxpinfo.type)
#define NAMED(x)	((x)->sxpinfo.named)

	/* Primitive Access Macros */
#define PRIMFUN(x)	(FunTab[(x)->u.primsxp.offset].cfun)
#define PRIMNAME(x)	(FunTab[(x)->u.primsxp.offset].name)
#define PRIMVAL(x)	(FunTab[(x)->u.primsxp.offset].code)
#define PRIMARITY(x)	(FunTab[(x)->u.primsxp.offset].arity)
#define PPINFO(x)	(FunTab[(x)->u.primsxp.offset].gram)


	/* Symbol Access Macros */
#define PRINTNAME(x)	((x)->u.symsxp.pname)
#define SYMVALUE(x)	((x)->u.symsxp.value)
#define INTERNAL(x)	((x)->u.symsxp.internal)


	/* Vector Access Macros */
#define LENGTH(x)	((x)->u.vecsxp.length)
#define CHAR(x)		((x)->u.vecsxp.type.c)
#define STRING(x)	((x)->u.vecsxp.type.s)
#define LOGICAL(x)	((x)->u.vecsxp.type.i)
#define FACTOR(x)	((x)->u.vecsxp.type.i)
#define INTEGER(x)	((x)->u.vecsxp.type.i)
#define REAL(x)		((x)->u.vecsxp.type.f)
#define LEVELS(x)	((x)->sxpinfo.gp)

	/* List Access Macros */
	/* These also work for ... objects */
#define LISTVAL(x)	((x)->u.listsxp)
#define TAG(e)		((e)->u.listsxp.tagval)
#define CAR(e)		((e)->u.listsxp.carval)
#define CDR(e)		((e)->u.listsxp.cdrval)
#define CAAR(e)		CAR(CAR(e))
#define CDAR(e)		CDR(CAR(e))
#define CADR(e)		CAR(CDR(e))
#define CDDR(e)		CDR(CDR(e))
#define CADDR(e)	CAR(CDR(CDR(e)))
#define CADDDR(e)	CAR(CDR(CDR(CDR(e))))
#define CONS(a, b)	cons((a), (b))
#define LCONS(a, b)	lcons((a), (b))			/* language lists */
#define MISSING(x)	((x)->sxpinfo.gp)	/* for closure calls */
#define SETCDR(x,y)	{SEXP X=(x), Y=(y); if(X != nilValue) CDR(X)=Y; else error("bad value");} 

	/* Closure Access Macros */
#define FORMALS(x)	((x)->u.closxp.formals)
#define BODY(x)		((x)->u.closxp.body)
#define CLOENV(x)	((x)->u.closxp.env)

	/* Environment Access Macros */
#define FRAME(x)	((x)->u.envsxp.frame)
#define ENCLOS(x)	((x)->u.envsxp.enclos)
#define NARGS(x)	((x)->sxpinfo.gp)	/* for closure calls */

	/* Promise Access Macros */
#define PREXPR(x)	((x)->u.promsxp.expr)
#define PRENV(x)	((x)->u.promsxp.env)
#define PRVALUE(x)	((x)->u.promsxp.value)

#define PROTECT(s)	protect(s)
#define UNPROTECT(n)	unprotect(n)

typedef struct {
	union {
		SEXP		backpointer;
		double		align;
	} u;
} VECREC, *VECP;

typedef struct RCONTEXT {
	struct RCONTEXT *nextcontext;
	jmp_buf cjmpbuf;
	int cstacktop;
	int callflag;
	SEXP cenvir;
	SEXP cloenv;
	SEXP conexit;
	void (*cend)();
} RCONTEXT, *context;

#define BACKPOINTER(v)	((v).u.backpointer)
#define BYTE2VEC(n)	(((n)>0)?(((n)-1)/sizeof(VECREC)+1):0)
#define INT2VEC(n)	(((n)>0)?(((n)*sizeof(RINT)-1)/sizeof(VECREC)+1):0)
#define FLOAT2VEC(n)	(((n)>0)?(((n)*sizeof(RFLOAT)-1)/sizeof(VECREC)+1):0)
#define PTR2VEC(n)	(((n)>0)?(((n)*sizeof(SEXP)-1)/sizeof(VECREC)+1):0)

extern SEXP		globalEnv;
extern SEXP		*argStack;
extern RINT		stacktop;
extern RINT		stacksize;
extern int		R_nsize;
extern int		R_vsize;
extern int		R_ssize;
extern RINT		nsize;
extern RINT		vsize;
extern RINT		visible;
extern SEXPREC		*nheap;
extern VECREC		*vheap;
extern SEXP		freeSEXP;
extern SEXP		currentExp;
extern SEXP		returnedValue;
extern jmp_buf		stack_state;
extern SEXP		*SYMBOL_TABLE;
extern RCONTEXT		*globalcontext;
extern RCONTEXT 	*toplevelcontext;
extern FILE		*Rconsolefile;	/* Where error messages go */
extern FILE		*Routputfile;	/* Where output is currently going */
extern FILE		*Rsinkfile;	/* Current sink file */
extern FILE		*Rinputfile;	/* Where input is coming from */
extern FUNTAB_ENTRY	FunTab[];
extern VECREC   	*R_vtop;	/* free pointer for vector heap */
extern long		R_nvcell;	/* bytes allocated of vector heap */
extern long		R_collected;
extern RINT		R_Console;	/* indicates whether we are reading */
					/* from the console or not	*/
extern int		R_Init;
extern int		R_Unnamed;
extern int		R_DirtyImage;
extern char		R_ImageName[256];


extern SEXP		nilValue;
extern SEXP		trueValue;
extern SEXP		falseValue;
extern SEXP		unboundValue;
extern SEXP		missingArg;
extern SEXP		ClassSymbol;
extern SEXP		DotsSymbol;
extern SEXP		DimSymbol;
extern SEXP		DropSymbol;
extern SEXP		NamesSymbol;
extern SEXP		DimNamesSymbol;
extern SEXP		LevelsSymbol;
extern SEXP		TspSymbol;
extern SEXP		ModeSymbol;
extern SEXP		NarmSymbol;
extern SEXP		SeedsSymbol;
extern SEXP		DollarSymbol;
extern SEXP		BracketSymbol;
extern SEXP		Bracket2Symbol;
extern SEXP		commentSxp;
extern SEXP		ParseText;

extern RINT		ParseCnt;
extern RINT		ParseError;
extern RINT		max_int;
extern RFLOAT		max_float;
extern RINT		na_logical;
extern RINT		na_integer;
extern RINT		na_factor;
extern RFLOAT		na_real;
extern SEXP		na_string;

extern char		options_prompt[30];
extern char		options_editor[30];
extern char		options_continuation[30];
extern RINT		options_expressions;
extern RINT		options_width;
extern RINT		options_digits;
 
#define MAX_INTEGER	max_int
#define MAX_REAL	max_float
#define NA_LOGICAL	na_logical
#define NA_INTEGER	na_integer
#define NA_FACTOR	na_factor
#define NA_REAL		na_real
#define NA_STRING	na_string


/* Builtin Functions */

SEXP do_allocArray(SEXP, SEXP, SEXP, SEXP);
SEXP do_allocMatrix(SEXP, SEXP, SEXP, SEXP);
SEXP do_aperm(SEXP, SEXP, SEXP, SEXP);
SEXP do_arith(SEXP, SEXP, SEXP, SEXP);
SEXP do_as(SEXP, SEXP, SEXP, SEXP);
SEXP do_assign(SEXP, SEXP, SEXP, SEXP);
SEXP do_attach(SEXP,SEXP,SEXP,SEXP);
SEXP do_attr(SEXP, SEXP, SEXP, SEXP);
SEXP do_attrgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_attributes(SEXP, SEXP, SEXP, SEXP);
SEXP do_attributesgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_axis(SEXP, SEXP, SEXP, SEXP);
SEXP do_bind(SEXP, SEXP, SEXP, SEXP);
SEXP do_box(SEXP, SEXP, SEXP, SEXP);
SEXP do_browser(SEXP, SEXP, SEXP, SEXP);
SEXP do_builtin(SEXP, SEXP, SEXP, SEXP);
SEXP do_call(SEXP, SEXP, SEXP, SEXP);
SEXP do_cat(SEXP, SEXP, SEXP, SEXP);
SEXP do_compcases(SEXP, SEXP, SEXP, SEXP);
SEXP do_dataentry(SEXP, SEXP, SEXP, SEXP);
SEXP do_deparse(SEXP, SEXP, SEXP, SEXP);
SEXP do_deprecated(SEXP, SEXP, SEXP, SEXP);
SEXP do_detach(SEXP,SEXP,SEXP,SEXP);
SEXP do_device(SEXP, SEXP, SEXP, SEXP);
SEXP do_dim(SEXP, SEXP, SEXP, SEXP);
SEXP do_dimgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_dimnames(SEXP, SEXP, SEXP, SEXP);
SEXP do_dimnamesgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_dotCode(SEXP, SEXP, SEXP, SEXP);
SEXP do_dput(SEXP, SEXP, SEXP, SEXP);
SEXP do_dump(SEXP, SEXP, SEXP, SEXP);
SEXP do_dumpb(SEXP, SEXP, SEXP, SEXP);
SEXP do_duplicated(SEXP, SEXP, SEXP, SEXP);
SEXP do_edit(SEXP, SEXP, SEXP, SEXP);
SEXP do_envir(SEXP, SEXP, SEXP, SEXP);
SEXP do_envirgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_eval(SEXP, SEXP, SEXP, SEXP);
SEXP do_expression(SEXP, SEXP, SEXP, SEXP);
SEXP do_format(SEXP, SEXP, SEXP, SEXP);
SEXP do_gcinfo(SEXP, SEXP, SEXP, SEXP);
SEXP do_get(SEXP, SEXP, SEXP, SEXP);
SEXP do_internal(SEXP, SEXP, SEXP, SEXP);
SEXP do_interns(SEXP, SEXP, SEXP, SEXP);
SEXP do_invisible(SEXP, SEXP, SEXP, SEXP);
SEXP do_is(SEXP, SEXP, SEXP, SEXP);
SEXP do_isna(SEXP, SEXP, SEXP, SEXP);
SEXP do_lengthgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_lines(SEXP, SEXP, SEXP, SEXP);
SEXP do_logic(SEXP, SEXP, SEXP, SEXP);
SEXP do_logic2(SEXP, SEXP, SEXP, SEXP);
SEXP do_logic3(SEXP, SEXP, SEXP, SEXP);
SEXP do_ls(SEXP, SEXP, SEXP, SEXP);
#ifdef Macintosh
SEXP do_macedit(SEXP, SEXP, SEXP, SEXP);
#endif
SEXP do_machine(SEXP, SEXP, SEXP, SEXP);
SEXP do_makefactor(SEXP, SEXP, SEXP, SEXP);
SEXP do_makelist(SEXP, SEXP, SEXP, SEXP);
SEXP do_makevector(SEXP, SEXP, SEXP, SEXP);
SEXP do_match(SEXP, SEXP, SEXP, SEXP);
SEXP do_math1(SEXP, SEXP, SEXP, SEXP);
SEXP do_math2(SEXP, SEXP, SEXP, SEXP);
SEXP do_math3(SEXP, SEXP, SEXP, SEXP);
SEXP do_math4(SEXP, SEXP, SEXP, SEXP);
SEXP do_matprod(SEXP, SEXP, SEXP, SEXP);
SEXP do_missing(SEXP, SEXP, SEXP, SEXP);
SEXP do_names(SEXP, SEXP, SEXP, SEXP);
SEXP do_namesgets(SEXP, SEXP, SEXP, SEXP);
SEXP do_nargs(SEXP, SEXP, SEXP, SEXP);
SEXP do_nchar(SEXP,SEXP,SEXP,SEXP);
SEXP do_nlevels(SEXP, SEXP, SEXP, SEXP);
SEXP do_nrc(SEXP, SEXP, SEXP, SEXP);
SEXP do_onexit(SEXP, SEXP, SEXP, SEXP);
SEXP do_options(SEXP, SEXP, SEXP, SEXP);
SEXP do_order(SEXP, SEXP, SEXP, SEXP);
SEXP do_par(SEXP, SEXP, SEXP, SEXP);
SEXP do_parse(SEXP, SEXP, SEXP, SEXP);
SEXP do_paste(SEXP, SEXP, SEXP, SEXP);
SEXP do_pause(SEXP, SEXP, SEXP, SEXP);
SEXP do_plot_abline(SEXP, SEXP, SEXP, SEXP);
SEXP do_plot_content(SEXP, SEXP, SEXP, SEXP);
SEXP do_plot_new(SEXP, SEXP, SEXP, SEXP);
SEXP do_plot_range(SEXP, SEXP, SEXP, SEXP);
SEXP do_plot_setup(SEXP, SEXP, SEXP, SEXP);
SEXP do_plot_titles(SEXP, SEXP, SEXP, SEXP);
SEXP do_points(SEXP, SEXP, SEXP, SEXP);
SEXP do_polygon(SEXP, SEXP, SEXP, SEXP);
SEXP do_print(SEXP, SEXP, SEXP, SEXP);
SEXP do_psort(SEXP, SEXP, SEXP, SEXP);
SEXP do_rank(SEXP, SEXP, SEXP, SEXP);
SEXP do_random1(SEXP, SEXP, SEXP, SEXP);
SEXP do_random2(SEXP, SEXP, SEXP, SEXP);
SEXP do_random3(SEXP, SEXP, SEXP, SEXP);
SEXP do_rect(SEXP, SEXP, SEXP, SEXP);
SEXP do_relop(SEXP, SEXP, SEXP, SEXP);
SEXP do_remove(SEXP, SEXP, SEXP, SEXP);
SEXP do_restore(SEXP, SEXP, SEXP, SEXP);
SEXP do_restoreb(SEXP, SEXP, SEXP, SEXP);
SEXP do_rm(SEXP, SEXP, SEXP, SEXP);
SEXP do_rnorm(SEXP, SEXP, SEXP, SEXP);
SEXP do_rowscols(SEXP, SEXP, SEXP, SEXP);
SEXP do_runif(SEXP, SEXP, SEXP, SEXP);
SEXP do_sample(SEXP, SEXP, SEXP, SEXP);
SEXP do_scan(SEXP, SEXP, SEXP, SEXP);
SEXP do_setpars(SEXP, SEXP, SEXP, SEXP);
SEXP do_sort(SEXP, SEXP, SEXP, SEXP);
SEXP do_special(SEXP, SEXP, SEXP, SEXP);
SEXP do_stop(SEXP, SEXP, SEXP, SEXP);
SEXP do_strsplit(SEXP,SEXP,SEXP,SEXP);
SEXP do_subassign(SEXP, SEXP, SEXP, SEXP);
SEXP do_subassign2(SEXP, SEXP, SEXP, SEXP);
SEXP do_subassign2(SEXP, SEXP, SEXP, SEXP);
SEXP do_subassign3(SEXP, SEXP, SEXP, SEXP);
SEXP do_subset(SEXP, SEXP, SEXP, SEXP);
SEXP do_subset2(SEXP, SEXP, SEXP, SEXP);
SEXP do_subset3(SEXP, SEXP, SEXP, SEXP);
SEXP do_substitute(SEXP, SEXP, SEXP, SEXP);
SEXP do_substr(SEXP,SEXP,SEXP,SEXP);
SEXP do_summary(SEXP, SEXP, SEXP, SEXP);
SEXP do_switch(SEXP, SEXP, SEXP, SEXP);
SEXP do_system(SEXP, SEXP, SEXP, SEXP);
SEXP do_terms(SEXP, SEXP, SEXP, SEXP);
SEXP do_text(SEXP, SEXP, SEXP, SEXP);
SEXP do_tilde(SEXP, SEXP, SEXP, SEXP);
SEXP do_transpose(SEXP, SEXP, SEXP, SEXP);
SEXP do_typeof(SEXP, SEXP, SEXP, SEXP);
SEXP do_unlist(SEXP, SEXP, SEXP, SEXP);
SEXP do_warning(SEXP, SEXP, SEXP, SEXP);

SEXP allocArray(SEXPTYPE, SEXP);
SEXP allocMatrix(SEXPTYPE, RINT, RINT);
SEXP allocSExp(SEXPTYPE);
SEXP allocString(int);
SEXP allocVector(SEXPTYPE, RINT);
SEXP allocList(RINT);
SEXP append(SEXP, SEXP);
SEXP applyClosure(SEXP, SEXP, SEXP, SEXP);
SEXP applyRelOp(RINT, RINT, BUILTINOP);
SEXP asChar(SEXP);
RINT asInteger(SEXP);
RINT asLogical(SEXP);
RFLOAT asReal(SEXP);
SEXP arraySubscript(RINT, SEXP, SEXP);
void begincontext(RCONTEXT*, int, SEXP, SEXP);
void checkArity(SEXP, SEXP);
void CheckFormals(SEXP);
SEXP coerceVector(SEXP, SEXPTYPE);
SEXP coerceList(SEXP, SEXPTYPE);
void compactPhase(void);
int conformable(SEXP, SEXP);
SEXP cons(SEXP, SEXP);
SEXP copyVector(SEXP, SEXP);
void defineVar(SEXP, SEXP, SEXP);
SEXP deparse1(SEXP,RINT);
SEXP duplicate(SEXP);
SEXP emptyEnv(void);
void endcontext(RCONTEXT*);
void error(char*, ...);
void errorcall(SEXP, char*, ...);
SEXP eval(SEXP, SEXP);
SEXP evalList(SEXP, SEXP);
SEXP extendEnv(SEXP, SEXP, SEXP);
void findcontext(int, SEXP);
SEXP findVar(SEXP, SEXP);
SEXP findVar1(SEXP, SEXP, SEXPTYPE, RINT);
SEXP findVarInFrame(SEXP, SEXP);
SEXP findFun(SEXP, SEXP);
void gc(void);
SEXP getAttrib(SEXP, SEXP);
int hashpjw(char*);
void initGlobalEnv(void);
void initMemory(RINT, RINT);
void initNames(void);
void initStack(void);
SEXP install(char*);
void internalTypeCheck(SEXP, SEXP, SEXPTYPE);
int isArray(SEXP);
int isFactor(SEXP);
int isInteger(SEXP);
int isLanguage(SEXP);
int isList(SEXP);
int isLogical(SEXP);
int isMatrix(SEXP);
int isNull(SEXP);
int isNumeric(SEXP);
int isReal(SEXP);
int isString(SEXP);
int isSymbol(SEXP);
int isVector(SEXP);
int isVectorizable(SEXP);
SEXP lang1(SEXP);
SEXP lang2(SEXP, SEXP);
SEXP lang3(SEXP, SEXP, SEXP);
SEXP lang4(SEXP, SEXP, SEXP, SEXP);
SEXP lcons(SEXP, SEXP);
RINT length(SEXP);
SEXP list1(SEXP);
SEXP list2(SEXP, SEXP);
SEXP list3(SEXP, SEXP, SEXP);
SEXP list4(SEXP, SEXP, SEXP, SEXP);
SEXP listAppend(SEXP, SEXP);
SEXP makeSubscript(SEXP, SEXP);
void markPhase(void);
void markSExp(SEXP);
SEXP matchArg(SEXP, SEXP*);
SEXP matchPar(char*, SEXP*);
SEXP mkCLOSXP(SEXP, SEXP, SEXP);
SEXP mkEnv(SEXP, SEXP, SEXP);
SEXP mkPRIMSXP (RINT, RINT);
SEXP mkPROMISE(SEXP, SEXP);
SEXP mkQUOTE(SEXP);
SEXP mkSYMSXP(SEXP, SEXP);
SEXP mkChar(char*);
SEXP mkFalse(void);
SEXP mkString(char*);
SEXP mkTrue(void);
int ncols(SEXP);
int nrows(SEXP);
SEXP nthcdr(SEXP, RINT);
void onintr();
SEXP parseSubargs(char*, SEXP, SEXP);
void prName(SEXP);
void prValue(SEXP, int);
SEXP promiseArgs(SEXP, SEXP);
void protect(SEXP);
SEXP rep(SEXP, SEXP);
char *R_alloc(long, int);
int R_printf(char*, ...);
int Rprintf(char*, ...);
void ResetComment();
void scanPhase(void);
SEXP seq(SEXP, SEXP);
SEXP setAttrib(SEXP, SEXP, SEXP);
void setIVector(RINT*, RINT, RINT);
void setRVector(RFLOAT*, RINT, RFLOAT);
void setSVector(SEXP*, RINT, SEXP);
void setVar(SEXP, SEXP, SEXP);
SEXP setVarInFrame(SEXP, SEXP, SEXP);
SEXPTYPE str2type(char*);
void suicide(char*);
SEXP sysparent(int);
SEXP type2str(SEXPTYPE);
void unmarkPhase(void);
void unprotect(int);
char *vmaxget(void);
void vmaxset(char*);
void WrongArgCount(char*);
void warning(char*, ...);
void yyprompt(char *format, ...);
