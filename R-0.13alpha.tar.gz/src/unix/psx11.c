/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include "Defn.h"
#include "Graphics.h"
#include "psx11.h"
#include <math.h>

#define PORTRAIT	1
#define LANDSCAPE	2
#define	FLEXIBLE	3

static FILE	*psfp;			/* temporary file */
static char	filename[128];		/* temporary file name */
static double	truepagewidth;		/* unrotated page width */
static double	truepageheight;		/* unrotated page height */
static int	pageorient;		/* page orientation */
static int	canrotate;		/* free to turn page */
static double	pagewidth;		/* page width */
static double	pageheight;		/* page height */
static int	pageno;			/* page number */
static double	plotwidth;		/* plot width */
static double	plotheight;		/* plot width */
static double	xscale;			/* pixel -> points scaling */
static double	yscale;			/* pixel -> points scaling */
static double	xoffset;		/* page offset */
static double	yoffset;		/* page offset */
static short	charwidth[256][4];	/* font metrics */
static double	fontsize;		/* current font size */
static int	fontface;		/* current font face */
static rcolor	col;			/* current color */
static int	lty;			/* current lty */


void psx11_SetColor(rcolor newcol)
{
	double r, g, b;
	if(newcol != col) {
		col = newcol;
		r = ((newcol>> 8) & 255) / 255.0;
		g = ((newcol>>16) & 255) / 255.0;
		b = ((newcol>>24) & 255) / 255.0;
		fprintf(psfp,"%.4f %.4f %.4f setrgbcolor\n", r, g, b);
	}
}


void psx11_SetLinetype(int newlty)
{
	int i;
	if(newlty != lty) {
		lty = newlty;
		fprintf(psfp,"[");
		for(i=0 ; i<8 && newlty&15 ; i++) {
			fprintf(psfp," %d", newlty&15);
			newlty = newlty>>4;
		}
		fprintf(psfp,"] 0 setdash\n");
	}
}


	/* Paint the plot region in the background color */
	/* then draw a black box around it.  This looks */
	/* much spiffier than just painting the region */

static void psx11_ClearPage(col)
{
	rcolor white;
	white = RGB(255,255,255);
	if(col != white) {
		psx11_SetColor(col);
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f m\n", xoffset, yoffset);
		fprintf(psfp, "%.2f %.2f l\n", xoffset+plotwidth, yoffset);
		fprintf(psfp, "%.2f %.2f l\n", xoffset+plotwidth, yoffset-plotheight);
		fprintf(psfp, "%.2f %.2f l\n", xoffset, yoffset-plotheight);
		fprintf(psfp, "closepath fill\n");
		psx11_SetColor(0);
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f m\n", xoffset, yoffset);
		fprintf(psfp, "%.2f %.2f l\n", xoffset+plotwidth, yoffset);
		fprintf(psfp, "%.2f %.2f l\n", xoffset+plotwidth, yoffset-plotheight);
		fprintf(psfp, "%.2f %.2f l\n", xoffset, yoffset-plotheight);
		fprintf(psfp, "closepath stroke\n");
	}
}

static char *fontname[] = {
	"Helvetica",
	"Helvetica-Bold",
	"Helvetica-Oblique",
	"Helvetica-BoldOblique"
};
 
static int GetFontMetrics()
{
	FILE *fp;
	char buf[512], *rhome;
	int i, x, wx;

	if((rhome = getenv("RHOME")) == NULL)
		return 0;
	for(i=0 ; i<4 ; i++) {
		sprintf(buf, "%s/psmetrics/%s", rhome, fontname[i]);
		if((fp = fopen(buf,"r")) == NULL) return 0;
		for(x=0 ; x<256 ; x++)
			charwidth[x][i] = 0;
		while(fscanf(fp, "%d %d", &x, &wx) == 2)
			if(0 <=  x && x < 256)
				charwidth[x][i] = wx;
		fclose(fp);
	}
	return 1;
}


void psx11_SetFont(int face, int size)
{
	if(face != fontface || size != fontsize) {
		fprintf(psfp, "/%s findfont %d scalefont setfont\n",
			fontname[face-1], size);
		fontface = face;
		fontsize = size;
	}
}


int psx11_Open(char *pagetype, int orientation)
{
	if(!strcmp(pagetype, "a4") || !strcmp(pagetype, "A4")) {
		truepagewidth  = 72.0 * 21.0 / 2.54;
		truepageheight = 72.0 * 29.7 / 2.54;
	}
	else if(!strcmp(pagetype, "letter")) {
		truepagewidth  = 72.0 *  8.5;
		truepageheight = 72.0 * 11.0;
	}
	else return 0;

	switch(orientation) {
		case PORTRAIT:
			pageorient = PORTRAIT;
			pagewidth = truepagewidth; 
			pageheight = truepageheight;
			canrotate = 0;
			break;
		case LANDSCAPE:
			pageorient = LANDSCAPE;
			pagewidth = truepageheight;
			pageheight = truepagewidth;
			canrotate = 0;
			break;
		case FLEXIBLE:
			pageorient = FLEXIBLE;
			canrotate = 1;
			break;
		default:
			return 0;
	}

	psfp = NULL;
	sprintf(filename, "/tmp/Rps%d.ps", getpid());
	GetFontMetrics();
	return 1;
}


void psx11_Close()
{
	if(psfp) {
		fclose(psfp);
	}
	unlink(filename);
}

void psx11_NewPlot(int xsize, int ysize, double pw, double ph,
	int face, int size, rcolor startcol, int startlty, rcolor bg)
{
		/* compute plot dimensions in pixels */
		/* compute window -> page mappings */

	if(psfp) fclose(psfp);
	psfp = fopen(filename, "w");
	xscale = 72.0 * pw;
	yscale = 72.0 * ph;
	plotwidth  = xscale * xsize;
	plotheight = yscale * ysize;
	if(canrotate) {
		if(plotwidth < plotheight) {
			pageorient = PORTRAIT;
			pagewidth = truepagewidth;
			pageheight = truepageheight;
		}
		else {
			pageorient = LANDSCAPE;
			pagewidth = truepageheight;
			pageheight = truepagewidth;
		}
	}

	if(plotwidth > pagewidth || plotheight > pageheight)
		REprintf("warning: plot size exceeds physical page size\n");

	xoffset = 0.5 * (pagewidth - plotwidth);
	yoffset = pageheight - 0.5 * (pageheight - plotheight);
	yscale = - yscale;

	fprintf(psfp, "%%!PS-Adobe-1.0\n");
	fprintf(psfp, "%%%%DocumentFonts: Helvetica\n");
	fprintf(psfp, "%%%%Title: R Graphics Output\n");
	fprintf(psfp, "%%%%Creator: R Software\n");
	fprintf(psfp, "%%%%Pages: 1\n");
	if(pageorient == LANDSCAPE) {
		fprintf(psfp, "%%%%Orientation: Landscape\n");
		fprintf(psfp, "%%%%BoundingBox: %.2f %.2f %.2f %.2f\n",
			yoffset-plotheight,
			xoffset,
			yoffset,
			xoffset+plotwidth);
	}
	else
		fprintf(psfp, "%%%%BoundingBox: %.2f %.2f %.2f %.2f\n",
			xoffset,
			yoffset-plotheight,
			xoffset+plotwidth,
			yoffset);
	fprintf(psfp, "%%%%EndComments\n");

	fprintf(psfp, "/m { moveto } def\n");
	fprintf(psfp, "/l { lineto } def\n");
	fprintf(psfp, "/t { gsave rotate show grestore } def\n");
	fprintf(psfp, "/r { 3 index 3 index moveto 1 index 4 -1 roll\n");
	fprintf(psfp, "     lineto exch 1 index lineto lineto\n");
	fprintf(psfp, "     closepath stroke newpath } def\n");
	fprintf(psfp, "/c { initclip newpath 3 index 3 index moveto\n");
	fprintf(psfp, "     1 index 4 -1 roll lineto exch 1 index\n");
	fprintf(psfp, "     lineto lineto closepath clip newpath } def\n");
	if(pageorient == LANDSCAPE)
		fprintf(psfp, "%.2f 0 translate 90 rotate\n", pageheight);
	fprintf(psfp, "0.5 setlinewidth\n");
	fprintf(psfp, "gsave\n");

	fprintf(psfp, "%%%%EndProlog\n");
	fprintf(psfp, "%%%%Page: 1 1\n");

	fontface = 0;
	fontsize = 0;
	lty = 0;
	col = 0;
	psx11_SetFont(face, size);
	psx11_ClearPage(bg);
	psx11_SetColor(startcol);
	psx11_SetLinetype(startlty);
}

void psx11_Clip(double x0, double x1, double y0, double y1)
{
        fprintf(psfp, "%.2f %.2f %.2f %.2f c\n",
		xoffset + xscale * x0, yoffset + yscale * y0,
		xoffset + xscale * x1, yoffset + yscale * y1);
}



void psx11_StartPath()
{
        fprintf(psfp, "newpath\n");
}


void psx11_EndPath()
{
        fprintf(psfp, "stroke\n");
}


void psx11_MoveTo(double x, double y)
{
        fprintf(psfp, "%.2f %.2f m\n",
		xoffset + xscale * x, yoffset + yscale * y);
}


void psx11_LineTo(double x, double y)
{
        fprintf(psfp, "%.2f %.2f l\n",
		xoffset + xscale * x, yoffset + yscale * y);
}


static void pstext(char *str)
{
	fputc('(', psfp);
	for( ; *str ; str++)
		switch(*str) {
			case '\n':
				fprintf(psfp, "\\n");
				break;
			case '-':
				if(isdigit(str[1]))
					fputc(177, psfp);
					/* fprintf(psfp, "\\177"); */
				else
					fputc(*str, psfp);
				break;
			case '(':
			case ')':
				fprintf(psfp, "\\%c", *str);
				break;
			default:
				fputc(*str, psfp);
				break;
		}       
	fputc(')', psfp);
}

static double StrWidth(char *str)
{
        char *p;
        int sum = 0;
        for(p=str ; *p ; *p++) {
		if(*p == '-' && isdigit(p[1]))
			sum += charwidth[177][fontface];
		else
			sum += charwidth[*p][fontface];
	}
        return 0.001 * sum * fontsize;
}


static double deg2rad = 0.01745329251994329576;

void psx11_Text(double x, double y, char *str, double xc, double yc, double rot)
{
        double xoff, yoff, xl, yl, xlast, ylast;
        int size;
	x = xoffset + xscale * x;
	y = yoffset + yscale * y;
        if(xc != 0.0 || yc != 0.0) {
                xl = StrWidth(str);
                yl = fontsize;
                x += -xc * xl * cos(deg2rad * rot) + yc * yl * sin(deg2rad * rot);
                y += -xc * xl * sin(deg2rad * rot) - yc * yl * cos(deg2rad * rot);
        }
        fprintf(psfp, "%.2f %.2f m ", x, y);
        pstext(str);
        fprintf(psfp," %.0f t\n", rot);
}


void psx11_Circle(double x, double y, double r, int col, int border)
{
	if(col != NA_INTEGER) {
		psx11_SetColor(col);
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f %.2f 0 360 arc fill\n",
			xoffset + xscale * x,
			yoffset + yscale * y,
			xscale * r);
	}
	if(border != NA_INTEGER) {
		psx11_SetColor(border);
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f %.2f 0 360 arc stroke\n",
			xoffset + xscale * x,
			yoffset + yscale * y,
			xscale * r);
	}
}


void psx11_Rect(double x0, double y0, double x1, double y1, int fill)
{
	if(fill) {
		x0 = xoffset + xscale * x0;
		x1 = xoffset + xscale * x1;
		y0 = yoffset + yscale * y0;
		y1 = yoffset + yscale * y1;
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f m\n", x0, y0);
		fprintf(psfp, "%.2f %.2f l\n", x1, y0);
		fprintf(psfp, "%.2f %.2f l\n", x1, y1);
		fprintf(psfp, "%.2f %.2f l\n", x0, y1);
		fprintf(psfp, "closepath fill\n");
	}
	else {
		fprintf(psfp, "%.2f %.2f %.2f %.2f r\n", x0, y0, x1, y1);
	}
}


void psx11_Polygon(int n, double *x, double *y)
{
	int i;
	fprintf(psfp, "newpath\n");
	fprintf(psfp, "%.2f %.2f m\n",
		xoffset + xscale * x[0],
		yoffset + yscale * y[0]);
	for(i=1 ; i<n ; i++) {
		fprintf(psfp, "%.2f %.2f l\n",
			xoffset + xscale * x[i],
			yoffset + yscale * y[i]);
	}	
	fprintf(psfp, "closepath fill\n");
}


void psx11_PrintPlot()
{
	FILE *ifp, *ofp;
	char *lprcmd;
	int c;

	if(!psfp) error("no plot file present (yet)\n");
	fflush(psfp);

	if((lprcmd = getenv("R_PRINTCMD")) == NULL)
		error("don't know how to print\n");
	
	if((ofp=popen(lprcmd, "w")) == NULL)
		error("unable print plot\n");

	if((ifp=fopen(filename, "r")) == NULL) {
		fclose(ofp);
		error("unable to open plot file \"%s\"\n", filename);
	}
	while((c=fgetc(ifp)) != EOF)
		fputc(c, ofp);
	fprintf(ofp, "showpage\n");
	fprintf(ofp, "%%%%Trailer\n");
	fclose(ifp);
	pclose(ofp);
}


void psx11_SavePlot(char *name)
{
	FILE *ifp, *ofp;
	int c;

	if(!psfp) error("no plot file present (yet)\n");
	fflush(psfp);

	if((ofp=fopen(name, "w")) == NULL)
		error("unable to open output file \"%s\" for plot\n", name);
	if((ifp=fopen(filename, "r")) == NULL) {
		fclose(ofp);
		error("unable to open plot file \"%s\"\n", filename);
	}
	while((c=fgetc(ifp)) != EOF)
		fputc(c, ofp);
	fprintf(ofp, "showpage\n");
	fprintf(ofp, "%%%%Trailer\n");
	fclose(ofp);
	fclose(ifp);
}
