/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

/* functions to perform analogues of the standard C string library */
/* most will be vectorized */

SEXP do_nchar(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, x;
	int i, len;

	checkArity(op, args);
	x = CAR(args);
	if (!isString(x))
		error("invalid type, nchar requires a character vector\n");
	len = LENGTH(x);
	PROTECT(s = allocVector(INTSXP, len));
	for (i = 0; i < len; i++)
		INTEGER(s)[i] = strlen(CHAR(STRING(x)[i]));
	UNPROTECT(1);
	return s;
}
static void substr(char *buf, char *str, int sa, int so)
{
	int i;

	str += (sa - 1);
	for (i = 0; i <= (so - sa); i++)
		*buf++ = *str++;
	*buf = '\0';
}

SEXP do_substr(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, x, sa, so;
	int i, len, start, stop, slen, k, l;
	char buff[MAXELTSIZE];

	checkArity(op, args);
	x = CAR(args);
	sa = CADR(args);
	so = CAR(CDDR(args));

	if (!isString(x) || !isInteger(sa) || !isInteger(so))
		error("invalid type to substr\n");

	len = LENGTH(x);
	k = LENGTH(sa);
	l = LENGTH(so);
	PROTECT(s = allocVector(STRSXP, len));
	for (i = 0; i < len; i++) {
		start = INTEGER(sa)[i % k];
		stop = INTEGER(so)[i % l];
		slen = strlen(CHAR(STRING(x)[i]));
		if (start > stop)
			error("substr: start must be smaller than stop\n");
		if (start > slen)
			STRING(s)[i] = NA_STRING;
		else {
			if (stop > slen)
				stop = slen;
			substr(buff, CHAR(STRING(x)[i]), start, stop);
			STRING(s)[i] = mkChar(buff);
		}
	}
	UNPROTECT(1);
	return s;
}

/* strsplit is going to split the strings in the first argument
   into tokens depending on the second argument. The characters
   of the second argument are used to split the first argument.
   A list of vectors is returned of lenght equal to the input vector x, 
   each element of the list is the collection of splits for the corresponding
   element of x.
 */
SEXP do_strsplit(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t, x, tok, w;
	int i, j, len, tlen, ntok;
	char buff[MAXELTSIZE], *pt;

	checkArity(op, args);
	x = CAR(args);
	tok = CADR(args);

	if (!isString(x) || !isString(tok))
		error("invalid type to strsplit\n");

	len = LENGTH(x);
	tlen = LENGTH(tok);
	PROTECT(s = allocList(len));
	w = s;
	for (i = 0; i < len; i++) {
		/* first find out how many splits there will be */
		strcpy(buff, CHAR(STRING(x)[i]));
		pt = strtok(buff, CHAR(STRING(tok)[i % tlen]));
		ntok = 1;
		while ((pt = strtok(NULL, CHAR(STRING(tok)[i % tlen]))) != NULL)
			ntok++;
		PROTECT(t = allocVector(STRSXP, ntok));
		strcpy(buff, CHAR(STRING(x)[i]));
		pt = strtok(buff, CHAR(STRING(tok)[i % tlen]));
		for (j = 0; j < ntok; j++) {
			STRING(t)[j] = mkChar(pt);
			pt = strtok(NULL, CHAR(STRING(tok)[i % tlen]));
		}
		CAR(w) = t;
		UNPROTECT(1);
		w = CDR(w);
	}
	UNPROTECT(1);
	return s;
}
