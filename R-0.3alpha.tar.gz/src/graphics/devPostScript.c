/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"

void error(char*);
int ValidColor(unsigned int);

static char *filename;
static int pageno;
static int landscape;
static double width;
static double height;
static double pagewidth;
static double pageheight;
static double xlast;
static double ylast;
static int lty;
static rcolor col;
static rcolor fg;
static rcolor bg;
static double cex;

static FILE *psfp;

static char *pstart[] = {
#include "devPostScript.h"
	NULL
};

static void SetColor(unsigned color)
{
	double r, g, b;
	col = color;
	r = ((color>> 8)&255)/255.0;
	g = ((color>>16)&255)/255.0;
	b = ((color>>24)&255)/255.0;
	fprintf(psfp,"%f %f %f setrgbcolor\n", r, g, b);
}

static void SetLineType(int newlty)
{
	int i;
	lty = newlty;

	fprintf(psfp,"[");
	for(i=0 ; i<8 && newlty&15 ; i++) {
		fprintf(psfp," %d", newlty&15);
		newlty = newlty>>4;
	}
	fprintf(psfp,"] 0 setdash\n");
}

#ifdef FULLPAGE
#  define BOTTOM 0.0
#  define LEFT 0.0
#  define TOP (72.0*pageheight)
#  define RIGHT (72.0*pagewidth)
#else
#  define BOTTOM 0.01*GP->bottom
#  define LEFT 0.01*GP->left
#  define TOP 0.01*GP->top
#  define RIGHT 0.01*GP->right
#endif

static void ClearPage()
{
	/* inlining the RGB(255,255,255) */
	/* in the != trips a Sun compiler bug */

	rcolor white = RGB(255,255,255);
	if(DP->bg != white) {
		if(col != DP->bg) SetColor(DP->bg);
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f m\n", LEFT, BOTTOM);
		fprintf(psfp, "%.2f %.2f l\n", RIGHT, BOTTOM);
		fprintf(psfp, "%.2f %.2f l\n", RIGHT, TOP);
		fprintf(psfp, "%.2f %.2f l\n", LEFT, TOP);
		fprintf(psfp, "closepath fill\n");
	}
}

/* Initialize the device */

static int PS_Open(void)
{
	int i;
	if(!(psfp = fopen(filename, "w"))) return 0;
	fprintf(psfp, "%%!PS-Adobe-1.0\n");
	fprintf(psfp, "%%%%DocumentFonts: Helvetica\n");
	fprintf(psfp, "%%%%Title: R Graphics Output\n");
	fprintf(psfp, "%%%%Creator: R Software\n");
	fprintf(psfp, "%%%%Pages: (atend)\n");
	fprintf(psfp, "%%%%BoundingBox: %d %d %d %d\n",
		GP->left/100, GP->bottom/100, GP->right/100, GP->top/100);
	fprintf(psfp, "%%%%EndComments\n");
	if(landscape)
		fprintf(psfp, "%.2f 0 translate 90 rotate\n", 72 * pageheight);
	fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", 10.0);
	fprintf(psfp, "0.5 setlinewidth\n");
	fprintf(psfp, "gsave\n");
	for( i=0 ; pstart[i] ; i++ )
		fprintf(psfp, "%s\n",pstart[i]);
	fprintf(psfp, "%%%%EndProlog\n");
	fprintf(psfp, "%%%%Page: 1 1\n");
	ClearPage();
	return 1;
}

/* Set the clipping rectangle */
static void PS_Clip(int x0, int x1, int y0, int y1)
{
	fprintf(psfp, "%.2f %.2f %.2f %.2f c\n", 0.01*x0, 0.01*y0, 0.01*x1, 0.01*y1);
}


/* Interactive Resize */
static void PS_Resize()
{
}

/* Start a new page */
static void PS_NewPlot()
{
	++pageno;
	fprintf(psfp, "showpage\n");
	fprintf(psfp, "%%%%Page: %d %d\n", pageno, pageno);
	fprintf(psfp, "grestore gsave\n");
	fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", cex*10.0);
	ClearPage();
}

/* Close down the driver */
static void PS_Close(void)
{
	fprintf(psfp, "showpage\n");
	fprintf(psfp, "%%%%Trailer\n");
	fprintf(psfp, "%%%%Pages: %d\n", pageno);
	fclose(psfp);
}


/* Seek */
static void PS_MoveTo(int x, int y)
{
	if(GP->col != col) SetColor(GP->col);
	fprintf(psfp, "%.2f %.2f m\n", 0.01*x, 0.01*y);
	xlast = x;
	ylast = y;
}


/* Centered Dot */
static void PS_Dot(void)
{
}


/* Draw To */
static void PS_LineTo(int x, int y)
{
	if(lty != GP->lty) SetLineType(GP->lty);
	fprintf(psfp, "%.2f %.2f l\n", 0.01*x, 0.01*y);
}


/* Start a Path */
static void PS_LStart()
{
	fprintf(psfp, "newpath\n");
}


/* End a Path */
static void PS_LEnd()
{
	fprintf(psfp, "stroke\n");
}


/* Possibly Filled Rectangle */
static void PS_Rect(int x0, int y0, int x1, int y1, int fill)
{
	if (GP->col != col) SetColor(GP->col);
	if(lty != GP->lty) SetLineType(GP->lty);
	if(fill) {
		fprintf(psfp, "newpath\n");
		fprintf(psfp, "%.2f %.2f m\n", 0.01*x0, 0.01*y0);
		fprintf(psfp, "%.2f %.2f l\n", 0.01*x1, 0.01*y0);
		fprintf(psfp, "%.2f %.2f l\n", 0.01*x1, 0.01*y1);
		fprintf(psfp, "%.2f %.2f l\n", 0.01*x0, 0.01*y1);
		fprintf(psfp, "closepath fill\n");
	}
	else {
		fprintf(psfp, "%.2f %.2f %.2f %.2f r\n", 0.01*x0, 0.01*y0, 0.01*x1, 0.01*y1);
	}
}

static void PS_Polygon(int n, int *x, int *y)
{
	int i;
	if (GP->col != col) SetColor(GP->col);
	if (GP->lty != lty) SetLineType(GP->lty);
	fprintf(psfp, "newpath\n");
	fprintf(psfp, "%.2f %.2f m\n", 0.01*x[0], 0.01*y[0]);
	for(i=1 ; i<n ; i++) {
		fprintf(psfp, "%.2f %.2f l\n", 0.01*x[i], 0.01*y[i]);
	}
	fprintf(psfp, "closepath fill\n");
}

/* PostScript Text Translations */
static void pstext(char *str)
{
	fputc('(', psfp);
	for( ; *str ; str++)
		switch(*str) {
			case '\n':
				fprintf(psfp, "\\n");
				break;
			case '-':
				fprintf(psfp, "\\261");
				break;
			case '(':
			case ')':
				fprintf(psfp, "\\%c", *str);
				break;
			default:
				fputc(*str, psfp);
				break;
		}
	fputc(')', psfp);
}


/* Plain Text */
static void PS_Text(char *str, double xc, double yc)
{
	if(cex != GP->cex) {
		cex = GP->cex;
		fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", cex*10.0);
	}
	if (GP->col != col) SetColor(GP->col);
	pstext(str);
	fprintf(psfp," %.2f %.2f t\n", xc, yc);
}


/* Rotated Text */
static void PS_RText(char *str, double xc, double yc, int rot)
{
	if(cex != GP->cex) {
		cex = GP->cex;
		fprintf(psfp, "/Helvetica findfont %.2f scalefont setfont\n", cex*10.0);
	}
	if (GP->col != col) SetColor(GP->col);
	pstext(str);
	fprintf(psfp," %.2f %.2f %d tr\n", xc, yc, rot);
}


/* Pick */
static int PS_Locator(int *x, int *y)
{
	return 0;
}


/* Set Graphics mode - not needed for PS */
static void PS_Mode(int mode)
{
}

/* GraphicsInteraction() for the Mac */
static void PS_Hold()
{
}

#define A4 1

int PSDeviceDriver(char **cpars, int ncpars, double *npars, int nnpars)
{
	double xoff, yoff;
	char *pagetype;
	DevInit = 0;

	if(ncpars != 2 || nnpars != 5)
		error("invalid device parameters (postscript)\n");

	filename = cpars[0];
	pagetype = cpars[1];
	width = npars[0];
	height = npars[1];
	landscape = npars[2];
	bg = npars[3];
	fg = npars[4];
	if(!(ValidColor(bg) && ValidColor(fg)))
		error("invalid foreground/background color (postscript)\n");
	DP->bg = GP->bg = bg;
	DP->fg = GP->fg = fg;

	if(!strcmp(pagetype, "A4")) {
		pagewidth  = 21.0/2.54;
		pageheight = 29.7/2.54;
	}
	else if(!strcmp(pagetype, "letter")) {
		pagewidth  =  8.5;
		pageheight = 11.0;
	}
	else if(!strcmp(pagetype, "legal")) {
		pagewidth  =  8.5;
		pageheight = 14.0;
	}
	else if(!strcmp(pagetype, "executive")) {
		pagewidth  =  7.25;
		pageheight = 10.5;
	}
	else
		error("invalid page type (postscript)\n");

	if(landscape) {
		double tmp;
		tmp = pagewidth;
		pagewidth = pageheight;
		pageheight = tmp;;
	}

	if(width < 3.0 || width > pagewidth-0.5)
		width = pagewidth-0.5;
	if(height < 3.0 || height > pageheight-0.5)
		height = pageheight-0.5;
	xoff = (pagewidth - width)/2.0;
	yoff = (pageheight - height)/2.0;

	DevOpen = PS_Open;
	DevClose = PS_Close;
	DevResize = PS_Resize;
	DevNewPlot = PS_NewPlot;
	DevClip = PS_Clip;
	DevStartPath = PS_LStart;
	DevEndPath = PS_LEnd;
	DevMoveTo = PS_MoveTo;
	DevLineTo = PS_LineTo;
	DevText = PS_Text;
	DevRText = PS_RText;
	DevDot = PS_Dot;
	DevRect = PS_Rect;
	DevPolygon = PS_Polygon;
	DevLocator = PS_Locator;
	DevMode = PS_Mode;
	DevHold = PS_Hold;

		/* Screen Dimensions in Pixels */

	GP->left = 7200 * xoff;			/* left */
	GP->right = 7200 * (xoff + width); 	/* right */
	GP->bottom = 7200 * yoff;		/* bottom */
	GP->top = 7200 * (yoff + height);	/* top */

	if( ! PS_Open() ) return 0;


		/* Nominal Character Sizes in Pixels */

	GP->cra[0] =  6.0 * 100.0;
	GP->cra[1] = 10.0 * 100.0;

		/* Character Addressing Offsets */
		/* These offsets should center a single */
		/* plotting character over the plotting point. */
		/* Pure guesswork and eyeballing ... */

	GP->xCharOffset =  2.0/3.0;
	GP->yCharOffset =  2.0/3.0;

			/* Inches per Raster Unit */

	GP->ipr[0] = 0.01/72.0;
	GP->ipr[1] = 0.01/72.0;

	GP->canResizePlot = 0;
	GP->canChangeFont = 1;
	GP->canRotateText = 1;
	GP->canResizeText = 1;
	GP->canClip = 1;

	lty = 1;
	pageno = 1;
	cex = 1.0;

	DevInit = 1;
	return 1;
}
