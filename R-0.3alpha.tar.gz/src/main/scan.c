/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

/* The size of vector initially allocated by scan */
#define SCAN_BLOCKSIZE 1000

static int save = 0;
static int sepchar = 0;
static FILE *fp;
static int ttyflag;

static int scanchar(void)
{
	if(save) {
		int c = save;
		save = 0;
		return c;
	}
	return (ttyflag) ? cget() : fgetc(fp);
}

static void unscanchar(int c)
{
	save = c;
	/* ttyflag ? uncget(c) : ungetc(c, fp); */
}

static void fillBuffer(char *buffer, SEXPTYPE type)
{
	char *bufp = buffer;
	int c, quote;

	if(sepchar == 0) {
		c = scanchar();
		if(type == STRSXP && c == '\"' || c == '\'') {
			quote = c;
			while ((c = scanchar()) != EOF && c != quote) {
				if(bufp >= &buffer[MAXELTSIZE - 2])
					continue;
				if (c == '\\') {
					c = scanchar();
					if(c == EOF) break;
					else if (c == 'n') c = '\n';
					else if (c == 'r') c = '\r';
				}
				*bufp++ = c;
			}
		}
		else {
			do {
				if(bufp >= &buffer[MAXELTSIZE - 2])
					continue;
				*bufp++ = c;
			} while (!isspace(c = scanchar()) && c != EOF);
			unscanchar(c);
		}
	}
	else {
		while((c = scanchar()) != sepchar && c != EOF && c != '\n') {
			if(bufp >= &buffer[MAXELTSIZE - 2])
				continue;
			*bufp++ = c;
		}
		unscanchar(c);
	}
	*bufp = '\0';
}

static int NAstring(char *buf)
{
	if (!strcmp("NA", buf) || !strcmp("", buf) || !strcmp(".", buf))
		return 1;
	else
		return 0;
}

static void expected(char *what, char *got)
{
	int c;

	if(ttyflag) {
		while((c = scanchar()) != EOF && c != '\n')
			;
	}
	else fclose(fp);
	error("\"scan\" expected %s got \"%s\"\n", what, got);
}

static SEXP extractItem(char *buffer, SEXP ans, int i)
{
	char *endp;

	switch(TYPEOF(ans)) {
		case LGLSXP:
			LOGICAL(ans)[i] = StringTrue(buffer);
			break;
		case FACTSXP:
		case ORDSXP:
			if(!ttyflag) fclose(fp);
			error("can't scan factors (yet)\n");
		case INTSXP:
			if (NAstring(buffer))
				INTEGER(ans)[i] = NA_INTEGER;
			else {
				INTEGER(ans)[i] = strtol(buffer, &endp, 10);
				if (*endp != '\0')
					expected("an integer", buffer);
			}
			break;
		case REALSXP:
			if (NAstring(buffer))
				REAL(ans)[i] = NA_REAL;
			else {
				REAL(ans)[i] = strtod(buffer, &endp);
				if (*endp != '\0')
					expected("a real", buffer);
			}
			break;
		case STRSXP:
			STRING(ans)[i] = mkChar(buffer);
			break;
	}
}

static SEXP scanVector(SEXPTYPE type, int maxitems, int maxlines)
{
	SEXP ans, bns;
	int blocksize, c, first, i, n, linesread, nprev;
	char buffer[MAXELTSIZE];

	if(maxitems > 0) blocksize = maxitems;
	else blocksize = SCAN_BLOCKSIZE;

	PROTECT(ans = allocVector(type, blocksize));

	nprev = -1; n = 0; linesread = 0, first = 1;

	if (ttyflag) REprintf("1: ");

	if(sepchar) {
		for(;;) {
			fillBuffer(buffer, type);

			if(first && *buffer == '\0')
				if((ttyflag && c == '\n') || c == EOF)
					break;

			if (n == blocksize) {
				/* enlarge the vector*/
				bns = ans;
				blocksize = 2 * blocksize;
				ans = allocVector(type, blocksize);
				UNPROTECT(1);
				PROTECT(ans);
				copyVector(ans, bns);
			}

			extractItem(buffer, ans, n);

			if(++n == maxitems) {
				if(ttyflag) {
					while((c=scanchar()) != '\n')
						;
				}
				break;
			}

			if((c = scanchar()) == EOF)
				break;
			else if(c == '\n') {
				linesread++;
				if (linesread == maxlines)
					break;
				if (ttyflag) {
					REprintf("%d: ", n+1);
				}
				first = 1;
			}
			else first = 0;
		}
	}
	else {
		for(;;) {
			while ((c = scanchar()) == ' ' || c == '\t')
				;
			if (c == EOF) {
				if(ttyflag) ClearerrConsole();
				break;
			}
			else if (c == '\n') {
				linesread++;
				if (n == nprev || linesread == maxlines)
					break;
				if (ttyflag) {
					REprintf("%d: ", n + 1);
					nprev = n;
				}
			}
			else {
				unscanchar(c);
				if (n == blocksize) {
					/* enlarge the vector*/
					bns = ans;
					blocksize = 2 * blocksize;
					ans = allocVector(type, blocksize);
					UNPROTECT(1);
					PROTECT(ans);
					copyVector(ans, bns);
				}
				fillBuffer(buffer, type);
				extractItem(buffer, ans, n);
				if(++n == maxitems) {
					if(ttyflag) {
						while((c=scanchar()) != '\n')
							;
					}
					break;
				}
			}
		}
	}
	REprintf("Read %d items\n", n);

	if (n == 0) {
		UNPROTECT(1);
		return R_NilValue;
	}
	if (n == maxitems) {
		UNPROTECT(1);
		return ans;
	}

	bns = allocVector(type, n);
	switch (type) {
	case LGLSXP:
	case INTSXP:
		for (i = 0; i < n; i++)
			INTEGER(bns)[i] = INTEGER(ans)[i];
		break;
	case REALSXP:
		for (i = 0; i < n; i++)
			REAL(bns)[i] = REAL(ans)[i];
		break;
	case STRSXP:
		for (i = 0; i < n; i++)
			STRING(bns)[i] = STRING(ans)[i];
		break;
	}
	UNPROTECT(1);
	return bns;
}

static SEXP scanFrame(SEXP what, int maxitems, int maxlines)
{
	SEXP a, ans, b, bns, new, old, w;
	char buffer[MAXELTSIZE];
	int blksize, c, i, j, n, nc, linesread;

	nc = length(what);

	if(maxitems > 0) blksize = maxitems;
	else blksize = SCAN_BLOCKSIZE;

	PROTECT(ans = allocList(nc));
	a = ans;
	w = what;
	for (i = 0; i < nc; i++) {
		if (!isVector(CAR(w))) {
			if (!ttyflag) fclose(fp);
			error("\"scan\" invalid \"what=\" specified\n");
		}
		CAR(a) = allocVector(TYPEOF(CAR(w)), blksize);
		TAG(a) = TAG(w);
		a = CDR(a);
		w = CDR(w);
	}

	n = 0; linesread = 0;

	if (ttyflag) REprintf("1: ");

	if(sepchar) {
		for(;;) {
			a = ans;
			for(i = 0 ; i< nc ; i++) {

				fillBuffer(buffer, TYPEOF(CAR(a)));

				if(i == 0 && buffer[0] == '\0')
					if((ttyflag && save == '\n')
							|| save == EOF)
						goto done;

				if (n == blksize) {
					old = CAR(a);
					blksize = 2 * blksize;
					new = allocVector(TYPEOF(old), blksize);
					copyVector(new, old);
					CAR(a) = new;
				}

				extractItem(buffer, CAR(a), n);

				if(i < nc-1 && (save == EOF || save == '\n')) {
					if (!ttyflag) fclose(fp);
					error("ragged structure in scan\n");
				}
				a = CDR(a);
				c = scanchar();
			}

			if(++n == maxitems) {
				if(ttyflag) {
					while(c != '\n')
						c = scanchar();
				}
				break;
			}

			if(c == sepchar) {
				if (!ttyflag) fclose(fp);
				error("ragged structure in scan\n");
			}
			else if(c == EOF) {
				break;
			}
			else if(c == '\n') {
				if(++linesread == maxlines)
					break;
				if(ttyflag) REprintf("%d: ", n + 1);
				
			}
		}
	}
	else {
		for(;;) {
			a = ans;

			while ((c = scanchar()) == ' ' || c == '\t')
				;
			if (c == EOF) {
				if(ttyflag) ClearerrConsole();
				goto done;
			}
			else if (c == '\n') {
				goto done;
			}
			unscanchar(c);

			if (n == blksize) {
				b = ans;
				for (i = 0; i < nc; i++) {
					old = CAR(b);
					blksize = 2 * blksize;
					new = allocVector(TYPEOF(old), blksize);
					copyVector(new, old);
					CAR(b) = new;
					b = CDR(b);
				}
			}

			for (i = 0; i < nc; i++) {
				while (isspace(c = scanchar()))
					if (c == '\n' || c == EOF) {
						if (!ttyflag) fclose(fp);
						error("ragged structure in scan\n");
					}
				unscanchar(c);
				fillBuffer(buffer, TYPEOF(CAR(a)));
				extractItem(buffer, CAR(a), n);
				a = CDR(a);
			}
			n++;
			while ((c = scanchar()) != '\n' && c != EOF);
			linesread++;
			if (c == EOF || linesread == maxlines)
				goto done;
			if (c == '\n' && ttyflag)
				REprintf("%d: ", n + 1);
		}
	}

done:
	if (!ttyflag)
		fclose(fp);
	REprintf("Read %d lines\n", n);

	if (n == maxitems) {
		UNPROTECT(1);
		return ans;
	}

	a = ans;
	for (i = 0; i < nc; i++) {
		old = CAR(a);
		new = allocVector(TYPEOF(old), n);
		switch (TYPEOF(old)) {
		case LGLSXP:
		case INTSXP:
			for (j = 0; j < n; j++)
				INTEGER(new)[j] = INTEGER(old)[j];
			break;
		case REALSXP:
			for (j = 0; j < n; j++)
				REAL(new)[j] = REAL(old)[j];
			break;
		case STRSXP:
			for (j = 0; j < n; j++)
				STRING(new)[j] = STRING(old)[j];
			break;
		}
		CAR(a) = new;
		a = CDR(a);
	}
	UNPROTECT(1);
	return ans;
}

SEXP do_scan(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP ans, file, sep, what;
	int i, c, nlines, nmax, nskip, type;
	char *filename;

	checkArity(op, args);
	file = CAR(args); args = CDR(args);
	what = CAR(args); args = CDR(args);
	nmax = asInteger(CAR(args)); args = CDR(args);
	sep = CAR(args); args = CDR(args);
	nskip = asInteger(CAR(args)); args = CDR(args);
	nlines = asInteger(CAR(args)); args = CDR(args);

	if (nskip < 0 || nskip == NA_INTEGER) nskip = 0;
	if (nlines < 0 || nlines == NA_INTEGER) nlines = 0;
	if (nmax < 0 || nmax == NA_INTEGER) nmax = 0;

	if(isString(sep) || isNull(sep)) {
		if(LENGTH(sep) == 0) sepchar = 0;
		else sepchar = CHAR(STRING(sep)[0])[0];
	}
	else errorcall(call, "invalid sep value\n");

	if (isNull(file))
		filename = NULL;
	else if (isString(file)) {
		filename = CHAR(*STRING(file));
		if (strlen(filename) == 0)
			filename = NULL;
	}
	else errorcall(call, "\"scan\" file name required\n");

	if (filename) {
		ttyflag = 0;
		if ((fp = fopen(filename, "r")) == 0)
			error("\"scan\" can't open file\n");
		for (i = 0; i < nskip; i++)
			while ((c = scanchar()) != '\n' && c != EOF);
	}
	else ttyflag = 1;

	save = 0;

	switch (TYPEOF(what)) {
	case LGLSXP:
	case FACTSXP:
	case ORDSXP:
	case INTSXP:
	case REALSXP:
	case STRSXP:
		ans = scanVector(TYPEOF(what), nmax, nlines);
		break;
	case LISTSXP:
		ans = scanFrame(what, nmax, nlines);
		break;
	default:
		if (!ttyflag) fclose(fp);
		error("\"scan\" invalid \"what=\" specified\n");
	}
	if (!ttyflag)
		fclose(fp);
	return ans;
}
