/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <math.h>

void rsort(double*, int);

static int polish(double *z, double *y, double *r, double *c, double *t,
	int nr, int nc, double *sum)
{
	int i, j;
	double delta, rdelta, cdelta;

	*sum = 0.0;

	for( i=0 ; i<nr ; i++ ) {
		for( j=0 ; j<nc ; j++ )
			y[j] = z[i+j*nr];
		rsort(y,nc);
		rdelta = 0.5*(y[(int)(0.50*nc+0.75)-1]+y[(int)(0.50*nc+1.25)-1]);
		for( j=0 ; j<nc ; j++ )
			z[i+j*nr] -= rdelta;
		r[i] += rdelta;
	}

	for( j=0 ; j<nc ; j++ )
		y[j] = c[j];
	rsort(y, nc);
	delta = 0.5*(y[(int)(0.50*nc+0.75)-1]+y[(int)(0.50*nc+1.25)-1]);
	for( j=0 ; j<nc ; j++ )
		c[j] -= delta;
	*t += delta;

	for( j=0 ; j<nc ; j++ ) {
		for( i=0 ; i<nr ; i++ )
			y[i] = z[i+j*nr];
		rsort(y,nr);
		cdelta = 0.5*(y[(int)(0.50*nr+0.75)-1]+y[(int)(0.50*nr+1.25)-1]);
		for( i=0 ; i<nr ; i++ ) {
			z[i+j*nr] -= cdelta;
			*sum += fabs(z[i+j*nr]);
		}
		c[j] += cdelta;
	}

	for( i=0 ; i<nr ; i++ )
		y[i] = r[i];
	rsort(y,nr);
	delta = 0.5*(y[(int)(0.50*nr+0.75)-1]+y[(int)(0.50*nr+1.25)-1]);
	for( i=0 ; i<nr ; i++ )
		r[i] -= delta;
	*t += delta;
	return 0;
}


int medpolish(double *x, int *pnr, int *pnc, double *t, double *r, double *c,
	double *z, double *y, double *f)
{
	int i, j, ij, nr, nc, n;
	double amed, oldsum, sum;
	double eps = .01;

	nr = *pnr;
	nc = *pnc;
	n = nr*nc;

	*t = 0;
	oldsum = 0.0;
	for( i=0 ; i<nr ; i++ ) r[i] = 0.0;
	for( j=0 ; j<nc ; j++ ) c[j] = 0.0;
	for( i=0 ; i<n ; i++ ) z[i] = x[i];

	do {
		polish(z, y, r, c, t, nr, nc, &sum);
		/*
		printReal(sum);
		printNewLine(1);
		*/
		if(fabs(1.0-oldsum/sum) < eps) break;
		oldsum = sum;
	} while(1);

	for( i=0 ; i<n ; i++ )
			y[i] = x[i];
	amed = 0.5*(y[(int)(0.50*n+0.75)-1]+y[(int)(0.50*n+1.25)-1]);
	sum = 0.0;
	for( i=0 ; i<n ; i++ )
		sum += fabs(y[i]-amed);
	/*
	printReal(sum);
	printNewLine(1);
	*/
	for( i=0 ; i<nr ; i++ ) 
		for( j=0 ; j<nc ; j++ ) {
			ij = i+j*nr;
			y[ij] = r[i]*c[j]/ *t;
			f[ij] = *t+r[i]+c[j];
		}
	return 0;
}
