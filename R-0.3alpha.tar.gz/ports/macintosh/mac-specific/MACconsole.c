/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "MACconsole.h"
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include "Defn.h"

/* Interface */

CursHandle		iBeam;
CursHandle		cross;
CursHandle		plus;
CursHandle		watch;
Rect			dragRect;

MenuHandle		appleMenu;
MenuHandle		fileMenu;
MenuHandle		editMenu;
MenuHandle		graphMenu;

WindowContext	*activeContext;
WindowContext	stdioContext;
WindowContext	graphContext;
WindowContext	editorContext; 
WindowContext	spreadContext;

TEHandle		scrollText;
ControlHandle	scrollVScroll;
ControlHandle	scrollHScroll;
int				scrollLines;


/* Implementation */

static void InitContext(WindowContext *theContext)
{
	theContext->theWindow = NULL;
	theContext->active = 0;
}

void WatchCursor()
{
	SetCursor(*watch);
}

void ArrowCursor()
{
	SetCursor(&qd.arrow);
}

void IBeamCursor()
{
	SetCursor(*iBeam);
}

static void SetupCursors(void)
{	
	iBeam = GetCursor(iBeamCursor);
	cross = GetCursor(crossCursor);
	plus = GetCursor(plusCursor);
	watch = GetCursor(watchCursor);
}

static void SetupMenus(void)
{
	InsertMenu(appleMenu = NewMenu(1, "\p\024"), 0);
	AppendMenu(appleMenu, "\pAbout R ...;(-");
	AddResMenu(appleMenu, 'DRVR');
	
	InsertMenu(fileMenu = NewMenu(2, "\pFile"), 0);
	AppendMenu(fileMenu, "\p(New/N;Open/O;Save/S;Load/L;(-;Page Setup...;Print.../P;(-;Quit/Q");
	
	InsertMenu(editMenu = NewMenu(3, "\pEdit"), 0);
	AppendMenu(editMenu, "\p(Undo/Z;(-;Cut/X;Copy/C;Paste/V;Clear");

	DrawMenuBar();
}

extern int	R_Unnamed;
extern int	R_DirtyImage;
extern char	R_ImageName[256];

static Point SFGwhere = {90, 82};
static Point SFPwhere = {106, 104};
static SFReply reply;

void menuOpen(void)
{
	char fn[256];
	int vRef;
	VolumeParam PBlock;
	SFTypeList myTypes;
	int i;
	
	myTypes[0] = 'RIMG';
	SFGetFile(SFGwhere, "\p", 0L, 1, myTypes, 0L, &reply);
	if(!reply.good)
		return;
	for(i=0 ; i<reply.fName[0] ; i++)
		fn[i] = reply.fName[i+1];
	fn[i] = '\0';
	PBlock.ioVRefNum=reply.vRefNum;
	PBlock.ioNamePtr= reply.fName;
	PBlock.ioCompletion=0;
	if(PBSetVol((ParmBlkPtr)&PBlock, FALSE) != noErr)
		error("load: couldn't open requested file\n");
	printf("restore(\"%s\")\n", fn);
	HiliteMenu(0);
	restore_image(fn);
}

extern SEXP parse(FILE*,int);

void menuLoad(void)
{
	char fn[256];
	int i;
	FILE *fp;
	VolumeParam PBlock;
	SFTypeList myTypes;
	SEXP expr;
	
	myTypes[0] = 'TEXT';
	SFGetFile(SFGwhere, "\p", 0L, 1, myTypes, 0L, &reply);
	if(!reply.good)
		return;
	for(i=0 ; i<reply.fName[0] ; i++)
		fn[i] = reply.fName[i+1];
	fn[i] = '\0';
	/* for some reason Think C doesn't update the current vol immediately
	    so we have to
	*/
	PBlock.ioVRefNum=reply.vRefNum;
	PBlock.ioNamePtr= reply.fName;
	PBlock.ioCompletion=0;
	if( PBSetVol((ParmBlkPtr)&PBlock,FALSE) != noErr )
		error("load: couldn't open requested file\n");
	fp=fopen(fn,"r");
	if( !fp )
		error("load: couldn't open requested file\n");
	HiliteMenu(0);
	SetCursor(*watch);
	Rprintf("\n");
	PROTECT(expr=parse(fp, -1));
	if( ParseError )
		error("load: an error occurred in parsing\n");
	for( expr; expr!=nilValue ; expr=CDR(expr) )
		eval(CAR(expr),globalEnv);
	UNPROTECT(1);
	yyprompt((char *) CHAR(R_options_prompt));
	SetCursor(&qd.arrow);
}

void menuSave(int jump)
{
	char fn[256];
	VolumeParam PBlock;
	int i;
	
	strcpy(fn, R_ImageName);
	SFPutFile(SFPwhere, "\pSave file as", CtoPstr(fn), 0L, &reply);
	if(!reply.good)
		return;
	R_Unnamed = 0;
	for(i=0 ; i<reply.fName[0] ; i++)
		fn[i] = reply.fName[i+1];
	fn[i] = '\0';
	PBlock.ioVRefNum=reply.vRefNum;
	PBlock.ioNamePtr= reply.fName;
	PBlock.ioCompletion=0;
	if( PBSetVol((ParmBlkPtr)&PBlock,FALSE) != noErr )
		error("save: cannot save to requested location\n");
	printf("dump(\"%s\")\n", fn);
	HiliteMenu(0);
	WatchCursor();
	sysdump(fn);
	if(jump)
		jump_to_toplevel();
}

void menuNew()
{
	DialogPtr procdlg;
	EventRecord theEvent;
	short whichItem, type;
	Rect box;
	ControlHandle chand1, chand2;
	
	if(R_DirtyImage) {
		procdlg=GetNewDialog(130,0L,(WindowPtr)-1L);
		GetDItem(procdlg,(short)1,&type,(Handle*)&chand1,&box);
		GetDItem(procdlg,(short)2,&type,(Handle*)&chand2,&box);
		SetCtlValue(chand1,1);
		SetCtlValue(chand2,0);
		ShowWindow(procdlg);
		
		whichItem=0;
		while(whichItem !=1 && whichItem !=2 ) 
			ModalDialog(0,&whichItem);
		CloseDialog(procdlg);
		if(whichItem==2)
			return;
    }
    globalEnv=emptyEnv();
}
		


static char line1[] = "R - A Language and Environment for Data Analysis";
static char line2[] = "Copyright 1993,1994";
static char line3[] = "by Robert Gentleman and Ross Ihaka";
static char line4[] = "Wonder Hackers, Graphics Wizards";
static char line5[] = "and All-Round Swell Guys";
/*
static char line4[] = "The University we work for";
static char line5[] = "doesn't pay us enough to get a mention here.";
*/
/*
static char line3[] = "Statistics Department, University of Auckland";
static char line4[] = "Auckland";
static char line5[] = "New Zealand";
*/
 

void AboutWindow(void)
{
	long dummy;
	Rect creditR;
	Rect lineR;
	GrafPtr port;
	WindowPtr creditW;
	EventRecord anEvent;
	
	GetPort(&port);
	SetRect(&lineR,5,5,345,20);
	SetRect(&creditR,75,120,425,220);
	creditW = NewWindow((Ptr)0, &creditR, (void*)0,true, dBoxProc, (WindowPtr)-1, true, 0);
	SetPort(creditW);
	
	TextSize(12);
	TextFont(0);
	TextBox(line1, strlen(line1), &lineR, 1);
	OffsetRect(&lineR, 0, 20);
	TextBox(line2, strlen(line2), &lineR, 1);
	OffsetRect(&lineR, 0, 20);
	TextBox(line3, strlen(line3), &lineR, 1);
	OffsetRect(&lineR, 0, 20);
	TextBox(line4, strlen(line4), &lineR, 1);
	OffsetRect(&lineR, 0, 20);
	TextBox(line5, strlen(line5), &lineR, 1);
		
	do {
		GetNextEvent(everyEvent, &anEvent);
	} while(anEvent.what != mouseDown);
	do {
		GetNextEvent(everyEvent, &anEvent);
	} while(anEvent.what != mouseUp);
	
	DisposeWindow(creditW);
	
	SetPort(port);
	return;
}

void DoMenu(long choice)
{
	Str255 buf;

	switch (HiWord(choice)) {
		case 1:		/*  Apple  */
			if(LoWord(choice) == 1) {
				AboutWindow();
			}
			else {
				GetItem(appleMenu, LoWord(choice), buf);
				OpenDeskAcc(buf);
			}
			break;
		case 2:		/*  File  */
			switch(LoWord(choice)) {
			case newCommand:		/* New */
				menuNew();
				break;
			case openCommand:		/* Open */
				menuOpen();
				break;
			case saveCommand:		/* Save */
				menuSave(1);
				break;
			case loadCommand:		/* Save as ... */
				menuLoad();
				break;
			case pageSetCommand:
				SetupPrinter();
				break;
			case printCommand:
				break;
			case quitCommand:		/* Quit */
				HiliteMenu(0);
				RCleanUp();
				break;
			}
			break;
		case 3:		/*  Edit  */
			SystemEdit(LoWord(choice) - 1);
			break;
		case 4:		/* Graph */
			break;
	}
	HiliteMenu(0);
}

void RCleanUp(void)
{
	if( R_DirtyImage ) {
	ParamText("\pSave workspace?", "\p", "\p", "\p");
	switch(Alert(128, 0L)) {
		case 1:
			menuSave(0);
		case 2:
			break;
		case 3:
			jump_to_toplevel();
			break;
	}
	}
	KillDevice();
	exit(0);
}

void InitConsole(Str255 name, int rows, int columns)
{
	InitGraf(&qd.thePort);
	InitFonts();
	FlushEvents(everyEvent, 0);
	InitWindows();
	InitMenus();
	TEInit();
	InitDialogs(0L);
	InitCursor();
	MaxApplZone();
	
	InitContext(&stdioContext);
	InitContext(&graphContext);
	InitContext(&editorContext);
	InitContext(&spreadContext);

	SetRect(&dragRect,
		qd.screenBits.bounds.left+4,
		qd.screenBits.bounds.top+24,
		qd.screenBits.bounds.right-4,
		qd.screenBits.bounds.bottom-4);
	
	SetupMenus();
	SetupCursors();
	activeContext = &stdioContext;
	InitStdioConsole(name, rows, columns, &stdioContext);
}

void RenameConsole(char *name)
{
	char buf[512];

	strcpy(buf,"R Dialog : ");
	strcat(buf,name);
	SetWTitle(stdioContext.theWindow, CtoPstr(buf));
}

static void doUpdate(EventRecord *theEvent)
{
	WindowPtr theWindow;
	
	theWindow = (WindowPtr)theEvent->message;
	if(theWindow == stdioContext.theWindow)
		stdioContext.doUpdate(theWindow);
	else if(theWindow == graphContext.theWindow)
		graphContext.doUpdate(theWindow);
	else if(theWindow == editorContext.theWindow)
		editorContext.doUpdate(theWindow);
	else if(theWindow == spreadContext.theWindow)
		spreadContext.doUpdate(theWindow);
}

static void doActivate(EventRecord *theEvent)
{
	WindowPtr theWindow;
	int theCode;
	
	theWindow = (WindowPtr)theEvent->message;
	theCode = theEvent->modifiers & activeFlag;
	
	if(theWindow != NULL) {
		if(theWindow == stdioContext.theWindow) {
			stdioContext.doActivate(theCode);
			if(theCode) activeContext = &stdioContext;
		}
		else if(theWindow == graphContext.theWindow) {
			graphContext.doActivate(theCode);
			if(theCode) activeContext = &graphContext;
		}
		else if(theWindow == editorContext.theWindow) {
			editorContext.doActivate(theCode);
			if(theCode) activeContext = &editorContext;
		}
		else if(theWindow == spreadContext.theWindow) {
			spreadContext.doActivate(theCode);
			if(theCode) activeContext = &spreadContext;
		}
		activeContext->pasteH = NULL;
	}
	else SysBeep(2);
}

void EventLoop(void)
{
	EventRecord theEvent;
	WindowPtr whichWindow;
	short windowCode;
	int key;
	long sleepTicks=10;
	register EvQElPtr q;

	if (activeContext->pasteH) {
		key = (unsigned char) (*(activeContext->pasteH))[activeContext->pasteOfs++];
		if (activeContext->pasteOfs == activeContext->pasteLen) {
			DisposHandle(activeContext->pasteH);
			activeContext->pasteH = NULL;
		}
		if (key == '\t')
			key = ' ';
		activeContext->doKey(key, &theEvent);
		return;
	}

	
	SystemTask();
	activeContext->doCursor();
	
	/* have a look for cmd-. to cancel */
	for (q = (EvQElPtr) GetEvQHdr()->qHead; q; q = (EvQElPtr) q->qLink) 
				if (q->evtQWhat == keyDown && (char) q->evtQMessage == '.') 
					if (q->evtQModifiers & cmdKey) {
						FlushEvents(keyDownMask, 0);
						raise(SIGINT);
						/* errno = EINTR; n */
						return;
					}

	
#define SYS_7_FRIENDLY

#ifdef SYS_7_FRIENDLY		
	if(WaitNextEvent(everyEvent, &theEvent, sleepTicks, 0L)) {
#else
	if(GetNextEvent(everyEvent, &theEvent)) {
#endif
		switch(theEvent.what) {
			
			case autoKey:
			case keyDown:
				key = theEvent.message & charCodeMask;
				if(theEvent.modifiers & cmdKey) 
					if( key == 't' )
						jump_to_toplevel();
					else
						activeContext->doMenu(MenuKey(key));
				else
					activeContext->doKey(key, &theEvent);
				break;
			case mouseDown:
				windowCode = FindWindow(theEvent.where, &whichWindow);
				if(whichWindow != NULL) {
					if(FrontWindow() == whichWindow)
						activeContext->doActive(&theEvent, whichWindow, windowCode);
					else
						activeContext->doInactive(&theEvent, whichWindow, windowCode);
					break;
				}
				else activeContext->doNotWindow(&theEvent, whichWindow, windowCode);
				break;
					
			case updateEvt:
				doUpdate(&theEvent);
				break;
					
			case activateEvt:
				doActivate(&theEvent);
				break;
		}
	}
}

void SetVScroll(void)
{
	int	n, p, w;
	TEHandle theTEH;
	
	theTEH = activeContext->theTEH;
	p = ((**theTEH).viewRect.top - (**theTEH).destRect.top) / (**theTEH).lineHeight;
	w = ((**theTEH).viewRect.bottom - (**theTEH).viewRect.top) / (**theTEH).lineHeight;
	n = (**theTEH).nLines - w;
	if((**theTEH).teLength > 0 && (*((**theTEH).hText))[(**theTEH).teLength-1]=='\r')
		n++;
	SetCtlMax(activeContext->vScroll, n > 0 ? n : 0);
	SetCtlValue(activeContext->vScroll, p > 0 ? p : 0);
}

pascal Boolean CClikLoop(void)
{
	Rect *viewR, *destR;
	Point mousePt;
	short viewWidth, lineHeight, destBottom;
	TEHandle theTEH;
	TEPtr theTEPtr;
	
	theTEH = activeContext->theTEH;
	HLock((Handle)theTEH);
	theTEPtr = *theTEH;
	
	viewR = &theTEPtr->viewRect;
	destR = &theTEPtr->destRect;
	lineHeight = theTEPtr->lineHeight;
	viewWidth = viewR->right - viewR->left;
	
	GetMouse(&mousePt);
	if(! PtInRect(mousePt, viewR)) {
		if(mousePt.v > viewR->bottom) {
			destBottom = destR->top + (theTEPtr->nLines)*lineHeight;
			if(viewR->bottom < destBottom) {
				TEScroll(0, -lineHeight, theTEH);
			}
		}
		else if((mousePt.h < viewR->left) && (viewR->left > destR->right)) {
			TEScroll(viewWidth/10, 0, theTEH);
		}
		else if((mousePt.h > viewR->right) && (viewR->right < destR->right)) {
			TEScroll(-viewWidth/10, 0, theTEH);
		}
		else if((mousePt.v < viewR->top) && (viewR->top > destR->top)) {
			TEScroll(0, lineHeight, theTEH);
		}
	}

	SetVScroll();
	HUnlock((Handle)theTEH);
	return 1;
}

/********************************************/
/* Window Scrolling Code - All Text Windows */
/********************************************/

void ScrollInsertPt(TEHandle hTE)
{
	int line, theLine, nLines, topline, bottomline, lineHeight, windowHeight;
	TEPtr	pTE;

	HLock((Handle)hTE);
	pTE = *hTE;
	lineHeight = pTE->lineHeight;
	nLines = pTE->nLines;
	if (pTE->teLength > 0 && (*(pTE->hText))[pTE->teLength-1]=='\r')
		nLines++;

	topline = ((pTE->viewRect).top - (pTE->destRect).top) / lineHeight;
	windowHeight = ((pTE->viewRect).bottom - (pTE->viewRect).top) / lineHeight;
	bottomline = topline + windowHeight;
	
	if(nLines <= windowHeight) {
		TEScroll(0, topline*lineHeight, hTE);
	}
	else {
		theLine = 1;
		while(pTE->lineStarts[theLine] < pTE->selEnd && theLine<pTE->nLines)
				theLine++;
		if (pTE->teLength > 0 && (*(pTE->hText))[pTE->teLength-1]=='\r')
				theLine++;
		if(pTE->selEnd < pTE->lineStarts[topline])
			TEScroll(0, (topline-theLine+2)*lineHeight, hTE);
		else if(pTE->selStart >= pTE->lineStarts[bottomline])
			TEScroll(0, (bottomline-theLine)*lineHeight, hTE);
	}
	HUnlock((Handle)hTE);
}


int AdjustText(void)
{
	int oldScroll, newScroll, vdelta, hdelta;
	TEHandle theTEH = activeContext->theTEH;
	
	oldScroll = (**theTEH).viewRect.top - (**theTEH).destRect.top;
	newScroll = GetCtlValue(activeContext->vScroll) * (**theTEH).lineHeight;
	vdelta = oldScroll - newScroll;
	
	oldScroll = (**theTEH).viewRect.left - (**theTEH).destRect.left;
	newScroll = GetCtlValue(activeContext->hScroll) * activeContext->fontWidth;
	hdelta = oldScroll - newScroll;
	
	if(vdelta != 0 || hdelta != 0)
		TEScroll(hdelta, vdelta, theTEH);
	SetVScroll();
}

void SetView(WindowPtr w)
{
	int lines;
	TEHandle theTEH = activeContext->theTEH;
	
	(**theTEH).viewRect = w->portRect;
	(**theTEH).viewRect.right -= SBarWidth;
	(**theTEH).viewRect.bottom -= SBarWidth;
	InsetRect(&(**theTEH).viewRect, 4, 4);

	lines = ((**theTEH).viewRect.bottom-(**theTEH).viewRect.top)/(**theTEH).lineHeight;
	activeContext->lines = lines;
	(**theTEH).viewRect.bottom = (**theTEH).viewRect.top + (**theTEH).lineHeight*lines;
	(**theTEH).destRect.right = (**theTEH).viewRect.right;
	TECalText(theTEH);
}

pascal void ScrollProc(ControlHandle theControl, short theCode)
{
	int	pageSize, scrollAmt, oldCtl;
	TEHandle theTEH;
	
	if (theCode == 0)
		return ;
	
	theTEH = activeContext->theTEH;
	pageSize = ((**theTEH).viewRect.bottom-(**theTEH).viewRect.top) / 
			(**theTEH).lineHeight - 1;
			
	switch (theCode) {
		case inUpButton: 
			scrollAmt = -1;
			break;
		case inDownButton: 
			scrollAmt = 1;
			break;
		case inPageUp: 
			scrollAmt = -pageSize;
			break;
		case inPageDown: 
			scrollAmt = pageSize;
			break;
	}
	oldCtl = GetCtlValue(theControl);
	SetCtlValue(theControl, oldCtl+scrollAmt);
	AdjustText();
}
