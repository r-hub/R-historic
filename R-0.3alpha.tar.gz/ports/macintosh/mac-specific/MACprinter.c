/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*include <MacHeaders.h>*/
#include <Printing.h>
#include <stdio.h>
#include "PicComments.h"
#include "MACconsole.h"

#define topMargin 20
#define leftMargin 20
#define bottomMargin 20
#define tabChar	((char)'\t')
void PrErrWindow(short);


static int init = 0;
static int tabWidth;


static THPrint hPrint=NULL;

#define DEBUG

#ifdef DEBUG
FILE *logfp;
#endif

OpenPrinter()
{
	if( !hPrint ) {
		hPrint = (THPrint) NewHandle(sizeof (TPrint));
		PrOpen();
		PrintDefault(hPrint);
	}
	else {
		PrOpen();
		PrValidate(hPrint);
	}
}

ClosePrinter()
{
	PrClose();
}

SetupPrinter()
{
	
	OpenPrinter();
	PrStlDialog(hPrint);
	ClosePrinter();
}

static int HowMany(void)
{
	return( ((**hPrint).prJob.bJDocLoop==bDraftLoop) ? 
				(**hPrint).prJob.iCopies : 1 );
}

void DoPlotPrint(PicHandle pict)
{
	TPPrPort printPort;
#ifdef HI_RES
	TGetRslBlk pData;
	TSetRslBlk qData;
#endif
	GrafPtr savePort;
	Rect printRect, pictRect;
	Point linesize;
	Point *lp;
	int copies, xoff, yoff;
	short PrintError;
	
	linesize.h = 2;
	linesize.v = 1;
	lp = &linesize;
	
	OpenPrinter();
	if (PrError() == noErr)
	{
		if (PrJobDialog(hPrint) != 0) {
			SetCursor(*watch);
			GetPort(&savePort);
	
			printRect = (**hPrint).prInfo.rPage;
			pictRect = (**pict).picFrame;
			xoff = (printRect.right-pictRect.right-printRect.left+pictRect.left)/2;
			OffsetRect(&pictRect, xoff, 0);
	
			for( copies=HowMany(); copies>0 ; copies--) {
				printPort = PrOpenDoc(hPrint, 0L, 0L);
				if( PrError() == noErr)
				{
					SetPort((GrafPtr)printPort);
					PrOpenPage(printPort, 0L);
					if( PrError() == noErr)
					{
						PicComment(SetLineWidth, 4, (Handle)&lp); /*!! handle?*/
						DrawPicture(pict, &pictRect);
					}
					PrClosePage(printPort);
				}
				PrCloseDoc(printPort);
			}
			SetPort(savePort);
		}
	}
	PrintError = PrError();
	
	ClosePrinter();
	if( PrintError != noErr)
		PrErrWindow(PrintError);
}

static void MyDrawText(char	*p, int count)
{
	register char	*p1, *p2;
	int				len;
	Point			pt;

	p1 = p;
	p2 = p+count;
	while (p<p2) {
		while ((p1<p2) && (*p1 !=tabChar)) *p1++;
		if ((len=p1-p)>0) DrawText(p, 0, p1-p);
		if (*p1==tabChar) {
			GetPen(&pt);
			Move((tabWidth-(pt.h-leftMargin)%tabWidth), 0);
			*p1++;
		}
		p = p1;
	}
}

static void PrDoc(TEHandle hTE, long first, long last, THPrint hPrint)
{
	register int 	line = 0;
	register int 	lastLineOnPage = 0;
	int				i, j, length;
	Rect 			printRect;
	int 			linesPerPage, lineBase, lineHeight;
	register char 	*p, *q, *r;
	FontInfo		info;
	TPPrPort		printPort;
	
	
	printPort = PrOpenDoc(hPrint, nil, nil);
	if( PrError() == noErr)
	{
		SetPort((GrafPtr)printPort);
		TextFont((**hTE).txFont);
		TextSize((**hTE).txSize);
		tabWidth = StringWidth("\pmmmm");
		printRect = (**hPrint).prInfo.rPage;
		GetFontInfo(&info);
		lineHeight = info.leading+info.ascent+info.descent;
		linesPerPage = (printRect.bottom-printRect.top-topMargin-bottomMargin)/lineHeight;
		HLock((**hTE).hText);
		p = q = *((**hTE).hText)+first;
		r = *((**hTE).hText)+last;
		do {
			PrOpenPage(printPort, 0L);
			if( PrError() == noErr ) {
				lastLineOnPage += linesPerPage;
				MoveTo(printRect.left+leftMargin, (lineBase = printRect.top+lineHeight));
				do {
					while (q <= r && *q++ != (char)'\r')
					;
					if((length=(int)(q-p)-1) > 0)	/* -1 because we don't want \r */
						MyDrawText(p, length);			
					MoveTo(printRect.left+leftMargin, (lineBase += lineHeight));
					p = q;
				} while (++line != lastLineOnPage && p < r);
			}
			PrClosePage(printPort);
		} while (p < r);
		HUnlock((**hTE).hText);
	}
	PrCloseDoc(printPort);
}

void printTE(TEHandle hTE)
{
	TPPrPort	printPort;
	TPrStatus	prStatus;
	GrafPtr		savePort;
	short		PrintError;
	int			first, last, ncopies, copy;

	first = (**hTE).selStart;
	last = (**hTE).selEnd;
	if(first == last) {
		first = 0;
		last = (**hTE).teLength;
	}
    OpenPrinter();
    if(PrError() == noErr)
    {
		SetCursor(&qd.arrow);
		if (PrJobDialog(hPrint) != 0) {
			SetCursor(*watch);
			GetPort(&savePort);
			ncopies=HowMany();
			for ( copy=0 ; copy<ncopies ; copy++ ) {
				PrDoc(hTE, first, last, hPrint);
				PrPicFile(hPrint, 0L, 0L, 0L, &prStatus);
			}
			SetPort(savePort);
		}
	}
	PrintError = PrError();
	
	ClosePrinter();
	if( PrintError != noErr)
		PrErrWindow(PrintError);
}

static char line1[] = "Printer Error";
static char line3[] = "Please Report this Error";

void PrErrWindow(short PrintError)
{
	long dummy;
	Rect p1, p2;
	GrafPtr port;
	WindowPtr errWin;
	EventRecord anEvent;
	char line2[128];
	
	GetPort(&port);
	SetRect(&p1,5,5,245,20);
	SetRect(&p2,75,120,325,200);
	errWin = NewWindow((WindowPeek)0, &p2,"\px",true,dBoxProc, (WindowPtr)-1,true,0);
	SetPort(errWin);
	sprintf(line2,"Error %d occurred",PrintError);
	
	TextSize(12);
	TextFont(0);
	TextBox(line1,strlen(line1), &p1,1);
	OffsetRect(&p1,0,20);
	TextBox(line2,strlen(line2), &p1,1);
	OffsetRect(&p1,0,20);
	TextBox(line3,strlen(line3), &p1,1);
	
	do {
		GetNextEvent(everyEvent, &anEvent);
	} while(anEvent.what != mouseDown);
	do {
		GetNextEvent(everyEvent, &anEvent);
	} while(anEvent.what != mouseUp);
	
	DisposeWindow(errWin);
	
	SetPort(port);
	return;
}
