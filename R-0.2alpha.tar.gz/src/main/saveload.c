/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
/* Functions to save and load (restore) R objects both as binary files */
/* and as ascii files. */
/*     do_save - saves objects in ascii format */
/*     do_load  - loads objects from an ascii file */
/* To save objects the algorithm is to traverse the SEXP heap marking */
/* all SEXP's that need to be saved. Then these are written out. System */
/* functions have ascii versions of their printnames printed so they */
/* can be installed when the file is read in. */

/* This could be made cleaner by using function pointers one for binary */
/* and one for ascii to handle the reading and writing; then half the */
/* functions could go away ... */

#include "Defn.h"

/* Static Globals */

static FILE *fp;		/* The file handle. */
static int NSave;		/* Number of SEXPs to be saved or restored. */
static int NVSize;		/* Amount of vector heap to be saved or restored. */
static char buf[MAXELTSIZE];	/* Buffer for character strings. */
static char *bufp;		/* A pointer to that buffer. */



	/* Function Prototypes */

static void binary_Load();
static void ascii_Load();
static void restoreSEXP(SEXP, int *, int *);
static void brestoreSEXP(SEXP, int *, int *);
static SEXP brestoreNode(int *, int *);
static void restoreINT(SEXP, int);
static void restoreREAL(SEXP, int);
static SEXP restoreNode(int *, int *);
static void fillBuff();
static void asciiSave(char *, SEXP);
static void binary_Save();
static void ascii_Save();
static void BSaveCheck(SEXP);
static void markSave(SEXP);
static void SaveCheck(SEXP);
static void writeINT(FILE *, int *, int);
static void writereal(FILE *, double *, int);
static void writechar(FILE *, char *, int);
static void fwriteInteger(unsigned int, FILE *);
static unsigned int freadInteger(FILE *);
static void readINT(FILE *, int *, int);
static void readreal(FILE *, double *, int);
static void readchar(FILE *, char *, int);

static void reallocString(SEXP, int);
static void reallocVector(SEXP, int);
static SEXP TranslateNode(int *, int *, int);

	/* Magic numbers are 4 digit ascii */

#define R_MAGIC_BINARY 1950
#define R_MAGIC_ASCII 1951

static void R_WriteMagic(FILE *fp, int number)
{
	unsigned char buf[5];
	number = abs(number);
	buf[4] = '\n';
	buf[3] = number % 10 + '0';
	buf[2] = (number/10) % 10 + '0';
	buf[1] = (number/100) % 10 + '0';
	buf[0] = (number/1000) % 10 + '0';
	writechar(fp, (char*)buf, 5);
}

static int R_ReadMagic(FILE *fp)
{
	unsigned char buf[6];
	int d1, d2, d3, d4, d1234;
	readchar(fp, (char*)buf, 5);
	/* Intel gcc seems to screw up a single exprssion here */
	d1 = (buf[3]-'0') % 10;
	d2 = (buf[2]-'0') % 10;
	d3 = (buf[1]-'0') % 10;
	d4 = (buf[0]-'0') % 10;
	return d1234 = d1 + 10*d2 + 100*d3 + 1000*d4;
}


	/* Save and Restoration of the Global Environment */

void R_SaveGlobalEnv(void)
{
#ifdef Unix
	fp = fopen(".RData","w");
        if (!fp)
                error("can't save data -- unable to open ./.Rdata\n");
#else
	What is the right file name for your platform?
	Is this even the right strategy?
#endif

	unmarkPhase();
	NSave = 0;
	NVSize = 0;
	R_WriteMagic(fp, R_MAGIC_BINARY);
	binary_Save(FRAME(R_GlobalEnv));
	fclose(fp);
}

void R_RestoreGlobalEnv(void)
{
#ifdef Unix
	fp = fopen(".RData","r");
        if (!fp) {
		/* warning here perhaps */
		return;
	}
#else
	What is the right file name for your platform?
	Is this even the right strategy?
#endif
	gc();
	NSave = 0;
	NVSize = 0;
	switch(R_ReadMagic(fp)) {
	case R_MAGIC_BINARY:
		binary_Load();
		break;
	case R_MAGIC_ASCII:
		ascii_Load();
		break;
	default:
		fclose(fp);
		error("restore file corrupted -- no data loaded\n");
	}
}

	/* Save Functions */

SEXP do_save(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP s, t;
	int len, j;

	checkArity(op, args);


	if (TYPEOF(CAR(args)) != STRSXP)
		errorcall(call, "first argument must be a character vector\n");
	if (TYPEOF(CADR(args)) != STRSXP)
		errorcall(call, "second argument must be a string\n");
	if (TYPEOF(CADDR(args)) != LGLSXP)
		errorcall(call, "third argument must be a logical vector\n");

	fp = fopen(CHAR(STRING(CADR(args))[0]), "wb");
	if (!fp)
		errorcall(call, "unable to open file\n");

	len = length(CAR(args));
	PROTECT(s = allocList(len));

	t = s;
	for (j = 0; j < len; j++, t = CDR(t)) {
		TAG(t) = install(CHAR(STRING(CAR(args))[j]));
		CAR(t) = eval(TAG(t), env);
	}

	unmarkPhase();
	NSave = 0;
	NVSize = 0;

	switch (INTEGER(CADDR(args))[0]) {
	case 0:
		R_WriteMagic(fp, R_MAGIC_BINARY);
		binary_Save(s);
		break;
	default:
		R_WriteMagic(fp, R_MAGIC_ASCII);
		ascii_Save(s);
		break;
	}

	UNPROTECT(1);
	fclose(fp);
	R_Visible = 0;
	return R_NilValue;
}


static void binary_Save(SEXP s)
{
	int len, j, i;
	char *strp;
	SEXP t;


#ifdef OLD
	/* write the magic number */
	fwriteInteger(1950, fp);
#endif

	/* links to the symbol table */
	fwriteInteger(length(s), fp);

	for (t = s; t != R_NilValue; t = CDR(t))
		if (TYPEOF(TAG(t)) == SYMSXP) {
			len = strlen(CHAR(PRINTNAME(TAG(t))));
			fwriteInteger(len, fp);
			writechar(fp, CHAR(PRINTNAME(TAG(t))), len);
			fwriteInteger(TAG(t) - R_NilValue, fp);
			fwriteInteger(CAR(t) - R_NilValue, fp);
		}
		else
			error("bsave: argument is not a symbol\n");

	/* mark everything */
	for (t = s; t != R_NilValue; t = CDR(t)) {
		markSave(CAR(t));
		markSave(TAG(t));
	}

	fwriteInteger(NSave, fp);
	fwriteInteger(NVSize, fp);

	for (i = 0; i < R_NSize; i++)
		if (MARK(&R_NHeap[i]))
			fwriteInteger(i, fp);

	for (i = 0; i < R_NSize; i++) {
		if (MARK(&R_NHeap[i])) {
			/*surely there  must be a better way????????? */
			fwriteInteger(*(unsigned int *) &((&R_NHeap[i])->sxpinfo), fp);

			BSaveCheck(ATTRIB(&R_NHeap[i]));
			switch (TYPEOF(&R_NHeap[i])) {
			case LISTSXP:
			case LANGSXP:
			case CLOSXP:
			case PROMSXP:
			case FRAMESXP:
			case ENVSXP:
				BSaveCheck(CAR(&R_NHeap[i]));
				BSaveCheck(CDR(&R_NHeap[i]));
				BSaveCheck(TAG(&R_NHeap[i]));
				break;
			case CHARSXP:
				len = LENGTH(&R_NHeap[i]);
				fwriteInteger(len, fp);
				writechar(fp, CHAR(&R_NHeap[i]), len);
				break;
			case REALSXP:
				len = LENGTH(&R_NHeap[i]);
				fwriteInteger(len, fp);
				writereal(fp, REAL(&R_NHeap[i]), len);
				break;
			case INTSXP:
			case LGLSXP:
			case FACTSXP:
			case ORDSXP:
				len = LENGTH(&R_NHeap[i]);
				fwriteInteger(len, fp);
				writeINT(fp, INTEGER(&R_NHeap[i]), len);
				break;
			case STRSXP:
				len = LENGTH(&R_NHeap[i]);
				fwriteInteger(len, fp);
				for (j = 0; j < len; j++)
					fwriteInteger(STRING(&R_NHeap[i])[j] - R_NHeap, fp);
			}
		}
	}
}

static void BSaveCheck(SEXP s)
{
	int t, len;

	t = s - R_NHeap;
	if (s == R_NilValue) {
		fwriteInteger(0, fp);
		return;
	}
	if (s == R_UnboundValue) {
		fwriteInteger(1, fp);
		return;
	}
	if (s == R_MissingArg) {
		fwriteInteger(2, fp);
		return;
	}
	if (MARK(s))
		fwriteInteger(t, fp);
	else {
		fwriteInteger(-t, fp);
		switch (TYPEOF(s)) {
		case SPECIALSXP:
		case BUILTINSXP:
			len = strlen(PRIMNAME(s));
			fwriteInteger(len, fp);
			writechar(fp, PRIMNAME(s), len);
			break;
		case SYMSXP:
			len = LENGTH(PRINTNAME(s));
			fwriteInteger(len, fp);
			writechar(fp, CHAR(PRINTNAME(s)), len);
			break;
		case ENVSXP:
			if (s == R_GlobalEnv) {
				len = 9;
				strcpy(buf, "R_GlobalEnv");
				fwriteInteger(len, fp);
				writechar(fp, buf, len);
			}
			break;
		}
	}
}


static void ascii_Save(SEXP s)
{
	int len, j, i;
	char *strp;
	SEXP t;

	len = 0;

	/* links to the symbol table */
	fprintf(fp, "%d \n", length(s));
	for (t = s; t != R_NilValue; t = CDR(t))
		if (TYPEOF(TAG(t)) == SYMSXP)
			fprintf(fp, "\"%s\" %d %d \n",
				CHAR(PRINTNAME(TAG(t))), TAG(t) - R_NilValue, CAR(t) - R_NilValue);
		else
			error("asave: argument is not a symbol\n");

	/* mark everything */
	for (t = s; t != R_NilValue; t = CDR(t)) {
		markSave(CAR(t));
		markSave(TAG(t));
	}

	fprintf(fp, "%d %d \n", NSave, NVSize);
	for (i = 0; i < R_NSize; i++) {
		if (MARK(&R_NHeap[i])) {
			fprintf(fp, "%d ", i);
			len++;
			if (len % 20 == 0)
				fprintf(fp, "\n");
		}
	}
	fprintf(fp, "\n");

	for (i = 0; i < R_NSize; i++) {
		if (MARK(&R_NHeap[i])) {
			fprintf(fp, "%u %u %u ", TYPEOF(&R_NHeap[i]), OBJECT(&R_NHeap[i]), LEVELS(&R_NHeap[i]));
			SaveCheck(ATTRIB(&R_NHeap[i]));
			switch (TYPEOF(&R_NHeap[i])) {
			case LISTSXP:
			case LANGSXP:
			case CLOSXP:
			case PROMSXP:
			case FRAMESXP:
			case ENVSXP:
				SaveCheck(CAR(&R_NHeap[i]));
				SaveCheck(CDR(&R_NHeap[i]));
				SaveCheck(TAG(&R_NHeap[i]));
				break;
			case CHARSXP:
				len = LENGTH(&R_NHeap[i]);
				fprintf(fp, " %d ", len);
				j = Rstrlen(CHAR(&R_NHeap[i]));
				fprintf(fp, "\"%s\"", EncodeString(CHAR(&R_NHeap[i]), j, 0));
				break;
			case REALSXP:
				len = LENGTH(&R_NHeap[i]);
				fprintf(fp, " %d ", len);
				for (j = 0; j < len; j++) {
					if (REAL(&R_NHeap[i])[j] == NA_REAL)
						fprintf(fp, "\"NA\"");
					else
						fprintf(fp, "\"%f\"", REAL(&R_NHeap[i])[j]);
				}
				break;
			case INTSXP:
			case LGLSXP:
			case FACTSXP:
			case ORDSXP:
				len = LENGTH(&R_NHeap[i]);
				fprintf(fp, " %d ", len);
				for (j = 0; j < len; j++) {
					if (INTEGER(&R_NHeap[i])[j] == NA_INTEGER)
						fprintf(fp, "\"NA\"");
					else
						fprintf(fp, "\"%d\"", INTEGER(&R_NHeap[i])[j]);
				}
				break;
			case STRSXP:
				len = LENGTH(&R_NHeap[i]);
				fprintf(fp, " %d ", len);
				for (j = 0; j < len; j++) {
					fprintf(fp, " %d ", STRING(&R_NHeap[i])[j] - R_NHeap);
				}
			}
			fprintf(fp, "\n", &len);
		}
	}
}

static void SaveCheck(SEXP s)
{
	int t;

	t = s - R_NHeap;
	if (s == R_NilValue) {
		fprintf(fp, " 0 ");
		return;
	}
	if (s == R_UnboundValue) {
		fprintf(fp, " 1 ");
		return;
	}
	if (s == R_MissingArg) {
		fprintf(fp, " 2 ");
		return;
	}
	if (MARK(s))
		fprintf(fp, " %d ", t);
	else {
		fprintf(fp, " -%d ", t);
		switch (TYPEOF(s)) {
		case SPECIALSXP:
		case BUILTINSXP:
			fprintf(fp, "\"%s\"", PRIMNAME(s));
			break;
		case SYMSXP:
			fprintf(fp, "\"%s\"", CHAR(PRINTNAME(s)));
			break;
		case ENVSXP:
			if (s == R_GlobalEnv)
				fprintf(fp, "\"R_GlobalEnv\"");
			break;
		}
	}
}


/*Mark the Important Bits */
static void markSave(SEXP s)
{
	int i, len;

	if (s && !MARK(s)) {
		if (ATTRIB(s) != R_NilValue)
			markSave(ATTRIB(s));
		switch (TYPEOF(s)) {
		case NILSXP:
		case BUILTINSXP:
		case SPECIALSXP:
		case SYMSXP:
			break;
		case CHARSXP:
			MARK(s) = 1;
			NSave++;
			len = LENGTH(s);
			NVSize += 1 + BYTE2VEC(len + 1);
			break;
		case LGLSXP:
		case FACTSXP:
		case ORDSXP:
		case INTSXP:
			MARK(s) = 1;
			NSave++;
			len = LENGTH(s);
			NVSize += 1 + INT2VEC(len);
			break;
		case REALSXP:
			MARK(s) = 1;
			NSave++;
			len = LENGTH(s);
			NVSize += 1 + FLOAT2VEC(len);
			break;
		case STRSXP:
			MARK(s) = 1;
			NSave += 1;
			len = LENGTH(s);
			NVSize += 1 + PTR2VEC(len);
			for (i = 0; i < len; i++)
				markSave(STRING(s)[i]);
			break;
			/* we don't want to mark the global environment */
		case ENVSXP:
			if (s == R_GlobalEnv)
				break;
			MARK(s) = 1;
			NSave++;
			markSave(FRAME(s));
			markSave(ENCLOS(s));
			break;
		case CLOSXP:
		case PROMSXP:
		case LISTSXP:
		case LANGSXP:
		case DOTSXP:
		case FRAMESXP:
			MARK(s) = 1;
			NSave++;
			markSave(TAG(s));
			markSave(CAR(s));
			markSave(CDR(s));
			break;
		}
	}
}

/* LOAD FUNCTIONS */

static void binary_Load()
{
	int i, j, t1, t2;
	int *Tvec1, *Tvec2;
	char *vmaxsave, *vm2;
	SEXP AList, s, SList, t;

#ifdef OLD
	i = freadInteger(fp);
	if (i != 1950)
		error("bload: file is not an R binary\n");
#endif

	/* read in the symbols */
	i = freadInteger(fp);
	if (i > 0)
		PROTECT(SList = allocList(i));
	else
		return;
	t = SList;
	for (j = 0; j < i; j++, t = CDR(t)) {
		t1 = freadInteger(fp);
		readchar(fp, buf, t1);
		CAR(t) = install(buf);
		t1 = freadInteger(fp);
		t2 = freadInteger(fp);
		s = allocVector(INTSXP, 2);
		TAG(t) = s;
		INTEGER(s)[0] = t1;
		INTEGER(s)[1] = t2;
	}

	NSave = freadInteger(fp);
	NVSize = freadInteger(fp);

	vmaxsave = vmaxget();

	/* need some checks to ensure we can load */
	Tvec1 = (int *) R_alloc(NSave, sizeof(int));
	Tvec2 = (int *) R_alloc(NSave, sizeof(int));

	vm2 = vmaxget();
	if ((VECREC *) vm2 - R_VTop < NVSize)
		error("load: vector heap is too small\n");

	s = R_FreeSEXP;
	i = 0;
	while (s != NULL && s != R_NilValue) {
		i++;
		s = CDR(s);
	}
	if (i < NSave)
		error("load: language heap is too small\n");

	/* a gc after this point will be a disaster */

	AList = allocList(NSave);
	s = AList;

	for (i = 0; i < NSave; i++) {
		Tvec1[i] = freadInteger(fp);
		Tvec2[i] = s - R_NHeap;
		s = CDR(s);
	}
	for (i = 0; i < NSave; i++) {
		s = AList;
		AList = CDR(AList);
		brestoreSEXP(s, Tvec1, Tvec2);
	}
	for (t = SList; t != R_NilValue; t = CDR(t)) {
		s = TranslateNode(Tvec1, Tvec2, INTEGER(TAG(t))[1]);
		defineVar(CAR(t), s, R_GlobalEnv);
	}

	UNPROTECT(1);

	vmaxset(vmaxsave);
}



static void brestoreSEXP(SEXP s, int *Tvec1, int *Tvec2)
{
	unsigned int i, j, k;
	int len, t1;



	*(unsigned int *) &(s->sxpinfo) = freadInteger(fp);

	ATTRIB(s) = brestoreNode(Tvec1, Tvec2);
	switch (TYPEOF(s)) {
	case LISTSXP:
	case LANGSXP:
	case CLOSXP:
	case PROMSXP:
	case FRAMESXP:
	case ENVSXP:
		CAR(s) = brestoreNode(Tvec1, Tvec2);
		CDR(s) = brestoreNode(Tvec1, Tvec2);
		TAG(s) = brestoreNode(Tvec1, Tvec2);
		break;
	case CHARSXP:
		len = freadInteger(fp);
		LENGTH(s) = len;
		readchar(fp, buf, len);
		reallocString(s, len);
		strcpy(CHAR(s), buf);
		break;
	case REALSXP:
		len = freadInteger(fp);
		LENGTH(s) = len;
		reallocVector(s, len);
		readreal(fp, REAL(s), len);
		break;
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
	case LGLSXP:
		len = freadInteger(fp);
		LENGTH(s) = len;
		reallocVector(s, len);
		readINT(fp, INTEGER(s), len);
		break;
	case STRSXP:
		len = freadInteger(fp);
		LENGTH(s) = len;
		reallocVector(s, len);
		for (j = 0; j < len; j++)
			STRING(s)[j] = brestoreNode(Tvec1, Tvec2);
		break;
	}
}

static SEXP brestoreNode(int *Tvec1, int *Tvec2)
{
	int i, j;

	i = freadInteger(fp);
	if (i == 0)
		return R_NilValue;
	if (i == 1)
		return R_UnboundValue;
	if (i == 2)
		return R_MissingArg;
	if (i < 0) {
		j = freadInteger(fp);
		readchar(fp, buf, j);
		if (strcmp(buf, "R_GlobalEnv"))
			return (install(buf));
		else
			return (R_GlobalEnv);
	}
	else {
		return (TranslateNode(Tvec1, Tvec2, i));
	}
}


static void ascii_Load()
{
	int i, j, t1, t2;
	int *Tvec1, *Tvec2;
	char *vmaxsave, *vm2;
	SEXP AList, s, SList, t;

	/* read in the symbols */
	fscanf(fp, "%d", &i);
	if (i > 0)
		PROTECT(SList = allocList(i));
	else
		return;
	t = SList;
	for (j = 0; j < i; j++, t = CDR(t)) {
		fillBuff();
		CAR(t) = install(buf);
		fscanf(fp, "%d %d", &t1, &t2);
		s = allocVector(INTSXP, 2);
		TAG(t) = s;
		INTEGER(s)[0] = t1;
		INTEGER(s)[1] = t2;
	}

	fscanf(fp, "%d %d", &NSave, &NVSize);


	vmaxsave = vmaxget();

	/* need some checks to ensure we can load */
	Tvec1 = (int *) R_alloc(NSave, sizeof(int));
	Tvec2 = (int *) R_alloc(NSave, sizeof(int));

	vm2 = vmaxget();
	if ((VECREC *) vm2 - R_VTop < NVSize)
		error("load: vector heap is too small\n");

	s = R_FreeSEXP;
	i = 0;
	while (s != NULL && s != R_NilValue) {
		i++;
		s = CDR(s);
	}
	if (i < NSave)
		error("load: language heap is too small\n");

	/* a gc after this point will be a disaster */

	AList = allocList(NSave);
	s = AList;

	for (i = 0; i < NSave; i++) {
		fscanf(fp, "%d", &Tvec1[i]);
		Tvec2[i] = s - R_NHeap;
		s = CDR(s);
	}
	for (i = 0; i < NSave; i++) {
		s = AList;
		AList = CDR(AList);
		restoreSEXP(s, Tvec1, Tvec2);
	}
	for (t = SList; t != R_NilValue; t = CDR(t)) {
		s = TranslateNode(Tvec1, Tvec2, INTEGER(TAG(t))[1]);
		defineVar(CAR(t), s, R_GlobalEnv);
	}

	UNPROTECT(1);

	vmaxset(vmaxsave);
}

static void restoreSEXP(SEXP s, int *Tvec1, int *Tvec2)
{
	unsigned int i, j, k;
	int len, t1;

	fscanf(fp, "%u %u %u ", &i, &j, &k);
	TYPEOF(s) = i;
	OBJECT(s) = j;
	LEVELS(s) = k;
	ATTRIB(s) = restoreNode(Tvec1, Tvec2);
	switch (TYPEOF(s)) {
	case LISTSXP:
	case LANGSXP:
	case CLOSXP:
	case PROMSXP:
	case FRAMESXP:
	case ENVSXP:
		CAR(s) = restoreNode(Tvec1, Tvec2);
		CDR(s) = restoreNode(Tvec1, Tvec2);
		TAG(s) = restoreNode(Tvec1, Tvec2);
		break;
	case CHARSXP:
		fscanf(fp, "%d", &len);
		LENGTH(s) = len;
		fillBuff();
		reallocString(s, len);
		strcpy(CHAR(s), buf);
		break;
	case REALSXP:
		fscanf(fp, "%d", &len);
		LENGTH(s) = len;
		reallocVector(s, len);
		for (j = 0; j < len; j++)
			restoreREAL(s, j);
		break;
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
	case LGLSXP:
		fscanf(fp, "%d", &len);
		LENGTH(s) = len;
		reallocVector(s, len);
		for (j = 0; j < len; j++)
			restoreINT(s, j);
		break;
	case STRSXP:
		fscanf(fp, "%d", &len);
		LENGTH(s) = len;
		reallocVector(s, len);
		for (j = 0; j < len; j++)
			STRING(s)[j] = restoreNode(Tvec1, Tvec2);
		break;
	}
}



static void restoreINT(SEXP ans, int n)
{
	char *endp;

	fillBuff();

	if (strcmp("NA", buf)) {
		INTEGER(ans)[n] = strtol(buf, &endp, 10);
		if (*endp != '\0')
			error("\"aload\" expected an integer got \"%s\"", buf);
	}
	else
		INTEGER(ans)[n] = NA_INTEGER;
}



static void restoreREAL(SEXP ans, int n)
{
	char *endp;

	fillBuff();

	if (strcmp("NA", buf)) {
		REAL(ans)[n] = strtod(buf, &endp);
		if (*endp != '\0')
			error("\"aload\" expected a real got \"%s\"", buf);
	}
	else
		REAL(ans)[n] = NA_REAL;
}


static void fillBuff()
{
	int c, quote;

	bufp = buf;
	while (c = fgetc(fp) != '"');
	while ((c = fgetc(fp)) != EOF && c != '"') {
		if (c == '\\') {
			c = fgetc(fp);
			if (c == EOF)
				break;
			else if (c == 'n')
				c = '\n';
			else if (c == 'r')
				c = '\r';
			else if (c == '"')
				c = '\"';
		}
		*bufp++ = c;
	}
	*bufp = '\0';
}

static SEXP restoreNode(int *Tvec1, int *Tvec2)
{
	int i, j;

	fscanf(fp, "%d", &i);
	if (i == 0)
		return R_NilValue;
	if (i == 1)
		return R_UnboundValue;
	if (i == 2)
		return R_MissingArg;
	if (i < 0) {
		fillBuff();
		if (strcmp(buf, "R_GlobalEnv"))
			return (install(buf));
		else
			return (R_GlobalEnv);
	}
	else {
		return (TranslateNode(Tvec1, Tvec2, i));
	}
}

/* 
   this could be improved by using some sort of hashing function 
   rather than linear search for matching nodes
 */
static SEXP TranslateNode(int *Tvec1, int *Tvec2, int oldN)
{
	int j;

	for (j = 0; j < NSave; j++)
		if (Tvec1[j] == oldN)
			return (SEXP) R_NHeap + Tvec2[j];

	error("load: node conflict\n");
}

SEXP do_load(SEXP call, SEXP op, SEXP args, SEXP env)
{
	int i;

	checkArity(op, args);

	if (TYPEOF(CAR(args)) != STRSXP)
		errorcall(call, "first argument must be a string\n");
#ifdef OLD
	if (TYPEOF(CADR(args)) != LGLSXP)
		errorcall(call, "second argument must be a logical vector\n");
#endif
	i = INTEGER(CADR(args))[0];

	fp = fopen(CHAR(STRING(CAR(args))[0]), "rb");
	if (!fp)
		errorcall(call, "unable to open file\n");
	gc();
	NSave = 0;
	NVSize = 0;
	switch(R_ReadMagic(fp)) {
	case R_MAGIC_BINARY:
		binary_Load();
		break;
	case R_MAGIC_ASCII:
		ascii_Load();
		break;
	default:
		fclose(fp);
		error("restore file corrupted -- no data loaded\n");
	}
	fclose(fp);
	R_Visible = 0;
	return R_NilValue;
}


static void reallocVector(SEXP s, int length)
{
	long size;

	switch (TYPEOF(s)) {
	case CHARSXP:
		size = 1 + BYTE2VEC(length + 1);
		break;
	case LGLSXP:
	case INTSXP:
	case FACTSXP:
	case ORDSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + INT2VEC(length);
		break;
	case REALSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + FLOAT2VEC(length);
		break;
	case STRSXP:
		if (length <= 0)
			size = 0;
		else
			size = 1 + PTR2VEC(length);
		break;
	default:
		error("wrong type to reallocSXP\n");
	}
	if (size + R_NVCell >= R_VSize) {
		gc();
		if (size + R_NVCell >= R_VSize)
			error("memory exhausted\n");
	}

	LENGTH(s) = length;
	if (size > 0) {
		CHAR(s) = (char *) (R_VTop + 1);
		BACKPOINTER(*R_VTop) = s;
		R_VTop += size;
		R_NVCell += size;
	}
	else
		CHAR(s) = (char *) 0;

}

static void reallocString(SEXP s, int length)
{
	long size;

	size = 1 + BYTE2VEC(length + 1);

	if (size + R_NVCell >= R_VSize) {
		gc();
		if (size + R_NVCell >= R_VSize)
			error("memory exhausted\n");
	}

	if (TYPEOF(s) != CHARSXP)
		error("reallocString: wrong type\n");
	CHAR(s) = (char *) (R_VTop + 1);
	LENGTH(s) = length;
	TAG(s) = R_NilValue;
	NAMED(s) = 0;
	ATTRIB(s) = R_NilValue;
	BACKPOINTER(*R_VTop) = s;
	R_VTop += size;
	R_NVCell += size;
}

/*binary read and write facilities */

static void fwriteInteger(unsigned int i, FILE * fp)
{
	if (fwrite(&i, sizeof(i), 1, fp) != 1)
		error("write error occured");
}

static void writeINT(FILE * fp, int *intvec, int len)
{
	if (len > 0)
		fwrite(intvec, sizeof(int), len, fp);
}


static void writereal(FILE * fp, double *fvec, int len)
{
	if (len > 0)
		fwrite(fvec, sizeof(double), len, fp);
}

static void writechar(FILE * fp, char *cvec, int len)
{
	if (len > 0)
		fwrite(cvec, sizeof(char), len, fp);
}

static unsigned int freadInteger(FILE * fp)
{
	unsigned int i;
	fread(&i, sizeof(i), 1, fp);
	return i;
}

static void readINT(FILE * fp, int *intvec, int len)
{
	if (len > 0)
		fread(intvec, sizeof(int), len, fp);
}

static void readreal(FILE * fp, double *fvec, int len)
{
	if (len > 0)
		fread(fvec, sizeof(double), len, fp);
}

static void readchar(FILE * fp, char *cvec, int len)
{
	if (len > 0) {
		fread(cvec, sizeof(char), len, fp);
	}
	cvec[len] = '\0';
}
