#include "Mathlib.h"

double fcube(double x)
{
	return x * x * x;
}
