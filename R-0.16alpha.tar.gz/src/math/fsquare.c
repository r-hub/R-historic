#include "Mathlib.h"

double fsquare(double x)
{
	return x * x;
}
