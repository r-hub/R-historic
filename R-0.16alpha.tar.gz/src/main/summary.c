/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"
#include "Mathlib.h"

extern int errno;
static int narm;
static int count;

typedef double (*SUMMARY) (double *, int);

static double sum(double * x, int n)
{
	int i, icount;
	double s;

	s = 0.0;
	if(n == 0) return s;
	icount = 0;
	for (i = 0; i < n; i++)
		if (FINITE(x[i])) {
			icount++;
			count++;
			s += x[i];
		}
		else if (!narm)
			return NA_REAL;
	if (icount == 0)
		return NA_REAL;
	return s;
}

static double minimum(double * x, int n)
{
	int i, icount;
	double s;

	icount = 0;
	s = NA_REAL;
	for (i = 0; i < n; i++)
		if (FINITE(x[i])) {
			icount++;
			count++;
			if (FINITE(s))
				s = (s < x[i]) ? s : x[i];
			else
				s = x[i];
		}
		else if (!narm)
			return NA_REAL;
	if (icount == 0)
		return NA_REAL;
	return s;
}

static double maximum(double * x, int n)
{
	int i, icount;
	double s;

	icount = 0;
	s = NA_REAL;
	for (i = 0; i < n; i++)
		if (FINITE(x[i])) {
			icount++;
			count++;
			if (FINITE(s))
				s = (s > x[i]) ? s : x[i];
			else
				s = x[i];
		}
		else if (!narm)
			return NA_REAL;
	if (icount == 0)
		return NA_REAL;
	return s;
}

static double product(double * x, int n)
{
	int i, icount;
	double s;

	s = 1.0;
	if(n == 0) return s;
	icount = 0;
	for (i = 0; i < n; i++)
		if (FINITE(x[i])) {
			icount++;
			if (FINITE(s))
				s = MATH_CHECK(s * x[i]);
			else
				s = x[i];
		}
		else if (!narm)
			return NA_REAL;
	if (icount == 0)
		return NA_REAL;
	return s;
}

#ifdef OLD
static double var(double * x, int n)
{
	int i, count;
	double dev, s, xmean;

	s = 0.0;
	count = 0;
	for (i = 0; i < n; i++)
		if (FINITE(x[i])) {
			count++;
			s += x[i];
		}
	if (count <= 1)
		return NA_REAL;
	xmean = s / count;
	s = 0.0;
	for (i = 0; i < n; i++)
		if (FINITE(x[i])) {
			dev = x[i] - xmean;
			s += dev * dev;
		}
	return s / (count - 1);
}

static double sd(double * x, int n)
{
	double v = var(x, n);
	if (FINITE(v))
		return sqrt(v);
	else
		return v;
}
#endif


	/* do_summary provides a variety of data summaries */
	/* 0 = sum, 1 = mean, 2 = min, 3 = max, 4 = prod */

SEXP do_summary(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans, x;
	int n;
	double tmp, cum = NA_REAL;

	ans = matchArg(R_NaRmSymbol, &args);
	narm = asLogical(ans);
	count = 0;
	switch (PRIMVAL(op)) {
	case 0:
	case 1:
		cum = 0.0;
		break;
	case 2:
	case 3:
		cum = NA_REAL;
		break;
	case 4:
		cum = 1.0;
		break;
	}
	PROTECT(ans = allocVector(REALSXP, 1));
	for ( ; args != R_NilValue; args = CDR(args)) {
		x = CAR(args) = coerceVector(CAR(args), REALSXP);
		n = LENGTH(x);
		if(n > 0) {
			switch (PRIMVAL(op)) {
			case 0:	/*sum */
			case 1:	/*mean */
				tmp = sum(REAL(x), n);
				if (FINITE(tmp)) {
					if (FINITE(cum))
						cum += tmp;
					else
						cum = tmp;
				}
				else if (!narm) {
					REAL(ans)[0] = NA_REAL;
					UNPROTECT(1);
					return ans;
				}
				break;
			case 2:	/*min */
				tmp = minimum(REAL(x), n);
				if (FINITE(tmp)) {
					if (FINITE(cum))
						cum = (cum < tmp) ? cum : tmp;
					else
						cum = tmp;
				}
				else if (!narm) {
					REAL(ans)[0] = NA_REAL;
					UNPROTECT(1);
					return ans;
				}
				break;
			case 3:	/* max */
				tmp = maximum(REAL(x), n);
				if (FINITE(tmp)) {
					if (FINITE(cum))
						cum = (cum > tmp) ? cum : tmp;
					else
						cum = tmp;
				}
				else if (!narm) {
					REAL(ans)[0] = NA_REAL;
					UNPROTECT(1);
					return ans;
				}
				break;
			case 4:	/* prod */
				tmp = product(REAL(x), n);
				if (FINITE(tmp)) {
					if (FINITE(cum))
						cum = MATH_CHECK(cum * tmp);
					else
						cum = tmp;
				}
				else if (!narm) {
					REAL(ans)[0] = NA_REAL;
					UNPROTECT(1);
					return ans;
				}
				break;
			default:
				error("method not implemented yet");
			}
		}
	}
	if (PRIMVAL(op) == 1)
		if (count == 0)
			cum = NA_REAL;
		else
			cum = cum / count;
	UNPROTECT(1);
	REAL(ans)[0] = cum;
	return ans;
}

SEXP do_compcases(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	SEXP s, t, u, rval;
	int i, len;

	/* checkArity(op, args); */
	len = -1;

	for (s = args; s != R_NilValue; s = CDR(s)) {
		if (isList(CAR(s)) || isFrame(CAR(s))) {
			for (t = CAR(s); t != R_NilValue; t = CDR(t))
				if (isMatrix(CAR(t))) {
					u = getAttrib(CAR(t), R_DimSymbol);
					if (len < 0)
						len = INTEGER(u)[0];
					else if (len != INTEGER(u)[0])
						goto bad;
				}
				else if (isVector(CAR(t))) {
					if (len < 0)
						len = LENGTH(CAR(t));
					else if (len != LENGTH(CAR(t)))
						goto bad;
				}
				else
					goto bad2;
		}
		else if (isMatrix(CAR(s))) {
			u = getAttrib(CAR(s), R_DimSymbol);
			if (len < 0)
				len = INTEGER(u)[0];
			else if (len != INTEGER(u)[0])
				goto bad;
		}
		else if (isVector(CAR(s))) {
			if (len < 0)
				len = LENGTH(CAR(s));
			else if (len != LENGTH(CAR(s)))
				goto bad;
		}
		else
			goto bad2;
	}
	PROTECT(rval = allocVector(LGLSXP, len));
	for (i = 0; i < len; i++)
		INTEGER(rval)[i] = 1;
	for (s = args; s != R_NilValue; s = CDR(s)) {
		if (isList(CAR(s)) || isFrame(CAR(s))) {
			/* now we only need to worry about vectors, use mod to handle arrays */
			for (t = CAR(s); t != R_NilValue; t = CDR(t))
				for (i = 0; i < LENGTH(CAR(t)); i++) {
					u = CAR(t);
					switch (TYPEOF(u)) {
					case INTSXP:
					case LGLSXP:
					case FACTSXP:
					case ORDSXP:
						if (INTEGER(u)[i] == NA_INTEGER)
							INTEGER(rval)[i % len] = 0;
						break;
					case REALSXP:
						if (!FINITE(REAL(u)[i]))
							INTEGER(rval)[i % len] = 0;
						break;
					case STRSXP:
						if (STRING(u)[i] == NA_STRING)
							INTEGER(rval)[i % len] = 0;
						break;
					default:
						goto bad2;
					}
				}
		}
		else {
			for (i = 0; i < LENGTH(CAR(s)); i++) {
				u = CAR(s);
				switch (TYPEOF(u)) {
				case INTSXP:
				case LGLSXP:
				case FACTSXP:
				case ORDSXP:
					if (INTEGER(u)[i] == NA_INTEGER)
						INTEGER(rval)[i % len] = 0;
					break;
				case REALSXP:
					if (!FINITE(REAL(u)[i]))
						INTEGER(rval)[i % len] = 0;
					break;
				case STRSXP:
					if (STRING(u)[i] == NA_STRING)
						INTEGER(rval)[i % len] = 0;
					break;
				default:
					goto bad2;
				}
			}
		}
	}
	UNPROTECT(1);
	return rval;
bad:	error("complete.cases: not all arguments have the same length\n");
bad2:	error("complete.cases: invalid argument type\n");
	/*NOTREACHED*/
}
