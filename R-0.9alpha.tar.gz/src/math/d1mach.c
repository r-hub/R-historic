#include "Mathlib.h"

double d1mach(int i)
{
	switch(i) {
	case 1:
		return DBL_MIN;
	case 2:
		return DBL_MAX;
	case 3:
		return pow((double)i1mach(10), -(double)i1mach(14));
	case 4:
		return pow((double)i1mach(10), 1-(double)i1mach(14));
	case 5:
		return log10(2.0);
	}
}

double d1mach_(int *i)
{
	return d1mach(*i);
}
