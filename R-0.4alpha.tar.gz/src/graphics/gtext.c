/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Graphics.h"

static double deg2rad = 0.01745329251994329576;


void GText(char *str, double xc, double yc, double rot)
{
	if(xc != 0.0 || yc != 0.0) {
		double xl, xoff, yl, yoff;
		int x, y;
		xl = GStrWidth(str, 2);
		yl = fabs(GP->mex * GP->cra[1] / GP->fig2dev.by);
		xoff = -xc * xl * cos(deg2rad * rot) + yc * yl * sin(deg2rad * rot);
		yoff = -xc * xl * sin(deg2rad * rot) - yc * yl * cos(deg2rad * rot);
		x = (int)XFMAP(DP->xlast + xoff);
		y = (int)YFMAP(DP->ylast + yoff);
		DevMoveTo(x, y);
	}

	if(str && *str)
		if(DP->canClip) {
			GClip();
			DevText(str, xc, yc, (int)rot);
		}
		else {
			if(GP->xpd || (GP->plt[0] <= DP->xlast && DP->xlast <= GP->plt[1] &&
				GP->plt[2] <= DP->ylast && DP->ylast <= GP->plt[3]))
			DevText(str, xc, yc, (int)rot);
		}
}
