/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995, 1996  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "Defn.h"

	/*--- I / O -- S u p p o r t -- C o d e ---*/

	/* These routines provide hooks for supporting console */
	/* I/O.  Under raw Unix these routines simply provide a */
	/* connection to the stdio library.  Under a Motif */
	/* interface the routines would be considerably more */
	/* complex. */


	/* Fill a text buffer with user typed console input. */
	/* This routine is only called when R_Console == 1. */

int ReadKBD(char *buf, int len)
{
#ifdef OLD
	if (fgets(buf, len, R_Inputfile) == NULL)
#endif
	if (fgets(buf, len, stdin) == NULL)
		return 0;
	else
		return 1;
}


	/* Write a text buffer to the console. */
	/* All system output is filtered through this routine. */

void WriteConsole(char *buf, int len)
{
	printf("%s", buf);
}


	/* Reset so that input comes from the console This is used */
	/* after error messages so that if the system was reading */
	/* from a file, input is redirected from the console */

void ResetConsole()
{
	R_Console = 1;
	R_Inputfile = stdin;
}


	/* This is stdio support to ensure that console file buffers */
	/* are flushed. */

void FlushConsole()
{
	if (R_Console == 1)
		fflush(stdin);
}


	/* This is stdio support to reset if the used types EOF */
	/* on the console. */

void ClearerrConsole()
{
	if (R_Console == 1)
		clearerr(stdin);
}


void Consolegets(char *buf, int buflen)
{
	fgets(buf, buflen, stdin);
}


	/*--- F i l e    H an d l i n g    C o d e ---*/

FILE *R_OpenLibraryFile(char *file)
{
	char buf[256], *home;
	FILE *fp;

	if((home = getenv("RHOME")) == NULL)
		return NULL;
	sprintf(buf, "%s/library/%s", home, file);
	fp = fopen(buf,"r");
	return fp;
}


	/*--- I n i t i a l i z a t i o n    C o d e ---*/

#ifdef Proctime
#include <sys/times.h>

static clock_t StartTime;
#endif

int argc;
char **argv;

int main(int xargc, char **xargv)
{
	int value;
	char *item;

#ifdef Proctime
	struct tms t;

	StartTime = times(&t);
#endif

	argc = xargc;
	argv = xargv;

	/* On Unix the console is a file */
	/* we just use stdio to write on it */
	R_Consolefile = stdout;
	R_Outputfile = stdout;
	R_Sinkfile = NULL;

#ifdef FreeBSD
	/* Set up the math library for */
	/* POSIX exception handling */
	_LIB_VERSION = _POSIX_;
#endif

	item = getenv("R_NSIZE");
	if(item) { 
		sscanf(item, "%d", &value);
		if(value < R_NSize || value > 1000000)
			REprintf("warning: invalid vector heap size ignored\n");
		else
			R_NSize = value;
	}

	item = getenv("R_VSIZE");
	if(item) { 
		sscanf(item, "%d", &value);
		if(value < 1 || value > 100)
			REprintf("warning: invalid vector heap size ignored\n");
		else
			R_VSize = value * 1000000;
	}

	mainloop();
	return 0;
}

void R_InitialData(void)
{
	R_RestoreGlobalEnv();
}

void RCleanUp()
{
	char buf[128];

	if( R_DirtyImage ) {
ask:
		ClearerrConsole();
		FlushConsole();

		REprintf("Save workspace image? [y/n/c]: ");
		Consolegets(buf, 128);

		switch (buf[0]) {
		case 'y':
		case 'Y':
			R_SaveGlobalEnv();
			break;
		case 'n':
		case 'N':
			break;
		case 'c':
		case 'C':
			jump_to_toplevel();
			break;
		default:
			goto ask;
		}
	}
	KillDevice();
	exit(0);
}

void RBusy(int which)
{
}

	/*--- P l a t f o r m -- D e p e n d e n t -- F u n c t i o n s ---*/

#ifdef Proctime
#ifndef CLK_TCK
#define CLK_TCK	0.01666667
#endif

SEXP do_proctime(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP ans;
	struct tms timeinfo;
	int elapsed;
	elapsed = times(&timeinfo) - StartTime;;
	ans = allocVector(REALSXP, 5);
	REAL(ans)[0] = timeinfo.tms_utime / (double)CLK_TCK;
	REAL(ans)[1] = timeinfo.tms_stime / (double)CLK_TCK;
	REAL(ans)[2] = elapsed / (double)CLK_TCK;
	REAL(ans)[3] = timeinfo.tms_cutime / (double)CLK_TCK;
	REAL(ans)[4] = timeinfo.tms_cstime / (double)CLK_TCK;
	return ans;
}
#endif

SEXP do_machine(SEXP call, SEXP op, SEXP args, SEXP env)
{
	return mkString("Unix");
}

SEXP do_system(SEXP call, SEXP op, SEXP args, SEXP rho)
{
	FILE *fp;
	char *x = "r", buf[120];
	int read, i, j;
	SEXP tlist = R_NilValue, tchar, rval;

	checkArity(op, args);
	if (!isString(CAR(args)))
		errorcall(call, "character argument expected\n");
	if (isLogical(CADR(args)))
		read = INTEGER(CADR(args))[0];
	if (read) {
		PROTECT(tlist);
		fp = popen(CHAR(STRING(CAR(args))[0]), x);
		for (i = 0; fgets(buf, 120, fp); i++) {
			read = strlen(buf);
			buf[read - 1] = '\0';
			tchar = mkChar(buf);
			UNPROTECT(1);
			PROTECT(tlist = CONS(tchar, tlist));
		}
		pclose(fp);
		rval = allocVector(STRSXP, i);;
		for (j = (i - 1); j >= 0; j--) {
			STRING(rval)[j] = CAR(tlist);
			tlist = CDR(tlist);
		}
		UNPROTECT(1);
		return (rval);
	}
	else {
		system(CHAR(STRING(CAR(args))[0]));
		R_Visible = 0;
		return (R_NilValue);
	}
}


	/* Declarations to keep f77 happy */

int MAIN_() {return 0;}
int MAIN__() {return 0;}
int __main() {return 0;}
