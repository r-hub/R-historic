/*
 *  R : A Computer Langage for Statistical Data Analysis
 *  Copyright (C) 1995  Robert Gentleman and Ross Ihaka
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*include <MacHeaders>*/
#include <stdio.h>
#include "Defn.h"
#include "MACconsole.h"

static WindowRecord		editorWindowRecord;
static WindowPtr		editorWindow;
static Rect				editorWindowRect = {48, 10, 200, 300};
static TEHandle			editorTEH;

static int inFlag;

static void doEditorCursor(void)
{
	Point mousePt;
	TEIdle(editorTEH);
	GetMouse(&mousePt);
	if(PtInRect(mousePt, &((**editorTEH).viewRect)))
		SetCursor(*iBeam);
	else
		SetCursor(&qd.arrow);
}

static void doEditorKey(int theChar, EventRecord* theEvent)
{
		TEKey(theChar, editorTEH);
		/* ScrollInsertPt(editorTEH); */
		SetVScroll();
		ScrollInsertPt(editorTEH);
		/* AdjustText(); */

}

static void doEditorMenu(long code)
{
	int		theItem;
	Str255	name;
	
	theItem = LoWord(code);
	switch (HiWord(code)) {
		case 1:
		case 2:
			DoMenu(code);

		case 3: 
			if (SystemEdit(theItem-1) == 0) {
				switch (theItem) {
					case cutCommand:
						TECut(editorTEH);
						break;
	
					case copyCommand:
						TECopy(editorTEH);
						break;
		
					case pasteCommand:
						TEPaste(editorTEH);
						break;
		
					case clearCommand:
						TEDelete(editorTEH);
						break;
				}
			}
			break;
	}
	HiliteMenu(0);
}

static void doEditorGrow(WindowPtr w, Point p)
{
	GrafPtr	savePort;
	long	theResult;
	Rect	hr, vr;
	Rect 	r;
	
	GetPort(&savePort);
	SetPort(w);
	
	SetRect(&r, 80, 80, qd.screenBits.bounds.right, qd.screenBits.bounds.bottom);
	theResult = GrowWindow(w, p, &r);
	if (theResult == 0)
	  return;
	SizeWindow( w, LoWord(theResult), HiWord(theResult), true);
	SetRect(&hr, w->portRect.left-1, w->portRect.bottom-15, w->portRect.right-14, w->portRect.bottom+1);
	SetRect(&vr, w->portRect.right-15, w->portRect.top-1, w->portRect.right+1, w->portRect.bottom-14);
	HLock((Handle)editorContext.hScroll);
	HLock((Handle)editorContext.hScroll);
	(**editorContext.hScroll).contrlRect = hr;
	(**editorContext.vScroll).contrlRect = vr;
	HUnlock((Handle)editorContext.hScroll);
	HUnlock((Handle)editorContext.hScroll);
	EraseRect(&w->portRect);
	InvalRect(&w->portRect);
	SetView(w);
	SetVScroll();
	AdjustText();
	SetPort(savePort);
}

static ControlActionUPP	theAction = NULL; 
static void doEditorContent(WindowPtr theWindow, EventRecord *theEvent)
{
	int				cntlCode;
	ControlHandle 	theControl;
	int				pageSize;
	GrafPtr			savePort;
	
	GetPort(&savePort);
	SetPort(theWindow);

	GlobalToLocal(&theEvent->where);
	if ((cntlCode = FindControl(theEvent->where, theWindow, &theControl)) == 0) {
		if (PtInRect(theEvent->where, &(**editorTEH).viewRect))
			TEClick(theEvent->where, (theEvent->modifiers & shiftKey)!=0, editorTEH);
	} else if (cntlCode == inThumb) {
		TrackControl(theControl, theEvent->where, 0L);
		AdjustText();
	} else
		{
		if( theAction == NULL )
			theAction = NewControlActionProc(ScrollProc); /* JRH - PPC 21/11/95 */
		TrackControl(theControl, theEvent->where, theAction);
		}			
	SetPort(savePort);
}

static void doEditorActive(EventRecord *theEvent, WindowPtr theWindow, short windowCode)
{
	SetPort(theWindow);
	switch(windowCode) {
		case inContent:
			doEditorContent(theWindow, theEvent);
			break;
		case inDrag:
			DragWindow(theWindow, theEvent->where, &dragRect);
			break;
		case inGrow:
			doEditorGrow(theWindow, theEvent->where);
			break;
		case inGoAway:
			if(TrackGoAway(theWindow, theEvent->where))
				inFlag = 0;
			break;
		case inSysWindow:
			SystemClick(theEvent, theWindow);
			break;
	}
}


static void doEditorInactive(EventRecord *theEvent, WindowPtr theWindow, short windowCode)
{
	switch(windowCode) {
		case inContent:
			SelectWindow(theWindow);
			break;
		case inDrag:
			DragWindow(theWindow, theEvent->where, &dragRect);
			break;
		case inSysWindow:
			SystemClick(theEvent, theWindow);
			break;
	}
}

static void doEditorNotWindow(EventRecord *theEvent, WindowPtr theWindow, short windowCode)
{
	switch(windowCode) {
		case inMenuBar:
			doEditorMenu(MenuSelect(theEvent->where));
			break;
		case inDesk:
			SystemClick(theEvent, theWindow);
			break;
	}
}

static void doEditorUpdate(WindowPtr theWindow)
{
	GrafPtr	savePort;
	
	GetPort(&savePort);
	SetPort(theWindow);
	BeginUpdate(theWindow);
	EraseRect(&theWindow->portRect);
	DrawControls(theWindow);
	DrawGrowIcon(theWindow);
	TEUpdate(&theWindow->portRect, editorTEH);
	EndUpdate(theWindow);
	SetPort(savePort);
}

static void doEditorActivate(int theCode)
{
	if(theCode) {
		SetPort(editorWindow);
		
		TEActivate(editorTEH);
		ShowControl(editorContext.vScroll);
		ShowControl(editorContext.hScroll);
		TEFromScrap();
		
		/* DisableItem(myMenus[editM], undoCommand); */
	}
	else {
		TEDeactivate(editorTEH);
		HideControl(editorContext.vScroll);
		HideControl(editorContext.hScroll);
		ZeroScrap();
		TEToScrap();
	}
	DrawGrowIcon(editorWindow);
}


void InitEditor(Str255 title, int rows, int columns)
{
	static TEClickLoopUPP theClickLoop = NULL;

	Rect bounds, rect;
	FontInfo info;
	
	if( theClickLoop == NULL )
		theClickLoop = NewTEClickLoopProc(CClikLoop); /*JRH PPC 21/1/95 */
	editorWindow = NewWindow(&editorWindowRecord, &editorWindowRect, title,
							0, 0, (WindowPtr)-1L, 1, 0);
	SetPort(editorWindow);
	TextFont(monaco);
	TextSize(9);
	GetFontInfo(&info);
	editorContext.fontHeight = info.ascent + info.descent + info.leading;
	editorContext.fontWidth = info.widMax;
	bounds.top = 0;
	bounds.left = 0;
	bounds.bottom = rows * editorContext.fontHeight + 8 + 16;
	bounds.right = columns * editorContext.fontWidth + 8 + 16;
	SizeWindow(editorWindow, bounds.right, bounds.bottom, 0);
	
	rect = (*editorWindow).portRect;
	rect.left = rect.right-15;
	rect.right += 1;
	rect.bottom -= 14;
	rect.top -= 1;
	editorContext.vScroll = NewControl(editorWindow, &rect, "\p", 1, 0, 0, 0, scrollBarProc, 0L);

	rect = (*editorWindow).portRect;
	rect.top = rect.bottom-15;
	rect.bottom += 1;
	rect.right -= 14;
	rect.left -= 1;
	editorContext.hScroll = NewControl(editorWindow, &rect, "\p", 1, 0, 0, 512, scrollBarProc, 0L);
		
	rect = qd.thePort->portRect;
	rect.right -= SBarWidth;
	rect.bottom -= SBarWidth;
	InsetRect(&rect, 4, 4);
	editorTEH = TENew(&rect, &rect);
	(**editorTEH).crOnly = -1;
	SetClikLoop(theClickLoop, editorTEH);
	
	editorContext.active = 1;
	editorContext.theWindow = editorWindow;
	editorContext.theTEH = editorTEH;
	editorContext.lines = rows;
	editorContext.cols = columns;
	
	editorContext.doCursor = doEditorCursor;
	editorContext.doKey = doEditorKey;
	editorContext.doMenu = doEditorMenu;
	editorContext.doActive = doEditorActive;
	editorContext.doInactive = doEditorInactive;
	editorContext.doNotWindow = doEditorNotWindow;
	editorContext.doUpdate = doEditorUpdate;
	editorContext.doActivate = doEditorActivate;
	
	SetView(editorWindow);
	ShowWindow(editorWindow);
	DrawControls(editorWindow);
	DrawGrowIcon(editorWindow);
}

void CloseEditor(void)
{
	DisposeControl(editorContext.vScroll);
	DisposeControl(editorContext.hScroll);
	TEDispose(editorTEH);
	CloseWindow(editorWindow);
	editorContext.active = 0;
}

SEXP do_macedit(SEXP call, SEXP op, SEXP args, SEXP env)
{
	SEXP x;
	int i, j, k, l, n;
	
	checkArity(op, args);
	if(TYPEOF(CAR(args)) != STRSXP)
		errorcall(call, "argument must be of mode \"character\"\n");
	x = CAR(args);
	InitEditor("\pR Editor", 24, 80);
	activeContext = &editorContext;
	n = LENGTH(CAR(args));
	for(i=0 ; i<n ; i++) {
		TEInsert(CHAR(STRING(x)[i]), strlen(CHAR(STRING(x)[i])), editorTEH);
		TEInsert("\r", 1, editorTEH);
	}
	TESetSelect(0, 0, editorTEH);
	TECalText(editorTEH);
	ScrollInsertPt(editorTEH);
	SetVScroll();
	AdjustText();
	
	inFlag = 1;
	do {
		EventLoop();
	}
	while(inFlag);
	
	n = (**editorTEH).nLines;
		
	PROTECT(x = allocVector(STRSXP, n));
	for(i=0 ; i<n ; i++) {
		k = (**editorTEH).lineStarts[i];
		l = (**editorTEH).lineStarts[i+1];
		if((*((**editorTEH).hText))[l-1] == '\r')
			l = l - k -1;
		else
			l = l - k;
		STRING(x)[i] = allocString(l);
		for(j=0 ; j<l ; j++)
			CHAR(STRING(x)[i])[j] = (*((**editorTEH).hText))[k+j];
		CHAR(STRING(x)[i])[j] = '\0';
	}

	
	CloseEditor();
	activeContext = &stdioContext;	
	UNPROTECT(1);
	return x;
}
